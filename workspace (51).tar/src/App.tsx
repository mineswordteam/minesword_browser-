/**
 * Minesword Browser - Main Application
 * 
 * A production-oriented Iranian mobile browser platform.
 * All features use real APIs and real data.
 * No mock data, no fake results, no simulated responses.
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search, Globe, Shield, Wifi, WifiOff, Moon, Sun, Menu, X,
  Plus, Bookmark, Clock, Download, Settings,
  Lock, Unlock, RefreshCw, Home,
  EyeOff, FileText, Trash2, Info, ExternalLink,
  AlertTriangle, Save, Zap, ChevronLeft
} from 'lucide-react';
import { networkManager, type NetworkStatus } from './engine/network';
import { storageManager, type BrowserSettings } from './engine/storage';
import { iranianSearchEngine, type SearchResponse } from './engine/iranian-search';
import { isURL } from './engine/persian';
import { performanceMonitor, type PerformanceMetrics } from './engine/performance';
import { compatibilityTestSuite, type CompatibilityReport } from './engine/compatibility';
import { errorRecoveryManager, ErrorType } from './engine/recovery';
import { networkClient } from './engine/networking';
import { checkURLSafety } from './engine/security';
import { isKnownIframeBlocked, openUrlInNewTab } from './engine/url-loader';

// === TYPES ===

interface Tab {
  id: string;
  title: string;
  url: string;
  isLoading: boolean;
  isPrivate: boolean;
  canGoBack: boolean;
  canGoForward: boolean;
  loadError?: string;
  isDirectNavigation?: boolean; // For sites that block iframe
}

type View = 'home' | 'search' | 'settings' | 'bookmarks' | 'history' | 'downloads' | 'about' | 'tabs' | 'error' | 'diagnostics';

// === MAIN APP ===

export default function App() {
  const [tabs, setTabs] = useState<Tab[]>([{
    id: 'tab-1',
    title: 'صفحه اصلی',
    url: '',
    isLoading: false,
    isPrivate: false,
    canGoBack: false,
    canGoForward: false,
  }]);
  const [activeTabId, setActiveTabId] = useState('tab-1');
  const [view, setView] = useState<View>('home');
  const [addressInput, setAddressInput] = useState('');
  const [networkStatus, setNetworkStatus] = useState<NetworkStatus>(networkManager.getStatus());
  const [settings, setSettings] = useState<BrowserSettings>(storageManager.getSettings());
  const [searchResults, setSearchResults] = useState<SearchResponse | null>(null);
  const [showMenu, setShowMenu] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [errorInfo, setErrorInfo] = useState<{ type: string; url: string; message: string } | null>(null);
  const [isDark, setIsDark] = useState(() => {
    const saved = storageManager.getSettings().theme;
    if (saved === 'system') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return saved === 'dark';
  });
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const activeTab = tabs.find(t => t.id === activeTabId) || tabs[0];

  // Apply theme
  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDark);
    document.documentElement.classList.toggle('light', !isDark);
    document.documentElement.dir = 'rtl';
  }, [isDark]);

  // Subscribe to network changes
  useEffect(() => {
    const unsubscribe = networkManager.subscribe(setNetworkStatus);
    return unsubscribe;
  }, []);

  // Handle address bar input
  const handleAddressChange = useCallback((value: string) => {
    setAddressInput(value);
    if (value.length > 1 && !isURL(value)) {
      // Get suggestions from Iranian search engine AND search history
      const searchSuggestions = iranianSearchEngine.getSuggestions(value);
      const historySuggestions = storageManager.getSearchHistory()
        .filter(h => h.query.includes(value))
        .slice(0, 5)
        .map(h => h.query);
      const combined = [...new Set([...searchSuggestions, ...historySuggestions])].slice(0, 8);
      setSuggestions(combined);
      setShowSuggestions(combined.length > 0);
    } else {
      setShowSuggestions(false);
    }
  }, []);

  // Navigate to URL
  const navigateTo = useCallback((url: string) => {
    // Check if site blocks iframe embedding
    if (isKnownIframeBlocked(url)) {
      // Create a new tab in OUR browser (not system browser)
      const newTab: Tab = {
        id: `tab-${Date.now()}`,
        title: url,
        url: url,
        isLoading: true,
        isPrivate: activeTab?.isPrivate || false,
        canGoBack: true,
        canGoForward: false,
        isDirectNavigation: true, // Flag for direct navigation (no iframe)
      };
      setTabs(prev => [...prev, newTab]);
      setActiveTabId(newTab.id);
      setView('home');
      setAddressInput(url);
      
      // Add to history
      if (!activeTab?.isPrivate) {
        storageManager.addHistoryEntry(url, url);
      }
      return;
    }

    // Check network status
    if (networkStatus.state === 'OFFLINE') {
      // Check if we have cached/saved version
      const savedPages = storageManager.getSavedPages();
      const savedVersion = savedPages.find(p => p.url === url);
      if (savedVersion) {
        // Show saved version
        setTabs(prev => prev.map(t => {
          if (t.id === activeTabId) {
            return { ...t, url: `minesword-saved://${savedVersion.id}`, title: savedVersion.title, isLoading: false, canGoBack: !!t.url };
          }
          return t;
        }));
        setView('home');
        setAddressInput(url);
        return;
      }
      // Show offline error
      setErrorInfo({
        type: 'offline',
        url,
        message: 'اتصال اینترنت برقرار نیست و نسخه ذخیره‌شده‌ای از این صفحه وجود ندارد.',
      });
      setView('error');
      return;
    }

    setTabs(prev => prev.map(t => {
      if (t.id === activeTabId) {
        return { ...t, url, title: url, isLoading: true, canGoBack: !!t.url, loadError: undefined };
      }
      return t;
    }));
    setView('home');
    setAddressInput(url);

    if (!activeTab?.isPrivate) {
      storageManager.addHistoryEntry(url, url);
    }

    // Set a timeout for load failure detection
    setTimeout(() => {
      setTabs(prev => prev.map(t => {
        if (t.id === activeTabId && t.isLoading) {
          return { ...t, isLoading: false };
        }
        return t;
      }));
    }, 15000);
  }, [activeTabId, activeTab?.isPrivate, networkStatus.state]);

  // Navigate to URL or search
  const handleNavigate = useCallback((input: string) => {
    const trimmed = input.trim();
    if (!trimmed) return;

    setShowSuggestions(false);

    if (isURL(trimmed)) {
      let url = trimmed;
      if (!/^https?:\/\//i.test(url)) {
        url = 'https://' + url;
      }
      navigateTo(url);
    } else {
      // Not a URL - search using Minesword Iranian Search
      const searchResults = iranianSearchEngine.search(trimmed);
      setSearchResults(searchResults);
      setView('search');
      setAddressInput(trimmed);

      if (!activeTab?.isPrivate) {
        storageManager.addSearchHistory(trimmed, searchResults.totalResults);
      }
    }
  }, [navigateTo, settings.searchEngine, activeTab?.isPrivate]);

  // Perform search - uses Minesword Iranian Search Engine
  const performSearch = useCallback((query: string) => {
    const searchResults = iranianSearchEngine.search(query);
    setSearchResults(searchResults);
    setView('search');
    setAddressInput(query);

    if (!activeTab?.isPrivate) {
      storageManager.addSearchHistory(query, searchResults.totalResults);
    }
  }, [activeTab?.isPrivate]);

  // Tab management
  const createTab = (isPrivate = false) => {
    const newTab: Tab = {
      id: `tab-${Date.now()}`,
      title: 'صفحه اصلی',
      url: '',
      isLoading: false,
      isPrivate,
      canGoBack: false,
      canGoForward: false,
    };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    setView('home');
    setAddressInput('');
    setSearchResults(null);
  };

  const closeTab = (tabId: string) => {
    const tab = tabs.find(t => t.id === tabId);
    
    // Clear private tab data on close
    if (tab?.isPrivate) {
      // Private tabs don't persist - data is already not saved
    }
    
    setTabs(prev => {
      const newTabs = prev.filter(t => t.id !== tabId);
      if (newTabs.length === 0) {
        const newTab: Tab = {
          id: `tab-${Date.now()}`,
          title: 'صفحه اصلی',
          url: '',
          isLoading: false,
          isPrivate: false,
          canGoBack: false,
          canGoForward: false,
        };
        setActiveTabId(newTab.id);
        return [newTab];
      }
      if (tabId === activeTabId) {
        setActiveTabId(newTabs[newTabs.length - 1].id);
      }
      return newTabs;
    });
  };

  // Iframe load handler
  const handleIframeLoad = () => {
    setTabs(prev => prev.map(t => {
      if (t.id === activeTabId) {
        try {
          const iframe = iframeRef.current;
          const title = iframe?.contentDocument?.title || t.url;
          return { ...t, isLoading: false, title };
        } catch {
          // Cross-origin - can't read title
          return { ...t, isLoading: false };
        }
      }
      return t;
    }));
  };

  // Iframe error handler - offer to open in new tab
  const handleIframeError = () => {
    setTabs(prev => prev.map(t => {
      if (t.id === activeTabId) {
        return { ...t, isLoading: false, loadError: 'blocked' };
      }
      return t;
    }));
    setErrorInfo({
      type: 'blocked',
      url: activeTab?.url || '',
      message: 'این سایت اجازه نمایش در مرورگر را نمی‌دهد. می‌توانید آن را در تب جدید باز کنید.',
    });
    setView('error');
  };

  // Open URL in new tab/window
  const openInNewTab = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  // Save current page
  const saveCurrentPage = useCallback(async () => {
    if (!activeTab?.url || activeTab.url.startsWith('minesword-')) return;
    
    try {
      const iframe = iframeRef.current;
      const doc = iframe?.contentDocument;
      if (doc) {
        const content = doc.documentElement.outerHTML;
        storageManager.savePage({
          url: activeTab.url,
          title: doc.title || activeTab.url,
          content,
          size: content.length,
        });
      }
    } catch (e) {
      console.error('Failed to save page:', e);
    }
  }, [activeTab]);

  // Toggle bookmark
  const toggleBookmark = useCallback(() => {
    if (!activeTab?.url) return;
    if (storageManager.isBookmarked(activeTab.url)) {
      const bookmarks = storageManager.getBookmarks();
      const bm = bookmarks.find(b => b.url === activeTab.url);
      if (bm) storageManager.removeBookmark(bm.id);
    } else {
      storageManager.addBookmark({
        url: activeTab.url,
        title: activeTab.title || activeTab.url,
      });
    }
    // Force re-render
    setTabs([...tabs]);
  }, [activeTab, tabs]);

  // Theme toggle
  const toggleTheme = () => {
    setIsDark(!isDark);
    storageManager.updateSettings({ theme: isDark ? 'light' : 'dark' });
  };

  // Network state indicator
  const getNetworkIcon = () => {
    switch (networkStatus.state) {
      case 'GLOBAL_ONLINE': return <Wifi className="w-4 h-4 text-green-400" />;
      case 'LOCAL_NETWORK': return <Wifi className="w-4 h-4 text-yellow-400" />;
      case 'OFFLINE': return <WifiOff className="w-4 h-4 text-red-400" />;
    }
  };

  const isBookmarked = activeTab?.url ? storageManager.isBookmarked(activeTab.url) : false;

  // === RENDER ===

  return (
    <div className={`h-full w-full flex flex-col ${isDark ? 'bg-minesword-dark text-minesword-text-dark' : 'bg-minesword-light text-minesword-text-light'} transition-colors duration-300`}>
      {/* Status Bar */}
      <div className={`safe-area-top flex items-center justify-between px-3 py-1 text-xs ${isDark ? 'bg-minesword-dark-surface/80' : 'bg-minesword-light-surface/80'} backdrop-blur-sm`}>
        <div className="flex items-center gap-2">
          {getNetworkIcon()}
          <span className="opacity-60">
            {networkStatus.state === 'GLOBAL_ONLINE' ? 'آنلاین' :
             networkStatus.state === 'LOCAL_NETWORK' ? 'شبکه محلی' : 'آفلاین'}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="font-medium text-minesword-primary">Minesword</span>
          {activeTab?.isPrivate && <EyeOff className="w-3 h-3 text-minesword-accent" />}
        </div>
      </div>

      {/* Address Bar */}
      <div className={`relative px-3 py-2 ${isDark ? 'bg-minesword-dark-surface' : 'bg-minesword-light-surface'} border-b ${isDark ? 'border-white/5' : 'border-black/5'}`}>
        <div className="flex items-center gap-2">
          <button
            onClick={() => { setView('home'); setSearchResults(null); setErrorInfo(null); }}
            className="touch-target opacity-60 hover:opacity-100 transition-opacity"
            aria-label="صفحه اصلی"
          >
            <Home className="w-5 h-5" />
          </button>

          <div className="flex-1 relative">
            <div className={`flex items-center gap-2 px-3 py-2 rounded-xl ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'} border ${isDark ? 'border-white/5' : 'border-black/5'} focus-within:border-minesword-primary/50 transition-colors`}>
              {activeTab?.url && !activeTab.url.startsWith('minesword-') ? (
                activeTab.url.startsWith('https') ?
                  <Lock className="w-4 h-4 text-green-400 shrink-0" /> :
                  <Unlock className="w-4 h-4 text-yellow-400 shrink-0" />
              ) : (
                <Search className="w-4 h-4 opacity-40 shrink-0" />
              )}
              <input
                type="text"
                value={addressInput}
                onChange={(e) => handleAddressChange(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleNavigate(addressInput);
                }}
                onFocus={() => {
                  if (addressInput.length > 1 && !isURL(addressInput)) {
                    setShowSuggestions(true);
                  }
                }}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                placeholder="جستجو یا آدرس وب‌سایت..."
                className="flex-1 bg-transparent outline-none text-sm placeholder:opacity-40"
                dir="auto"
              />
              {activeTab?.isLoading && (
                <RefreshCw className="w-4 h-4 animate-spin-slow text-minesword-primary shrink-0" />
              )}
            </div>

            <AnimatePresence>
              {showSuggestions && suggestions.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  className={`absolute top-full left-0 right-0 mt-1 rounded-xl overflow-hidden shadow-lg z-50 ${isDark ? 'bg-minesword-dark-card border border-white/10' : 'bg-white border border-black/10'}`}
                >
                  {suggestions.map((sug, i) => (
                    <button
                      key={i}
                      onMouseDown={() => handleNavigate(sug)}
                      className={`w-full px-4 py-3 text-right text-sm flex items-center gap-2 ${isDark ? 'hover:bg-white/5' : 'hover:bg-black/5'} transition-colors`}
                    >
                      <Search className="w-4 h-4 opacity-40" />
                      <span>{sug}</span>
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Bookmark toggle */}
          {activeTab?.url && !activeTab.url.startsWith('minesword-') && (
            <button
              onClick={toggleBookmark}
              className="touch-target opacity-60 hover:opacity-100 transition-opacity"
              aria-label="نشانک"
            >
              <Bookmark className={`w-5 h-5 ${isBookmarked ? 'fill-minesword-primary text-minesword-primary' : ''}`} />
            </button>
          )}

          <button
            onClick={() => setShowMenu(!showMenu)}
            className="touch-target opacity-60 hover:opacity-100 transition-opacity"
            aria-label="منو"
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-hidden relative">
        <AnimatePresence mode="wait">
          {view === 'home' && !activeTab?.url && (
            <motion.div
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="h-full overflow-y-auto"
            >
              <HomePage
                isDark={isDark}
                onSearch={performSearch}
                onNavigate={navigateTo}
                networkStatus={networkStatus}
              />
            </motion.div>
          )}

          {view === 'home' && activeTab?.url && !activeTab.loadError && (
            <motion.div
              key="webview"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="h-full relative"
            >
              {activeTab.isLoading && (
                <div className="absolute top-0 left-0 right-0 h-0.5 bg-minesword-primary/20 z-10">
                  <div className="h-full bg-minesword-primary animate-pulse" style={{ width: '60%' }} />
                </div>
              )}
              {activeTab.url.startsWith('minesword-saved://') ? (
                <SavedPageView pageId={activeTab.url.replace('minesword-saved://', '')} isDark={isDark} />
              ) : activeTab.isDirectNavigation ? (
                // Direct navigation for sites that block iframe
                <DirectNavigationView url={activeTab.url} isDark={isDark} onBack={() => {
                  setTabs(prev => prev.filter(t => t.id !== activeTab.id));
                  if (tabs.length > 1) {
                    setActiveTabId(tabs[tabs.length - 2].id);
                  }
                }} />
              ) : (
                <iframe
                  ref={iframeRef}
                  src={activeTab.url}
                  onLoad={handleIframeLoad}
                  onError={handleIframeError}
                  className="w-full h-full border-0"
                  title={activeTab.title}
                  referrerPolicy="no-referrer"
                />
              )}
            </motion.div>
          )}

          {view === 'search' && searchResults && (
            <motion.div
              key="search"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="h-full overflow-y-auto"
            >
              <SearchResultsView
                results={searchResults}
                isDark={isDark}
                onNavigate={navigateTo}
                onSearch={performSearch}
              />
            </motion.div>
          )}

          {view === 'error' && errorInfo && (
            <motion.div
              key="error"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="h-full overflow-y-auto"
            >
              <ErrorPage 
                error={errorInfo} 
                isDark={isDark} 
                onRetry={() => {
                  if (errorInfo.url && errorInfo.type !== 'offline') {
                    navigateTo(errorInfo.url);
                  } else {
                    setView('home');
                  }
                }}
                onOpenInNewTab={openInNewTab}
              />
            </motion.div>
          )}

          {view === 'settings' && (
            <motion.div key="settings" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="h-full overflow-y-auto">
              <SettingsView isDark={isDark} settings={settings} onUpdateSettings={(s) => {
                storageManager.updateSettings(s);
                setSettings(storageManager.getSettings());
                if (s.theme) {
                  if (s.theme === 'system') setIsDark(window.matchMedia('(prefers-color-scheme: dark)').matches);
                  else setIsDark(s.theme === 'dark');
                }
              }} />
            </motion.div>
          )}

          {view === 'bookmarks' && (
            <motion.div key="bookmarks" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="h-full overflow-y-auto">
              <BookmarksView isDark={isDark} onNavigate={navigateTo} />
            </motion.div>
          )}

          {view === 'history' && (
            <motion.div key="history" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="h-full overflow-y-auto">
              <HistoryView isDark={isDark} onNavigate={navigateTo} />
            </motion.div>
          )}

          {view === 'downloads' && (
            <motion.div key="downloads" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="h-full overflow-y-auto">
              <DownloadsView isDark={isDark} />
            </motion.div>
          )}

          {view === 'tabs' && (
            <motion.div key="tabs" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="h-full overflow-y-auto">
              <TabsView isDark={isDark} tabs={tabs} activeTabId={activeTabId}
                onSelectTab={(id) => { setActiveTabId(id); setView('home'); setErrorInfo(null); }}
                onCloseTab={closeTab} onCreateTab={createTab} />
            </motion.div>
          )}

          {view === 'about' && (
            <motion.div key="about" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="h-full overflow-y-auto">
              <AboutView isDark={isDark} />
            </motion.div>
          )}

          {view === 'diagnostics' && (
            <motion.div key="diagnostics" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="h-full overflow-y-auto">
              <DiagnosticsView isDark={isDark} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom Navigation */}
      <div className={`safe-area-bottom flex items-center justify-around px-2 py-2 ${isDark ? 'bg-minesword-dark-surface border-t border-white/5' : 'bg-minesword-light-surface border-t border-black/5'}`}>
        <button onClick={() => { setView('home'); setErrorInfo(null); }} className="touch-target flex flex-col items-center gap-0.5 opacity-60 hover:opacity-100">
          <Home className="w-5 h-5" />
          <span className="text-[10px]">خانه</span>
        </button>
        <button onClick={() => setView('bookmarks')} className="touch-target flex flex-col items-center gap-0.5 opacity-60 hover:opacity-100">
          <Bookmark className="w-5 h-5" />
          <span className="text-[10px]">نشانک</span>
        </button>
        <button onClick={() => saveCurrentPage()} className="touch-target flex flex-col items-center gap-0.5 opacity-60 hover:opacity-100" title="ذخیره صفحه">
          <Save className="w-5 h-5" />
          <span className="text-[10px]">ذخیره</span>
        </button>
        <button onClick={() => setView('tabs')} className="touch-target flex flex-col items-center gap-0.5 relative">
          <div className={`w-6 h-6 rounded border-2 flex items-center justify-center text-xs font-bold ${isDark ? 'border-white/40' : 'border-black/40'}`}>
            {tabs.length}
          </div>
          <span className="text-[10px]">زبانه‌ها</span>
        </button>
        <button onClick={() => setView('history')} className="touch-target flex flex-col items-center gap-0.5 opacity-60 hover:opacity-100">
          <Clock className="w-5 h-5" />
          <span className="text-[10px]">تاریخچه</span>
        </button>
        <button onClick={() => setView('settings')} className="touch-target flex flex-col items-center gap-0.5 opacity-60 hover:opacity-100">
          <Settings className="w-5 h-5" />
          <span className="text-[10px]">تنظیمات</span>
        </button>
      </div>

      {/* Dropdown Menu */}
      <AnimatePresence>
        {showMenu && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setShowMenu(false)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: -10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: -10 }}
              className={`absolute top-16 left-3 right-3 z-50 rounded-2xl shadow-2xl overflow-hidden ${isDark ? 'bg-minesword-dark-card border border-white/10' : 'bg-white border border-black/10'}`}
            >
              <MenuItem icon={<Plus className="w-5 h-5" />} label="زبانه جدید" onClick={() => { createTab(); setShowMenu(false); }} isDark={isDark} />
              <MenuItem icon={<EyeOff className="w-5 h-5" />} label="زبانه خصوصی" onClick={() => { createTab(true); setShowMenu(false); }} isDark={isDark} />
              {activeTab?.url && !activeTab.url.startsWith('minesword-') && (
                <MenuItem icon={<Save className="w-5 h-5" />} label="ذخیره صفحه" onClick={() => { saveCurrentPage(); setShowMenu(false); }} isDark={isDark} />
              )}
              <MenuItem icon={<Bookmark className="w-5 h-5" />} label="نشانک‌ها" onClick={() => { setView('bookmarks'); setShowMenu(false); }} isDark={isDark} />
              <MenuItem icon={<Download className="w-5 h-5" />} label="دانلودها" onClick={() => { setView('downloads'); setShowMenu(false); }} isDark={isDark} />
              <MenuItem icon={isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />} label={isDark ? 'حالت روشن' : 'حالت تاریک'} onClick={() => { toggleTheme(); setShowMenu(false); }} isDark={isDark} />
              <MenuItem icon={<Shield className="w-5 h-5" />} label="حریم خصوصی" onClick={() => { setView('settings'); setShowMenu(false); }} isDark={isDark} />
              <MenuItem icon={<Zap className="w-5 h-5" />} label="عیب‌یابی و آمار" onClick={() => { setView('diagnostics'); setShowMenu(false); }} isDark={isDark} />
              <div className={`h-px ${isDark ? 'bg-white/10' : 'bg-black/10'}`} />
              <MenuItem icon={<Info className="w-5 h-5" />} label="درباره Minesword" onClick={() => { setView('about'); setShowMenu(false); }} isDark={isDark} />
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

// === SUB-COMPONENTS ===

function MenuItem({ icon, label, onClick, isDark }: { icon: React.ReactNode; label: string; onClick: () => void; isDark: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-3 text-right text-sm ${isDark ? 'hover:bg-white/5' : 'hover:bg-black/5'} transition-colors`}
    >
      <span className="opacity-70">{icon}</span>
      <span>{label}</span>
    </button>
  );
}

function HomePage({ isDark, onSearch, onNavigate, networkStatus }: {
  isDark: boolean;
  onSearch: (q: string) => void;
  onNavigate: (url: string) => void;
  networkStatus: NetworkStatus;
}) {
  const [searchInput, setSearchInput] = useState('');
  const history = storageManager.getHistory().slice(0, 8);
  const siteCount = iranianSearchEngine.getSiteCount();

  // Popular Iranian sites
  const popularSites = [
    { name: 'دیجی‌کالا', url: 'https://www.digikala.com', emoji: '🛒' },
    { name: 'آپارات', url: 'https://www.aparat.com', emoji: '▶️' },
    { name: 'ورزش سه', url: 'https://www.varzesh3.com', emoji: '⚽' },
    { name: 'دیوار', url: 'https://www.divar.ir', emoji: '📋' },
    { name: 'اسنپ', url: 'https://www.snapp.ir', emoji: '🚕' },
    { name: 'فیلیمو', url: 'https://www.filimo.com', emoji: '🎬' },
  ];

  return (
    <div className="p-4 pb-8">
      {/* Welcome */}
      <div className="text-center mb-6 animate-fade-in">
        <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-gradient-to-br from-minesword-primary to-minesword-accent flex items-center justify-center shadow-lg">
          <span className="text-2xl font-bold text-white">M</span>
        </div>
        <h1 className="text-xl font-bold persian-text">مرورگر ماینسورد</h1>
        <p className="text-sm opacity-60 mt-1 persian-text">مرورگر ایرانی برای اینترنت ملی</p>
      </div>

      {/* Search Box */}
      <div className={`rounded-2xl p-4 mb-6 ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'} animate-fade-in`}>
        <div className={`flex items-center gap-3 px-4 py-3 rounded-xl ${isDark ? 'bg-minesword-dark' : 'bg-white'} border ${isDark ? 'border-white/5' : 'border-black/5'}`}>
          <Search className="w-5 h-5 text-minesword-primary" />
          <input
            type="text"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && searchInput.trim()) {
                onSearch(searchInput.trim());
              }
            }}
            placeholder="جستجو با موتور جستجوی ماینسورد..."
            className="flex-1 bg-transparent outline-none text-sm placeholder:opacity-40"
            dir="auto"
          />
          <button
            onClick={() => { if (searchInput.trim()) onSearch(searchInput.trim()); }}
            className="px-3 py-1.5 bg-minesword-primary text-white rounded-lg text-xs font-medium hover:bg-minesword-primary/90 transition-colors"
          >
            جستجو
          </button>
        </div>
        <p className="text-xs opacity-40 mt-2 persian-text text-center">
          موتور جستجوی ایرانی • {siteCount} سایت فهرست‌شده
        </p>
      </div>

      {/* Popular Iranian Sites */}
      <div className="mb-6 animate-fade-in">
        <h2 className="text-sm font-medium opacity-60 mb-3 persian-text">سایت‌های پرطرفدار ایرانی</h2>
        <div className="grid grid-cols-3 gap-3">
          {popularSites.map((site, i) => (
            <button
              key={i}
              onClick={() => onNavigate(site.url)}
              className={`flex flex-col items-center gap-2 p-3 rounded-xl ${isDark ? 'bg-minesword-dark-card hover:bg-minesword-dark-card/80' : 'bg-minesword-light-card hover:bg-minesword-light-card/80'} transition-colors`}
            >
              <span className="text-2xl">{site.emoji}</span>
              <span className="text-xs opacity-70 persian-text">{site.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Network Status Card */}
      {networkStatus.state !== 'GLOBAL_ONLINE' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`rounded-2xl p-4 mb-6 border ${
            networkStatus.state === 'LOCAL_NETWORK'
              ? 'border-yellow-500/30 bg-yellow-500/5'
              : 'border-red-500/30 bg-red-500/5'
          }`}
        >
          <div className="flex items-center gap-3">
            {networkStatus.state === 'LOCAL_NETWORK' ? (
              <Wifi className="w-6 h-6 text-yellow-400" />
            ) : (
              <WifiOff className="w-6 h-6 text-red-400" />
            )}
            <div className="flex-1">
              <p className="font-medium text-sm persian-text">
                {networkStatus.state === 'LOCAL_NETWORK'
                  ? 'فقط شبکه محلی در دسترس است'
                  : 'اتصال اینترنت برقرار نیست'}
              </p>
              <p className="text-xs opacity-60 mt-0.5 persian-text">
                {networkStatus.state === 'LOCAL_NETWORK'
                  ? 'خدمات محلی و محتوای ذخیره‌شده در دسترس هستند.'
                  : 'محتوای ذخیره‌شده و نشانک‌ها همچنان در دسترس هستند.'}
              </p>
            </div>
          </div>
        </motion.div>
      )}

      {/* Recent History */}
      {history.length > 0 && (
        <div className="animate-fade-in">
          <h2 className="text-sm font-medium opacity-60 mb-3 persian-text">اخیراً بازدید شده</h2>
          <div className={`rounded-2xl overflow-hidden ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'}`}>
            {history.map((entry, i) => (
              <button
                key={entry.id}
                onClick={() => onNavigate(entry.url)}
                className={`w-full flex items-center gap-3 px-4 py-3 ${isDark ? 'hover:bg-white/5' : 'hover:bg-black/5'} transition-colors ${i > 0 ? (isDark ? 'border-t border-white/5' : 'border-t border-black/5') : ''}`}
              >
                <Clock className="w-4 h-4 opacity-40" />
                <div className="flex-1 text-right min-w-0">
                  <p className="text-sm truncate">{entry.title || entry.url}</p>
                  <p className="text-xs opacity-40 truncate" dir="ltr">{entry.url}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {history.length === 0 && (
        <div className="text-center py-8 animate-fade-in">
          <Globe className="w-12 h-12 mx-auto opacity-20 mb-3" />
          <p className="text-sm opacity-50 persian-text">تاریخچه‌ای وجود ندارد</p>
          <p className="text-xs opacity-30 mt-1 persian-text">آدرسی در نوار آدرس وارد کنید تا شروع کنید</p>
        </div>
      )}
    </div>
  );
}

function SearchResultsView({ results, isDark, onNavigate, onSearch }: {
  results: SearchResponse;
  isDark: boolean;
  onNavigate: (url: string) => void;
  onSearch: (q: string) => void;
}) {
  return (
    <div className="p-4 pb-8">
      <div className="mb-4 animate-fade-in">
        <p className="text-xs opacity-50 persian-text">
          {results.totalResults} نتیجه ({(results.searchTime).toFixed(1)} میلی‌ثانیه)
        </p>
      </div>

      {results.results.length === 0 ? (
        <div className="text-center py-12 animate-fade-in">
          <div className="text-4xl mb-3">🔍</div>
          <p className="text-lg font-medium persian-text">نتیجه‌ای یافت نشد</p>
          <p className="text-sm opacity-60 mt-2 persian-text">
            عبارت «{results.query}» نتیجه‌ای نداشت. عبارت دیگری را امتحان کنید.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {results.results.map((result: any, i: number) => (
            <motion.div
              key={result.site.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className={`rounded-xl p-4 ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'}`}
            >
              <button onClick={() => onNavigate(result.site.url)} className="w-full text-right">
                <p className="text-xs text-minesword-accent truncate mb-1" dir="ltr">
                  {result.site.url}
                </p>
                <h3 className="text-base font-medium text-minesword-primary hover:underline persian-text leading-relaxed">
                  {result.site.title}
                </h3>
                <p className="text-sm opacity-70 mt-2 persian-text leading-relaxed">
                  {result.snippet}
                </p>
                <div className="flex items-center gap-3 mt-2 text-xs opacity-40">
                  {result.site.category && (
                    <span className="px-2 py-0.5 rounded-full bg-minesword-primary/10 text-minesword-primary">
                      {result.site.category}
                    </span>
                  )}
                </div>
              </button>
            </motion.div>
          ))}
        </div>
      )}

      {/* Related searches */}
      {results.relatedSearches.length > 0 && (
        <div className="mt-6 animate-fade-in">
          <h3 className="text-sm font-medium opacity-60 mb-3 persian-text">جستجوهای مرتبط</h3>
          <div className="flex flex-wrap gap-2">
            {results.relatedSearches.map((related: string, i: number) => (
              <button
                key={i}
                onClick={() => onSearch(related)}
                className={`px-3 py-1.5 rounded-full text-xs ${isDark ? 'bg-minesword-dark-card hover:bg-minesword-dark' : 'bg-minesword-light-card hover:bg-minesword-primary/10'} transition-colors persian-text`}
              >
                {related}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function SavedPageView({ pageId, isDark }: { pageId: string; isDark: boolean }) {
  const pages = storageManager.getSavedPages();
  const page = pages.find(p => p.id === pageId);
  
  if (!page) {
    return (
      <div className="p-8 text-center">
        <AlertTriangle className="w-12 h-12 mx-auto opacity-30 mb-3" />
        <p className="persian-text">صفحه ذخیره‌شده یافت نشد</p>
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto">
      <div className={`p-4 border-b ${isDark ? 'border-white/5 bg-minesword-dark-card' : 'border-black/5 bg-minesword-light-card'}`}>
        <p className="text-xs opacity-50 persian-text">نسخه ذخیره‌شده • {new Date(page.savedAt).toLocaleDateString('fa-IR')}</p>
        <p className="text-sm font-medium mt-1 persian-text">{page.title}</p>
      </div>
      <div
        className="p-4 persian-text leading-relaxed"
        dangerouslySetInnerHTML={{ __html: page.content }}
      />
    </div>
  );
}

function DirectNavigationView({ url, isDark, onBack }: { url: string; isDark: boolean; onBack: () => void }) {
  return (
    <div className={`h-full flex flex-col items-center justify-center p-8 text-center ${isDark ? 'bg-minesword-dark' : 'bg-minesword-light'}`}>
      <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-6 ${isDark ? 'bg-minesword-primary/20' : 'bg-minesword-primary/10'}`}>
        <ExternalLink className="w-10 h-10 text-minesword-primary" />
      </div>
      
      <h2 className="text-xl font-bold mb-3 persian-text">باز کردن سایت</h2>
      
      <p className="text-sm opacity-70 mb-6 persian-text leading-relaxed max-w-md">
        این سایت اجازه نمایش در مرورگر داخلی را نمی‌دهد.
        <br />
        برای باز کردن، روی دکمه زیر کلیک کنید.
      </p>

      <div className="text-xs opacity-50 mb-8 break-all" dir="ltr">{url}</div>

      <div className="flex flex-col gap-3 w-full max-w-xs">
        <button
          onClick={() => {
            window.location.href = url;
          }}
          className="flex items-center justify-center gap-2 px-6 py-3 bg-minesword-primary text-white rounded-xl hover:bg-minesword-primary/90 transition-colors font-medium"
        >
          <ExternalLink className="w-5 h-5" />
          <span className="persian-text">باز کردن سایت</span>
        </button>
        
        <button
          onClick={onBack}
          className={`flex items-center justify-center gap-2 px-6 py-3 rounded-xl ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'} hover:opacity-80 transition-opacity`}
        >
          <ChevronLeft className="w-5 h-5" />
          <span className="persian-text">بازگشت</span>
        </button>
      </div>
    </div>
  );
}

function ErrorPage({ error, isDark, onRetry, onOpenInNewTab }: {
  error: { type: string; url: string; message: string };
  isDark: boolean;
  onRetry: () => void;
  onOpenInNewTab?: (url: string) => void;
}) {
  return (
    <div className="p-6 flex flex-col items-center justify-center h-full text-center animate-fade-in">
      <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-6 ${
        error.type === 'offline' ? 'bg-red-500/10' : 'bg-yellow-500/10'
      }`}>
        {error.type === 'offline' ? (
          <WifiOff className="w-10 h-10 text-red-400" />
        ) : (
          <AlertTriangle className="w-10 h-10 text-yellow-400" />
        )}
      </div>
      
      <h2 className="text-xl font-bold mb-2 persian-text">
        {error.type === 'offline' ? 'اتصال برقرار نیست' : 
         error.type === 'blocked' ? 'سایت قابل نمایش نیست' : 'خطا در بارگذاری'}
      </h2>
      
      <p className="text-sm opacity-60 mb-6 persian-text leading-relaxed max-w-sm">
        {error.message}
      </p>

      {error.url && (
        <p className="text-xs opacity-40 mb-6 persian-text break-all" dir="ltr">{error.url}</p>
      )}

      <div className="flex flex-col gap-3 w-full max-w-xs">
        {error.type === 'blocked' && onOpenInNewTab && (
          <button
            onClick={() => onOpenInNewTab(error.url)}
            className="flex items-center justify-center gap-2 px-4 py-3 bg-minesword-primary text-white rounded-xl hover:bg-minesword-primary/90 transition-colors"
          >
            <ExternalLink className="w-4 h-4" />
            <span className="persian-text">باز کردن در تب جدید</span>
          </button>
        )}

        {error.type !== 'offline' && (
          <button
            onClick={onRetry}
            className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'} hover:opacity-80 transition-opacity`}
          >
            <RefreshCw className="w-4 h-4" />
            <span className="persian-text">تلاش مجدد</span>
          </button>
        )}
        
        <button
          onClick={() => {
            const saved = storageManager.getSavedPages();
            const match = saved.find(p => p.url === error.url);
            if (match) {
              window.location.hash = `saved://${match.id}`;
            }
          }}
          className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'} hover:opacity-80 transition-opacity`}
        >
          <FileText className="w-4 h-4" />
          <span className="persian-text">نسخه‌های ذخیره‌شده</span>
        </button>
      </div>
    </div>
  );
}

function SettingsView({ isDark, settings, onUpdateSettings }: {
  isDark: boolean;
  settings: BrowserSettings;
  onUpdateSettings: (s: Partial<BrowserSettings>) => void;
}) {
  return (
    <div className="p-4 pb-8">
      <h1 className="text-xl font-bold mb-6 persian-text">تنظیمات</h1>

      <SettingsSection title="عمومی" isDark={isDark}>
        <SettingsToggle label="حالت تاریک" description="تم تاریک برای راحتی چشم" value={isDark} onChange={(v) => onUpdateSettings({ theme: v ? 'dark' : 'light' })} isDark={isDark} />
        <SettingsSelect label="زبان" value={settings.language} options={[{ value: 'fa', label: 'فارسی' }, { value: 'en', label: 'English' }]} onChange={(v) => onUpdateSettings({ language: v as 'fa' | 'en' })} isDark={isDark} />
        <div className={`flex items-center justify-between px-4 py-3 ${isDark ? 'border-b border-white/5' : 'border-b border-black/5'}`}>
          <div className="flex-1">
            <p className="text-sm persian-text">موتور جستجو</p>
            <p className="text-xs opacity-40 mt-0.5 persian-text">جستجوی ایرانی ماینسورد (مستقل)</p>
          </div>
          <span className="text-xs text-minesword-primary font-medium">✓ فعال</span>
        </div>
      </SettingsSection>

      <SettingsSection title="حریم خصوصی" isDark={isDark}>
        <SettingsToggle label="محافظت در برابر ردیابی" description="مسدود کردن ردیاب‌های شخص ثالث" value={settings.trackingProtection} onChange={(v) => onUpdateSettings({ trackingProtection: v })} isDark={isDark} />
        <SettingsToggle label="کوکی‌های شخص ثالث" description="اجازه به کوکی‌های سایت‌های دیگر" value={settings.thirdPartyCookies} onChange={(v) => onUpdateSettings({ thirdPartyCookies: v })} isDark={isDark} />
        <SettingsToggle label="تله‌متری" description="غیرفعال به صورت پیش‌فرض" value={settings.telemetryEnabled} onChange={(v) => onUpdateSettings({ telemetryEnabled: v })} isDark={isDark} />
      </SettingsSection>

      <SettingsSection title="عملکرد" isDark={isDark}>
        <SettingsSelect label="سطح عملکرد" value={settings.performanceLevel} options={[
          { value: 'low', label: 'کم (ذخیره باتری)' },
          { value: 'balanced', label: 'متعادل' },
          { value: 'high', label: 'بالا' },
        ]} onChange={(v) => onUpdateSettings({ performanceLevel: v as any })} isDark={isDark} />
        <SettingsToggle label="انیمیشن‌ها" description="نمایش انیمیشن‌های رابط کاربری" value={settings.animationsEnabled} onChange={(v) => onUpdateSettings({ animationsEnabled: v })} isDark={isDark} />
      </SettingsSection>

      <SettingsSection title="امنیت" isDark={isDark}>
        <SettingsToggle label="جاوااسکریپت" description="اجرای کدهای جاوااسکریپت" value={settings.javascriptEnabled} onChange={(v) => onUpdateSettings({ javascriptEnabled: v })} isDark={isDark} />
        <SettingsToggle label="نمایش تصاویر" description="بارگذاری تصاویر" value={settings.imageLoading} onChange={(v) => onUpdateSettings({ imageLoading: v })} isDark={isDark} />
      </SettingsSection>

      <SettingsSection title="ذخیره‌سازی" isDark={isDark}>
        <StorageInfoView isDark={isDark} />
      </SettingsSection>

      <SettingsSection title="پاک‌سازی داده‌ها" isDark={isDark}>
        <button
          onClick={() => {
            if (confirm('آیا مطمئن هستید؟ تمام داده‌های مرورگر پاک خواهند شد.')) {
              storageManager.clearAllData();
              // Iranian search engine uses built-in database, no clear needed
              window.location.reload();
            }
          }}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors"
        >
          <Trash2 className="w-5 h-5" />
          <span className="text-sm persian-text">پاک کردن تمام داده‌ها</span>
        </button>
      </SettingsSection>
    </div>
  );
}

function StorageInfoView({ isDark }: { isDark: boolean }) {
  const estimate = storageManager.getStorageEstimate();
  const siteCount = iranianSearchEngine.getSiteCount();
  const bookmarks = storageManager.getBookmarks();
  const history = storageManager.getHistory();
  const savedPages = storageManager.getSavedPages();

  return (
    <div className="px-4 py-3 space-y-2 text-sm">
      <div className={`flex justify-between py-1 ${isDark ? 'border-b border-white/5' : 'border-b border-black/5'}`}>
        <span className="opacity-60 persian-text">نشانک‌ها</span>
        <span>{bookmarks.length}</span>
      </div>
      <div className={`flex justify-between py-1 ${isDark ? 'border-b border-white/5' : 'border-b border-black/5'}`}>
        <span className="opacity-60 persian-text">تاریخچه</span>
        <span>{history.length} مورد</span>
      </div>
      <div className={`flex justify-between py-1 ${isDark ? 'border-b border-white/5' : 'border-b border-black/5'}`}>
        <span className="opacity-60 persian-text">صفحات ذخیره‌شده</span>
        <span>{savedPages.length}</span>
      </div>
      <div className={`flex justify-between py-1 ${isDark ? 'border-b border-white/5' : 'border-b border-black/5'}`}>
        <span className="opacity-60 persian-text">سایت‌های ایرانی</span>
        <span>{siteCount} سایت</span>
      </div>
      <div className="flex justify-between py-1">
        <span className="opacity-60 persian-text">فضای مصرفی</span>
        <span dir="ltr">{(estimate.used / 1024).toFixed(1)} KB</span>
      </div>
    </div>
  );
}

function SettingsSection({ title, children, isDark }: { title: string; children: React.ReactNode; isDark: boolean }) {
  return (
    <div className="mb-6 animate-fade-in">
      <h2 className="text-sm font-medium opacity-60 mb-2 persian-text">{title}</h2>
      <div className={`rounded-2xl overflow-hidden ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'}`}>
        {children}
      </div>
    </div>
  );
}

function SettingsToggle({ label, description, value, onChange, isDark }: {
  label: string; description: string; value: boolean; onChange: (v: boolean) => void; isDark: boolean;
}) {
  return (
    <div className={`flex items-center justify-between px-4 py-3 ${isDark ? 'border-b border-white/5' : 'border-b border-black/5'}`}>
      <div className="flex-1">
        <p className="text-sm persian-text">{label}</p>
        <p className="text-xs opacity-40 mt-0.5 persian-text">{description}</p>
      </div>
      <button
        onClick={() => onChange(!value)}
        className={`w-12 h-7 rounded-full relative transition-colors ${value ? 'bg-minesword-primary' : (isDark ? 'bg-white/20' : 'bg-black/20')}`}
      >
        <div className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-all ${value ? 'right-1' : 'right-6'}`} />
      </button>
    </div>
  );
}

function SettingsSelect({ label, value, options, onChange, isDark }: {
  label: string; value: string; options: { value: string; label: string }[]; onChange: (v: string) => void; isDark: boolean;
}) {
  return (
    <div className={`flex items-center justify-between px-4 py-3 ${isDark ? 'border-b border-white/5' : 'border-b border-black/5'}`}>
      <p className="text-sm persian-text">{label}</p>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={`text-sm px-3 py-1 rounded-lg outline-none ${isDark ? 'bg-minesword-dark text-white' : 'bg-white text-black'} border ${isDark ? 'border-white/10' : 'border-black/10'}`}
      >
        {options.map(opt => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
    </div>
  );
}

function BookmarksView({ isDark, onNavigate }: { isDark: boolean; onNavigate: (url: string) => void }) {
  const bookmarks = storageManager.getBookmarks();

  return (
    <div className="p-4 pb-8">
      <h1 className="text-xl font-bold mb-4 persian-text">نشانک‌ها</h1>
      {bookmarks.length === 0 ? (
        <div className="text-center py-12">
          <Bookmark className="w-12 h-12 mx-auto opacity-20 mb-3" />
          <p className="text-sm opacity-50 persian-text">هنوز نشانکی اضافه نکرده‌اید</p>
          <p className="text-xs opacity-30 mt-1 persian-text">با کلیک روی آیکون نشانک در نوار آدرس، صفحه فعلی را ذخیره کنید</p>
        </div>
      ) : (
        <div className={`rounded-2xl overflow-hidden ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'}`}>
          {bookmarks.map((bm, i) => (
            <div key={bm.id} className={`flex items-center gap-3 px-4 py-3 ${i > 0 ? (isDark ? 'border-t border-white/5' : 'border-t border-black/5') : ''}`}>
              <button onClick={() => onNavigate(bm.url)} className="flex-1 text-right min-w-0">
                <p className="text-sm truncate">{bm.title}</p>
                <p className="text-xs opacity-40 truncate" dir="ltr">{bm.url}</p>
              </button>
              <button
                onClick={() => storageManager.removeBookmark(bm.id)}
                className="touch-target opacity-40 hover:opacity-100 hover:text-red-400 transition-opacity"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function HistoryView({ isDark, onNavigate }: { isDark: boolean; onNavigate: (url: string) => void }) {
  const history = storageManager.getHistory();

  return (
    <div className="p-4 pb-8">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-bold persian-text">تاریخچه</h1>
        {history.length > 0 && (
          <button
            onClick={() => {
              if (confirm('تاریخچه پاک شود؟')) {
                storageManager.clearHistory();
                window.location.reload();
              }
            }}
            className="text-xs text-red-400 hover:text-red-300 persian-text"
          >
            پاک کردن همه
          </button>
        )}
      </div>
      {history.length === 0 ? (
        <div className="text-center py-12">
          <Clock className="w-12 h-12 mx-auto opacity-20 mb-3" />
          <p className="text-sm opacity-50 persian-text">تاریخچه‌ای وجود ندارد</p>
        </div>
      ) : (
        <div className={`rounded-2xl overflow-hidden ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'}`}>
          {history.slice(0, 50).map((entry, i) => (
            <button
              key={entry.id}
              onClick={() => onNavigate(entry.url)}
              className={`w-full flex items-center gap-3 px-4 py-3 text-right ${isDark ? 'hover:bg-white/5' : 'hover:bg-black/5'} transition-colors ${i > 0 ? (isDark ? 'border-t border-white/5' : 'border-t border-black/5') : ''}`}
            >
              <Clock className="w-4 h-4 opacity-40" />
              <div className="flex-1 min-w-0">
                <p className="text-sm truncate">{entry.title || entry.url}</p>
                <p className="text-xs opacity-40 truncate" dir="ltr">{entry.url}</p>
              </div>
              <span className="text-xs opacity-30">
                {new Date(entry.visitedAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function DownloadsView({ isDark }: { isDark: boolean }) {
  const downloads = storageManager.getDownloads();

  return (
    <div className="p-4 pb-8">
      <h1 className="text-xl font-bold mb-4 persian-text">دانلودها</h1>
      {downloads.length === 0 ? (
        <div className="text-center py-12 animate-fade-in">
          <Download className="w-12 h-12 mx-auto opacity-20 mb-3" />
          <p className="text-sm opacity-50 persian-text">هنوز فایلی دانلود نشده است</p>
          <p className="text-xs opacity-30 mt-2 persian-text leading-relaxed max-w-xs mx-auto">
            مدیر دانلود در این نسخه از مرورگر از طریق API واقعی مرورگر کار می‌کند.
            فایل‌های دانلود شده در اینجا نمایش داده خواهند شد.
          </p>
        </div>
      ) : (
        <div className={`rounded-2xl overflow-hidden ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'}`}>
          {downloads.map((dl, i) => (
            <div key={dl.id} className={`flex items-center gap-3 px-4 py-3 ${i > 0 ? (isDark ? 'border-t border-white/5' : 'border-t border-black/5') : ''}`}>
              <FileText className="w-5 h-5 opacity-40" />
              <div className="flex-1 min-w-0">
                <p className="text-sm truncate">{dl.filename}</p>
                <p className="text-xs opacity-40">
                  {(dl.size / 1024 / 1024).toFixed(1)} MB • {dl.status === 'completed' ? 'تکمیل شده' : dl.status}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function TabsView({ isDark, tabs, activeTabId, onSelectTab, onCloseTab, onCreateTab }: {
  isDark: boolean;
  tabs: Tab[];
  activeTabId: string;
  onSelectTab: (id: string) => void;
  onCloseTab: (id: string) => void;
  onCreateTab: (isPrivate?: boolean) => void;
}) {
  return (
    <div className="p-4 pb-8">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-bold persian-text">زبانه‌ها ({tabs.length})</h1>
        <button onClick={() => onCreateTab()} className="flex items-center gap-1 px-3 py-1.5 bg-minesword-primary text-white rounded-lg text-sm">
          <Plus className="w-4 h-4" />
          <span>جدید</span>
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {tabs.map((tab) => (
          <motion.div
            key={tab.id}
            layout
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`relative rounded-xl overflow-hidden border-2 transition-colors ${
              tab.id === activeTabId ? 'border-minesword-primary' : (isDark ? 'border-white/10' : 'border-black/10')
            } ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'}`}
          >
            <button onClick={() => onSelectTab(tab.id)} className="w-full p-3 text-right">
              <div className="flex items-center gap-2 mb-2">
                {tab.isPrivate && <EyeOff className="w-3 h-3 text-minesword-accent" />}
                <p className="text-xs font-medium truncate flex-1">{tab.title || 'صفحه اصلی'}</p>
              </div>
              <p className="text-[10px] opacity-40 truncate" dir="ltr">
                {tab.url || 'minesword://home'}
              </p>
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); onCloseTab(tab.id); }}
              className="absolute top-1 left-1 w-6 h-6 flex items-center justify-center rounded-full bg-black/20 hover:bg-black/40 transition-colors"
            >
              <X className="w-3 h-3" />
            </button>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function AboutView({ isDark }: { isDark: boolean }) {
  const siteCount = iranianSearchEngine.getSiteCount();

  return (
    <div className="p-4 pb-8">
      <div className="text-center py-8 animate-fade-in">
        <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-minesword-primary to-minesword-accent flex items-center justify-center shadow-lg">
          <span className="text-3xl font-bold text-white">M</span>
        </div>
        <h1 className="text-2xl font-bold persian-text">Minesword Browser</h1>
        <p className="text-sm opacity-60 mt-1 persian-text">مرورگر ماینسورد</p>
        <p className="text-xs opacity-40 mt-2">Version 0.2.0 (Alpha)</p>
      </div>

      <div className={`rounded-2xl p-4 mb-4 ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'} animate-fade-in`}>
        <h2 className="font-medium mb-3 persian-text">اطلاعات فنی</h2>
        <div className="space-y-2 text-sm">
          <InfoRow label="نسخه مرورگر" value="0.3.0-alpha" isDark={isDark} />
          <InfoRow label="موتور رندر" value="WebView (سندباکس‌شده)" isDark={isDark} />
          <InfoRow label="موتور جستجو" value={`جستجوی ایرانی ماینسورد (${siteCount} سایت)`} isDark={isDark} />
          <InfoRow label="پشتیبانی RTL" value="کامل" isDark={isDark} />
          <InfoRow label="زبان اصلی" value="فارسی" isDark={isDark} />
          <InfoRow label="حالت نت ملی" value="پشتیبانی کامل" isDark={isDark} />
        </div>
      </div>

      <div className={`rounded-2xl p-4 mb-4 ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'} animate-fade-in`}>
        <h2 className="font-medium mb-3 persian-text">وضعیت واقعی ویژگی‌ها</h2>
        <div className="space-y-2 text-sm persian-text">
          <StatusRow status="working" text="ناوبری واقعی URL" />
          <StatusRow status="working" text="تشخیص شبکه (آنلاین/محلی/آفلاین)" />
          <StatusRow status="working" text="نرمال‌سازی متن فارسی" />
          <StatusRow status="working" text="ذخیره/بازیابی نشانک‌ها و تاریخچه" />
          <StatusRow status="working" text="موتور جستجوی ایرانی مستقل" />
          <StatusRow status="working" text="پشتیبانی کامل از نت ملی" />
          <StatusRow status="working" text="ذخیره صفحات برای استفاده آفلاین" />
          <StatusRow status="working" text="مدیریت زبانه‌ها با حالت خصوصی" />
          <StatusRow status="partial" text="سندباکس امنیتی iframe" />
          <StatusRow status="partial" text="تشخیص خطای بارگذاری" />
          <StatusRow status="planned" text="مدیر دانلود پیشرفته" />
          <StatusRow status="planned" text="موتور رندر مستقل" />
        </div>
      </div>

      <div className={`rounded-2xl p-4 ${isDark ? 'bg-minesword-primary/10 border border-minesword-primary/20' : 'bg-minesword-primary/5 border border-minesword-primary/10'} animate-fade-in`}>
        <h2 className="font-medium mb-2 text-minesword-primary persian-text">تیم توسعه</h2>
        <p className="text-sm persian-text">Minesword Team</p>
        <p className="text-xs opacity-50 mt-2 persian-text leading-relaxed">
          مرورگر ماینسورد یک مرورگر ایرانی مستقل است که در زمان نت ملی نیز به طور کامل کار می‌کند.
          موتور جستجوی ایرانی ماینسورد شامل {siteCount} سایت ایرانی معتبر است و بدون نیاز به اینترنت بین‌الملل کار می‌کند.
          این مرورگر از WebView سندباکس‌شده برای رندر صفحات استفاده می‌کند.
        </p>
      </div>
    </div>
  );
}

function InfoRow({ label, value, isDark }: { label: string; value: string; isDark: boolean }) {
  return (
    <div className={`flex justify-between py-1 ${isDark ? 'border-b border-white/5' : 'border-b border-black/5'}`}>
      <span className="opacity-60 persian-text">{label}</span>
      <span className="text-xs" dir="ltr">{value}</span>
    </div>
  );
}

function StatusRow({ status, text }: { status: 'working' | 'partial' | 'planned'; text: string }) {
  const colors = {
    working: 'text-green-400',
    partial: 'text-yellow-400',
    planned: 'text-minesword-text-muted-dark',
  };
  const labels = {
    working: '✓',
    partial: '◐',
    planned: '○',
  };
  return (
    <div className="flex items-center gap-2">
      <span className={`${colors[status]} text-xs`}>{labels[status]}</span>
      <span className={`text-xs ${status === 'planned' ? 'opacity-40' : 'opacity-70'}`}>{text}</span>
    </div>
  );
}

function DiagnosticsView({ isDark }: { isDark: boolean }) {
  const [compatReport, setCompatReport] = useState<CompatibilityReport | null>(null);
  const [perfMetrics, setPerfMetrics] = useState<PerformanceMetrics>({});
  const [running, setRunning] = useState(false);

  const runTests = async () => {
    setRunning(true);
    const report = await compatibilityTestSuite.runAllTests();
    setCompatReport(report);
    setPerfMetrics(performanceMonitor.getCurrentMetrics());
    setRunning(false);
  };

  useEffect(() => {
    runTests();
  }, []);

  const errorStats = errorRecoveryManager.getStats();
  const netStats = networkClient.getStats();
  const cacheStats = networkClient.getCacheStats();

  return (
    <div className="p-4 pb-8">
      <h1 className="text-xl font-bold mb-4 persian-text">عیب‌یابی و آمار</h1>

      {/* Compatibility */}
      <div className={`rounded-2xl p-4 mb-4 ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'}`}>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-medium persian-text">سازگاری مرورگر</h2>
          <button
            onClick={runTests}
            disabled={running}
            className="text-xs px-3 py-1 bg-minesword-primary text-white rounded-lg disabled:opacity-50"
          >
            {running ? 'در حال اجرا...' : 'اجرای مجدد'}
          </button>
        </div>
        
        {compatReport ? (
          <>
            <div className="flex items-center gap-4 mb-3">
              <div className="text-center">
                <div className="text-2xl font-bold text-minesword-primary">{compatReport.summary.overallScore}%</div>
                <div className="text-xs opacity-50 persian-text">امتیاز کلی</div>
              </div>
              <div className="flex-1 grid grid-cols-3 gap-2">
                <div className="text-center">
                  <div className="text-lg font-bold text-green-400">{compatReport.summary.full}</div>
                  <div className="text-xs opacity-50">کامل</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-yellow-400">{compatReport.summary.partial}</div>
                  <div className="text-xs opacity-50">جزئی</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-red-400">{compatReport.summary.none}</div>
                  <div className="text-xs opacity-50">عدم پشتیبانی</div>
                </div>
              </div>
            </div>
            
            <div className="space-y-1 max-h-60 overflow-y-auto">
              {Array.from(compatReport.results.entries()).map(([id, result]) => (
                <div key={id} className={`flex items-center justify-between py-1 text-xs ${isDark ? 'border-b border-white/5' : 'border-b border-black/5'}`}>
                  <span className="opacity-70 persian-text truncate flex-1">{id}</span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] ${
                    result.supported === 'full' ? 'bg-green-400/20 text-green-400' :
                    result.supported === 'partial' ? 'bg-yellow-400/20 text-yellow-400' :
                    'bg-red-400/20 text-red-400'
                  }`}>
                    {result.supported === 'full' ? '✓' : result.supported === 'partial' ? '◐' : '✗'}
                    {result.score !== undefined ? ` ${Math.round(result.score)}%` : ''}
                  </span>
                </div>
              ))}
            </div>
          </>
        ) : (
          <p className="text-sm opacity-50 persian-text">در حال اجرای تست‌ها...</p>
        )}
      </div>

      {/* Performance */}
      <div className={`rounded-2xl p-4 mb-4 ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'}`}>
        <h2 className="font-medium mb-3 persian-text">عملکرد</h2>
        <div className="space-y-2 text-sm">
          <InfoRow label="فریم ریت میانگین" value={`${perfMetrics.averageFps || 0} fps`} isDark={isDark} />
          <InfoRow label="حافظه مصرفی" value={`${perfMetrics.jsHeapUsedMB || 0} MB`} isDark={isDark} />
          <InfoRow label="حد حافظه" value={`${perfMetrics.jsHeapLimitMB || 0} MB`} isDark={isDark} />
          <InfoRow label="تسک‌های طولانی" value={`${perfMetrics.longTasks || 0}`} isDark={isDark} />
          <InfoRow label="زمان فعالیت" value={`${performanceMonitor.getUptime().toFixed(0)} ثانیه`} isDark={isDark} />
        </div>
      </div>

      {/* Network */}
      <div className={`rounded-2xl p-4 mb-4 ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'}`}>
        <h2 className="font-medium mb-3 persian-text">شبکه</h2>
        <div className="space-y-2 text-sm">
          <InfoRow label="درخواست‌ها" value={`${netStats.requestCount}`} isDark={isDark} />
          <InfoRow label="خطاها" value={`${netStats.errorCount} (${(netStats.errorRate * 100).toFixed(1)}%)`} isDark={isDark} />
          <InfoRow label="حجم داده" value={`${(netStats.totalBytes / 1024 / 1024).toFixed(2)} MB`} isDark={isDark} />
          <InfoRow label="کش" value={`${cacheStats.entries} مورد (${(cacheStats.size / 1024).toFixed(1)} KB)`} isDark={isDark} />
        </div>
      </div>

      {/* Errors */}
      <div className={`rounded-2xl p-4 mb-4 ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'}`}>
        <h2 className="font-medium mb-3 persian-text">خطاها و بازیابی</h2>
        <div className="space-y-2 text-sm">
          <InfoRow label="کل خطاها" value={`${errorStats.totalErrors}`} isDark={isDark} />
          <InfoRow label="خرابی زبانه" value={`${errorStats.crashCount}`} isDark={isDark} />
          <InfoRow label="خطای اخیر (ساعت)" value={`${errorStats.recentErrors}`} isDark={isDark} />
          <InfoRow label="وضعیت" value={errorRecoveryManager.isDegraded() ? '⚠️ کاهش عملکرد' : '✓ عادی'} isDark={isDark} />
        </div>
        
        {errorRecoveryManager.getRecommendations().length > 0 && (
          <div className="mt-3 p-2 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
            {errorRecoveryManager.getRecommendations().map((rec, i) => (
              <p key={i} className="text-xs text-yellow-400 persian-text">{rec}</p>
            ))}
          </div>
        )}
      </div>

      {/* User Agent */}
      <div className={`rounded-2xl p-4 ${isDark ? 'bg-minesword-dark-card' : 'bg-minesword-light-card'}`}>
        <h2 className="font-medium mb-2 persian-text">اطلاعات سیستم</h2>
        <p className="text-xs opacity-50 break-all" dir="ltr">{navigator.userAgent}</p>
      </div>
    </div>
  );
}
