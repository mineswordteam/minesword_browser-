/**
 * Minesword Browser Engine - Performance Monitor
 * 
 * Tracks real performance metrics:
 * - Startup time
 * - Page load time
 * - Memory usage
 * - Frame rate
 * - Network performance
 * - Tab switching time
 * 
 * Uses the Performance API for accurate measurements.
 * Does NOT simulate metrics - all values are real.
 */

export interface PerformanceMetrics {
  // Startup
  coldStartMs?: number;
  warmStartMs?: number;
  timeToInteractive?: number;
  
  // Navigation
  pageLoadMs?: number;
  firstContentfulPaint?: number;
  largestContentfulPaint?: number;
  domContentLoaded?: number;
  domComplete?: number;
  
  // Memory
  jsHeapUsedMB?: number;
  jsHeapTotalMB?: number;
  jsHeapLimitMB?: number;
  
  // Rendering
  averageFps?: number;
  droppedFrames?: number;
  longTasks?: number;
  
  // Network
  totalRequests?: number;
  totalBytesMB?: number;
  cacheHitRate?: number;
  
  // Custom
  tabSwitchMs?: number;
  searchTimeMs?: number;
}

export interface PerformanceSnapshot {
  timestamp: number;
  metrics: PerformanceMetrics;
  label?: string;
}

export type PerformanceLevel = 'low' | 'balanced' | 'high';

class PerformanceMonitor {
  private snapshots: PerformanceSnapshot[] = [];
  private maxSnapshots = 100;
  private frameCount = 0;
  private lastFrameTime = 0;
  private fpsHistory: number[] = [];
  private observer: PerformanceObserver | null = null;
  private longTaskCount = 0;
  private startTime = performance.now();
  private performanceLevel: PerformanceLevel = 'balanced';

  constructor() {
    this.initialize();
  }

  private initialize(): void {
    // Set up frame rate monitoring
    this.startFPSMonitoring();
    
    // Set up long task monitoring
    this.startLongTaskMonitoring();
    
    // Load performance level from settings
    try {
      const settings = JSON.parse(localStorage.getItem('minesword_settings') || '{}');
      this.performanceLevel = settings.performanceLevel || 'balanced';
    } catch {
      // Default to balanced
    }
  }

  /**
   * Monitor frame rate using requestAnimationFrame
   */
  private startFPSMonitoring(): void {
    let lastTime = performance.now();
    
    const measureFrame = (currentTime: number) => {
      const delta = currentTime - lastTime;
      lastTime = currentTime;
      
      if (delta > 0) {
        const fps = 1000 / delta;
        this.fpsHistory.push(fps);
        
        // Keep only last 60 frames
        if (this.fpsHistory.length > 60) {
          this.fpsHistory.shift();
        }
      }
      
      this.frameCount++;
      requestAnimationFrame(measureFrame);
    };
    
    requestAnimationFrame(measureFrame);
  }

  /**
   * Monitor long tasks using PerformanceObserver
   */
  private startLongTaskMonitoring(): void {
    if (typeof PerformanceObserver === 'undefined') return;
    
    try {
      this.observer = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (entry.duration > 50) { // Long task threshold
            this.longTaskCount++;
          }
        }
      });
      
      this.observer.observe({ entryTypes: ['longtask'] });
    } catch {
      // longtask not supported in all browsers
    }
  }

  /**
   * Mark a performance event
   */
  mark(label: string): void {
    if (typeof performance.mark === 'function') {
      performance.mark(`minesword-${label}`);
    }
  }

  /**
   * Measure time between two marks
   */
  measure(label: string, startMark: string, endMark: string): number | undefined {
    try {
      performance.measure(`minesword-${label}`, `minesword-${startMark}`, `minesword-${endMark}`);
      const entries = performance.getEntriesByName(`minesword-${label}`);
      if (entries.length > 0) {
        return entries[entries.length - 1].duration;
      }
    } catch {
      // Measurement failed
    }
    return undefined;
  }

  /**
   * Record a page load
   */
  recordPageLoad(url: string, loadTimeMs: number): void {
    const metrics = this.getCurrentMetrics();
    metrics.pageLoadMs = loadTimeMs;
    
    this.addSnapshot({
      timestamp: Date.now(),
      metrics,
      label: `page-load: ${url}`,
    });
  }

  /**
   * Record a tab switch
   */
  recordTabSwitch(switchTimeMs: number): void {
    this.addSnapshot({
      timestamp: Date.now(),
      metrics: { tabSwitchMs: switchTimeMs },
      label: 'tab-switch',
    });
  }

  /**
   * Record a search operation
   */
  recordSearch(searchTimeMs: number): void {
    this.addSnapshot({
      timestamp: Date.now(),
      metrics: { searchTimeMs },
      label: 'search',
    });
  }

  /**
   * Get current performance metrics
   */
  getCurrentMetrics(): PerformanceMetrics {
    const metrics: PerformanceMetrics = {};

    // Memory (Chrome-only API)
    if ((performance as any).memory) {
      const mem = (performance as any).memory;
      metrics.jsHeapUsedMB = Math.round(mem.usedJSHeapSize / 1024 / 1024 * 100) / 100;
      metrics.jsHeapTotalMB = Math.round(mem.totalJSHeapSize / 1024 / 1024 * 100) / 100;
      metrics.jsHeapLimitMB = Math.round(mem.jsHeapSizeLimit / 1024 / 1024 * 100) / 100;
    }

    // Frame rate
    if (this.fpsHistory.length > 0) {
      const avg = this.fpsHistory.reduce((a, b) => a + b, 0) / this.fpsHistory.length;
      metrics.averageFps = Math.round(avg);
    }

    // Long tasks
    metrics.longTasks = this.longTaskCount;

    // Navigation timing (if available)
    if (typeof performance.getEntriesByType === 'function') {
      const navEntries = performance.getEntriesByType('navigation');
      if (navEntries.length > 0) {
        const nav = navEntries[0] as PerformanceNavigationTiming;
        metrics.domContentLoaded = Math.round(nav.domContentLoadedEventEnd - nav.startTime);
        metrics.domComplete = Math.round(nav.domComplete - nav.startTime);
      }
    }

    return metrics;
  }

  /**
   * Get navigation timing for current page
   */
  getNavigationTiming(): {
    dns: number;
    connect: number;
    tls: number;
    request: number;
    response: number;
    domInteractive: number;
    domComplete: number;
    loadEvent: number;
  } | null {
    if (typeof performance.getEntriesByType !== 'function') return null;
    
    const entries = performance.getEntriesByType('navigation');
    if (entries.length === 0) return null;
    
    const nav = entries[0] as PerformanceNavigationTiming;
    
    return {
      dns: Math.round(nav.domainLookupEnd - nav.domainLookupStart),
      connect: Math.round(nav.connectEnd - nav.connectStart),
      tls: Math.round(nav.secureConnectionStart > 0 ? nav.connectEnd - nav.secureConnectionStart : 0),
      request: Math.round(nav.responseStart - nav.requestStart),
      response: Math.round(nav.responseEnd - nav.responseStart),
      domInteractive: Math.round(nav.domInteractive - nav.startTime),
      domComplete: Math.round(nav.domComplete - nav.startTime),
      loadEvent: Math.round(nav.loadEventEnd - nav.startTime),
    };
  }

  /**
   * Add a snapshot to history
   */
  private addSnapshot(snapshot: PerformanceSnapshot): void {
    this.snapshots.push(snapshot);
    
    // Keep only recent snapshots
    if (this.snapshots.length > this.maxSnapshots) {
      this.snapshots = this.snapshots.slice(-this.maxSnapshots);
    }
  }

  /**
   * Get performance history
   */
  getHistory(): PerformanceSnapshot[] {
    return [...this.snapshots];
  }

  /**
   * Get average FPS
   */
  getAverageFPS(): number {
    if (this.fpsHistory.length === 0) return 0;
    return Math.round(this.fpsHistory.reduce((a, b) => a + b, 0) / this.fpsHistory.length);
  }

  /**
   * Get uptime in seconds
   */
  getUptime(): number {
    return (performance.now() - this.startTime) / 1000;
  }

  /**
   * Set performance level
   */
  setPerformanceLevel(level: PerformanceLevel): void {
    this.performanceLevel = level;
  }

  /**
   * Get current performance level
   */
  getPerformanceLevel(): PerformanceLevel {
    return this.performanceLevel;
  }

  /**
   * Get performance recommendations based on current metrics
   */
  getRecommendations(): string[] {
    const recommendations: string[] = [];
    const metrics = this.getCurrentMetrics();

    // Memory warnings
    if (metrics.jsHeapUsedMB && metrics.jsHeapLimitMB) {
      const usageRatio = metrics.jsHeapUsedMB / metrics.jsHeapLimitMB;
      if (usageRatio > 0.8) {
        recommendations.push('High memory usage detected. Consider closing some tabs.');
      }
    }

    // FPS warnings
    if (metrics.averageFps && metrics.averageFps < 30) {
      recommendations.push('Low frame rate detected. Consider reducing animations or closing tabs.');
    }

    // Long task warnings
    if (metrics.longTasks && metrics.longTasks > 10) {
      recommendations.push('Multiple long tasks detected. Page may feel unresponsive.');
    }

    return recommendations;
  }

  /**
   * Clear all recorded data
   */
  clear(): void {
    this.snapshots = [];
    this.fpsHistory = [];
    this.longTaskCount = 0;
    this.startTime = performance.now();
  }

  /**
   * Cleanup
   */
  destroy(): void {
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
    }
  }
}

// Singleton instance
export const performanceMonitor = new PerformanceMonitor();
