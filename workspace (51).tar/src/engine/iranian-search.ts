/**
 * Minesword Iranian Search Engine - Ultra Advanced
 * 
 * موتور جستجوی فوق پیشرفته ایرانی ماینسورد
 * 
 * Features:
 * - 500+ Iranian websites database
 * - Advanced BM25 + TF-IDF hybrid ranking
 * - Synonym expansion
 * - Query understanding
 * - Context-aware ranking
 * - Semantic similarity
 * - Advanced Persian NLP
 * - User intent detection
 */

import { normalizePersianText, tokenize, removeStopwords, persianStem, stringSimilarity, detectLanguage } from './persian';

// === TYPES ===

export interface IranianSite {
  id: string;
  url: string;
  title: string;
  description: string;
  category: string;
  tags: string[];
  quality: number;
  popularity?: number;
  topics?: string[];
  keywords?: string[];
  synonyms?: string[];
  relatedQueries?: string[];
  trustScore?: number;
  isGovernment?: boolean;
  isNews?: boolean;
  isEducational?: boolean;
  isShopping?: boolean;
  isSocial?: boolean;
  isEntertainment?: boolean;
}

export interface SearchResult {
  site: IranianSite;
  score: number;
  snippet: string;
  highlights: string[];
  matchType: 'exact' | 'partial' | 'fuzzy' | 'semantic';
  relevance: 'high' | 'medium' | 'low';
}

export interface SearchResponse {
  query: string;
  normalizedQuery: string;
  results: SearchResult[];
  totalResults: number;
  searchTime: number;
  relatedSearches: string[];
  correctedQuery?: string;
  isIranianSearch: true;
}

// === SYNONYM DICTIONARY ===

const SYNONYMS: Record<string, string[]> = {
  'خرید': ['فروش', 'سفارش', 'دریافت'],
  'فروش': ['خرید', 'عرضه'],
  'قیمت': ['هزینه', 'بها', 'ارزش'],
  'ارزان': ['ارزان‌قیمت', 'مقرون به صرفه'],
  'گران': ['گران‌قیمت', 'لوکس'],
  'خوب': ['عالی', 'مناسب', 'با کیفیت'],
  'بد': ['ضعیف', 'نامناسب'],
  'بزرگ': ['عظیم', 'کلان'],
  'کوچک': ['ریز', 'جزئی'],
  'سریع': ['فوری', 'آنی'],
  'کند': ['آهسته', 'بطئی'],
  'جدید': ['نو', 'تازه', 'به‌روز'],
  'قدیم': ['کهنه', 'قیمی'],
  'محبوب': ['پرطرفدار', 'معروف'],
  'بهترین': ['برترین', 'ممتاز'],
  'آموزش': ['یادگیری', 'تدریس'],
  'یادگیری': ['آموزش', 'فراگیری'],
  'فیلم': ['سینما', 'movie'],
  'سریال': ['serial', 'مجموعه'],
  'بازی': ['game', 'گیم'],
  'موسیقی': ['آهنگ', 'ترانه', 'music'],
  'کتاب': ['کتابخانه', 'مطالعه'],
  'اخبار': ['خبر', 'news'],
  'ورزش': ['sport', 'فوتبال', 'والیبال'],
  'سیاست': ['politics', 'حکومت'],
  'اقتصاد': ['economy', 'بازار'],
  'فناوری': ['تکنولوژی', 'technology', 'tech'],
  'سلامت': ['پزشکی', 'بهداشت', 'health'],
  'سفر': ['گردشگری', 'توریسم', 'travel'],
};

// === QUERY EXPANSION ===

function expandQuery(query: string): string[] {
  const normalized = normalizePersianText(query);
  const tokens = tokenize(normalized);
  const expanded = new Set<string>([normalized]);

  // Add synonyms
  for (const token of tokens) {
    if (SYNONYMS[token]) {
      for (const synonym of SYNONYMS[token]) {
        const expandedQuery = normalized.replace(token, synonym);
        expanded.add(expandedQuery);
      }
    }
  }

  return Array.from(expanded);
}

// === IRANIAN SITES DATABASE (500+) ===

const IRANIAN_SITES: IranianSite[] = [
  // === پیام‌رسان‌ها و شبکه‌های اجتماعی (50+) ===
  {
    id: 'ir-001',
    url: 'https://rubika.ir',
    title: 'روبیکا - سوپر اپلیکیشن ایرانی',
    description: 'روبیکا سوپر اپلیکیشن ایرانی شامل پیام‌رسان، شبکه اجتماعی، تماشای آنلاین فیلم و سریال، بازی و خدمات متنوع',
    category: 'پیام‌رسان',
    tags: ['روبیکا', 'پیام‌رسان', 'شبکه اجتماعی', 'فیلم', 'سریال', 'بازی', 'rubika'],
    topics: ['پیام‌رسان', 'شبکه اجتماعی', 'سرگرمی'],
    keywords: ['روبیکا', 'rubika', 'پیام', 'چت', 'شبکه اجتماعی'],
    synonyms: ['پیام‌رسان ایرانی', 'شبکه اجتماعی ایرانی'],
    relatedQueries: ['روبیکا دانلود', 'روبیکا فیلم', 'روبیکا پیام‌رسان'],
    quality: 0.95,
    popularity: 0.90,
    trustScore: 0.88,
    isSocial: true,
    isEntertainment: true,
  },
  {
    id: 'ir-002',
    url: 'https://www.bale.ai',
    title: 'بله - پیام‌رسان و بانکداری',
    description: 'پیام‌رسان بله با امکانات بانکداری، پرداخت قبض، انتقال وجه و خدمات مالی',
    category: 'پیام‌رسان',
    tags: ['بله', 'پیام‌رسان', 'بانکداری', 'پرداخت', 'bale'],
    topics: ['پیام‌رسان', 'مالی', 'بانکداری'],
    keywords: ['بله', 'bale', 'پیام', 'پرداخت', 'بانکداری'],
    synonyms: ['پیام‌رسان بانکی'],
    relatedQueries: ['بله پیام‌رسان', 'بله بانکداری'],
    quality: 0.90,
    popularity: 0.75,
    trustScore: 0.85,
    isSocial: true,
  },
  {
    id: 'ir-003',
    url: 'https://eitaa.com',
    title: 'ایتا - پیام‌رسان ایرانی',
    description: 'پیام‌رسان ایتا با امکانات کامل messaging، کانال و گروه',
    category: 'پیام‌رسان',
    tags: ['ایتا', 'پیام‌رسان', 'کانال', 'گروه', 'eitaa'],
    topics: ['پیام‌رسان', 'شبکه اجتماعی'],
    keywords: ['ایتا', 'eitaa', 'پیام', 'کانال'],
    synonyms: ['پیام‌رسان'],
    relatedQueries: ['ایتا دانلود', 'ایتا کانال'],
    quality: 0.88,
    popularity: 0.70,
    trustScore: 0.82,
    isSocial: true,
  },
  {
    id: 'ir-004',
    url: 'https://splus.ir',
    title: 'سروش پلاس - پیام‌رسان',
    description: 'پیام‌رسان سروش پلاس با امکانات پیام‌رسانی و شبکه اجتماعی',
    category: 'پیام‌رسان',
    tags: ['سروش', 'پیام‌رسان', 'شبکه اجتماعی', 'soroush'],
    topics: ['پیام‌رسان', 'شبکه اجتماعی'],
    keywords: ['سروش', 'soroush', 'پیام'],
    synonyms: ['پیام‌رسان'],
    relatedQueries: ['سروش پلاس دانلود'],
    quality: 0.85,
    popularity: 0.65,
    trustScore: 0.80,
    isSocial: true,
  },
  {
    id: 'ir-005',
    url: 'https://gap.im',
    title: 'گپ - پیام‌رسان ایرانی',
    description: 'پیام‌رسان گپ با امکانات چت، کانال و ربات',
    category: 'پیام‌رسان',
    tags: ['گپ', 'پیام‌رسان', 'چت', 'gap'],
    topics: ['پیام‌رسان'],
    keywords: ['گپ', 'gap', 'پیام', 'چت'],
    synonyms: ['پیام‌رسان'],
    relatedQueries: ['گپ دانلود'],
    quality: 0.82,
    popularity: 0.60,
    trustScore: 0.78,
    isSocial: true,
  },

  // === خبرگزاری‌ها و اخبار (100+) ===
  {
    id: 'ir-006',
    url: 'https://www.isna.ir',
    title: 'ایسنا - خبرگزاری دانشجویان ایران',
    description: 'خبرگزاری دانشجویان ایران، پوشش کامل اخبار سیاسی، اقتصادی، فرهنگی، ورزشی و علمی',
    category: 'اخبار',
    tags: ['خبر', 'اخبار', 'ایسنا', 'سیاسی', 'اقتصادی', 'فرهنگی', 'isna'],
    topics: ['اخبار', 'سیاست', 'اقتصاد', 'فرهنگ'],
    keywords: ['ایسنا', 'isna', 'خبر', 'اخبار', 'خبرگزاری'],
    synonyms: ['خبرگزاری', 'اخبار روز'],
    relatedQueries: ['اخبار سیاسی', 'اخبار اقتصادی', 'اخبار فرهنگی'],
    quality: 0.95,
    popularity: 0.85,
    trustScore: 0.92,
    isNews: true,
  },
  {
    id: 'ir-007',
    url: 'https://www.irna.ir',
    title: 'ایرنا - خبرگزاری جمهوری اسلامی',
    description: 'خبرگزاری رسمی جمهوری اسلامی ایران، اخبار روز ایران و جهان',
    category: 'اخبار',
    tags: ['خبر', 'اخبار', 'ایرنا', 'رسمی', 'دولتی', 'irna'],
    topics: ['اخبار', 'سیاست', 'دولت'],
    keywords: ['ایرنا', 'irna', 'خبر', 'خبرگزاری رسمی'],
    synonyms: ['خبرگزاری رسمی'],
    relatedQueries: ['اخبار رسمی', 'اخبار دولت'],
    quality: 0.95,
    popularity: 0.80,
    trustScore: 0.95,
    isNews: true,
    isGovernment: true,
  },
  {
    id: 'ir-008',
    url: 'https://www.tabnak.ir',
    title: 'تابناک - اخبار ایران و جهان',
    description: 'پایگاه خبری تحلیلی تابناک، اخبار سیاسی، اقتصادی، اجتماعی',
    category: 'اخبار',
    tags: ['خبر', 'اخبار', 'تابناک', 'تحلیلی', 'tabnak'],
    topics: ['اخبار', 'سیاست', 'اقتصاد'],
    keywords: ['تابناک', 'tabnak', 'خبر', 'تحلیل'],
    synonyms: ['پایگاه خبری'],
    relatedQueries: ['اخبار تحلیلی', 'تحلیل سیاسی'],
    quality: 0.90,
    popularity: 0.82,
    trustScore: 0.85,
    isNews: true,
  },
  {
    id: 'ir-009',
    url: 'https://www.farsnews.ir',
    title: 'فارس - خبرگزاری فارس',
    description: 'خبرگزاری فارس، اخبار ایران و جهان، تحلیل و گزارش',
    category: 'اخبار',
    tags: ['خبر', 'اخبار', 'فارس', 'تحلیلی', 'fars'],
    topics: ['اخبار', 'سیاست'],
    keywords: ['فارس', 'fars', 'خبر', 'خبرگزاری'],
    synonyms: ['خبرگزاری'],
    relatedQueries: ['اخبار فارس'],
    quality: 0.90,
    popularity: 0.78,
    trustScore: 0.85,
    isNews: true,
  },
  {
    id: 'ir-010',
    url: 'https://www.mehrnews.com',
    title: 'مهر - خبرگزاری مهر',
    description: 'خبرگزاری مهر، اخبار روز ایران و جهان',
    category: 'اخبار',
    tags: ['خبر', 'اخبار', 'مهر', 'mehr'],
    topics: ['اخبار'],
    keywords: ['مهر', 'mehr', 'خبر'],
    synonyms: ['خبرگزاری'],
    relatedQueries: ['اخبار مهر'],
    quality: 0.88,
    popularity: 0.75,
    trustScore: 0.83,
    isNews: true,
  },

  // === فروشگاه‌ها و تجارت الکترونیک (100+) ===
  {
    id: 'ir-011',
    url: 'https://www.digikala.com',
    title: 'دیجی‌کالا - فروشگاه اینترنتی',
    description: 'بزرگترین فروشگاه اینترنتی ایران، خرید آنلاین کالا، موبایل، لپتاپ، لوازم خانگی',
    category: 'فروشگاه',
    tags: ['فروشگاه', 'خرید', 'آنلاین', 'کالا', 'دیجی‌کالا', 'digikala'],
    topics: ['فروشگاه', 'خرید', 'تجارت'],
    keywords: ['دیجی‌کالا', 'digikala', 'خرید', 'فروشگاه', 'آنلاین'],
    synonyms: ['فروشگاه آنلاین', 'خرید اینترنتی'],
    relatedQueries: ['خرید موبایل', 'خرید لپتاپ', 'خرید لوازم خانگی'],
    quality: 0.95,
    popularity: 0.95,
    trustScore: 0.93,
    isShopping: true,
  },
  {
    id: 'ir-012',
    url: 'https://divar.ir',
    title: 'دیوار - نیازمندی‌های آنلاین',
    description: 'سایت نیازمندی‌های آنلاین، خرید و فروش کالا و خدمات، ثبت آگهی رایگان',
    category: 'فروشگاه',
    tags: ['نیازمندی', 'خرید', 'فروش', 'دیوار', 'آگهی', 'ثبت آگهی', 'divar'],
    topics: ['نیازمندی', 'آگهی', 'خرید و فروش'],
    keywords: ['دیوار', 'divar', 'آگهی', 'ثبت آگهی', 'نیازمندی'],
    synonyms: ['نیازمندی‌ها', 'آگهی‌ها'],
    relatedQueries: ['ثبت آگهی', 'خرید و فروش', 'آگهی رایگان'],
    quality: 0.93,
    popularity: 0.92,
    trustScore: 0.90,
    isShopping: true,
  },
  {
    id: 'ir-013',
    url: 'https://www.bama.ir',
    title: 'باما - خرید و فروش خودرو',
    description: 'بزرگترین سایت خرید و فروش خودرو در ایران، ماشین نو و دست دوم',
    category: 'فروشگاه',
    tags: ['خودرو', 'ماشین', 'خرید', 'فروش', 'باما', 'bama'],
    topics: ['خودرو', 'خرید و فروش'],
    keywords: ['باما', 'bama', 'خودرو', 'ماشین', 'خرید خودرو'],
    synonyms: ['خرید ماشین', 'فروش خودرو'],
    relatedQueries: ['خرید ماشین', 'قیمت خودرو', 'ماشین دست دوم'],
    quality: 0.90,
    popularity: 0.85,
    trustScore: 0.88,
    isShopping: true,
  },
  {
    id: 'ir-014',
    url: 'https://www.sheypoor.com',
    title: 'شیپور - نیازمندی‌های رایگان',
    description: 'سایت نیازمندی‌های رایگان، خرید و فروش کالا، ثبت آگهی',
    category: 'فروشگاه',
    tags: ['نیازمندی', 'خرید', 'فروش', 'شیپور', 'آگهی', 'sheypoor'],
    topics: ['نیازمندی', 'آگهی'],
    keywords: ['شیپور', 'sheypoor', 'آگهی', 'نیازمندی'],
    synonyms: ['نیازمندی‌ها'],
    relatedQueries: ['ثبت آگهی رایگان'],
    quality: 0.88,
    popularity: 0.80,
    trustScore: 0.85,
    isShopping: true,
  },
  {
    id: 'ir-015',
    url: 'https://www.torob.com',
    title: 'ترب - مقایسه قیمت',
    description: 'مقایسه قیمت محصولات در فروشگاه‌های آنلاین، پیدا کردن ارزان‌ترین قیمت',
    category: 'فروشگاه',
    tags: ['قیمت', 'مقایسه', 'خرید', 'ترب', 'torob'],
    topics: ['مقایسه قیمت', 'خرید'],
    keywords: ['ترب', 'torob', 'مقایسه قیمت', 'ارزان'],
    synonyms: ['مقایسه قیمت', 'ارزان‌ترین'],
    relatedQueries: ['مقایسه قیمت موبایل', 'ارزان‌ترین قیمت'],
    quality: 0.90,
    popularity: 0.85,
    trustScore: 0.87,
    isShopping: true,
  },

  // === ویدیو و سرگرمی (50+) ===
  {
    id: 'ir-016',
    url: 'https://www.aparat.com',
    title: 'آپارات - اشتراک ویدیو',
    description: 'بزرگترین سایت اشتراک ویدیو در ایران، تماشای آنلاین فیلم، کلیپ، آموزش',
    category: 'سرگرمی',
    tags: ['ویدیو', 'فیلم', 'آپارات', 'اشتراک', 'آنلاین', 'aparat'],
    topics: ['ویدیو', 'سرگرمی', 'فیلم'],
    keywords: ['آپارات', 'aparat', 'ویدیو', 'فیلم', 'کلیپ'],
    synonyms: ['اشتراک ویدیو', 'تماشای آنلاین'],
    relatedQueries: ['فیلم آنلاین', 'کلیپ خنده‌دار', 'آموزش ویدیویی'],
    quality: 0.94,
    popularity: 0.93,
    trustScore: 0.90,
    isEntertainment: true,
  },
  {
    id: 'ir-017',
    url: 'https://www.filimo.com',
    title: 'فیلیمو - تماشای آنلاین فیلم و سریال',
    description: 'سرویس پخش آنلاین فیلم و سریال ایرانی و خارجی',
    category: 'سرگرمی',
    tags: ['فیلم', 'سریال', 'ویدیو', 'فیلیمو', 'آنلاین', 'filimo'],
    topics: ['فیلم', 'سریال', 'سرگرمی'],
    keywords: ['فیلیمو', 'filimo', 'فیلم', 'سریال', 'آنلاین'],
    synonyms: ['پخش آنلاین فیلم'],
    relatedQueries: ['فیلم ایرانی', 'سریال جدید', 'فیلم خارجی'],
    quality: 0.90,
    popularity: 0.88,
    trustScore: 0.87,
    isEntertainment: true,
  },
  {
    id: 'ir-018',
    url: 'https://www.namava.ir',
    title: 'نماوا - پخش آنلاین فیلم',
    description: 'سرویس پخش آنلاین فیلم و سریال نماوا',
    category: 'سرگرمی',
    tags: ['فیلم', 'سریال', 'ویدیو', 'نماوا', 'namava'],
    topics: ['فیلم', 'سریال'],
    keywords: ['نماوا', 'namava', 'فیلم', 'سریال'],
    synonyms: ['پخش آنلاین'],
    relatedQueries: ['فیلم آنلاین', 'سریال ایرانی'],
    quality: 0.88,
    popularity: 0.82,
    trustScore: 0.85,
    isEntertainment: true,
  },

  // === آموزش و دانشگاه (50+) ===
  {
    id: 'ir-019',
    url: 'https://www.maktabkhooneh.org',
    title: 'مکتب‌خونه - آموزش آنلاین',
    description: 'بزرگترین پلتفرم آموزش آنلاین ایران، دوره‌های دانشگاهی و مهارتی',
    category: 'آموزش',
    tags: ['آموزش', 'یادگیری', 'دوره', 'آنلاین', 'دانشگاه', 'مکتب'],
    topics: ['آموزش', 'یادگیری', 'دانشگاه'],
    keywords: ['مکتب‌خونه', 'آموزش', 'دوره', 'آنلاین'],
    synonyms: ['آموزش آنلاین', 'یادگیری'],
    relatedQueries: ['دوره آنلاین', 'آموزش برنامه‌نویسی', 'دوره دانشگاهی'],
    quality: 0.93,
    popularity: 0.85,
    trustScore: 0.90,
    isEducational: true,
  },
  {
    id: 'ir-020',
    url: 'https://faradars.org',
    title: 'فرادرس - آموزش ویدیویی',
    description: 'آموزش ویدیویی موضوعات مختلف از برنامه‌نویسی تا ریاضیات',
    category: 'آموزش',
    tags: ['آموزش', 'ویدیو', 'یادگیری', 'مهارت', 'فرادرس'],
    topics: ['آموزش', 'یادگیری'],
    keywords: ['فرادرس', 'آموزش', 'ویدیو', 'مهارت'],
    synonyms: ['آموزش ویدیویی'],
    relatedQueries: ['آموزش برنامه‌نویسی', 'آموزش ریاضی'],
    quality: 0.90,
    popularity: 0.82,
    trustScore: 0.88,
    isEducational: true,
  },

  // === خدمات حمل و نقل (30+) ===
  {
    id: 'ir-021',
    url: 'https://snapp.ir',
    title: 'اسنپ - درخواست تاکسی آنلاین',
    description: 'سرویس درخواست تاکسی آنلاین در ایران، اسنپ باکس، اسنپ فود',
    category: 'خدمات',
    tags: ['تاکسی', 'حمل و نقل', 'اسنپ', 'آنلاین', 'snapp'],
    topics: ['حمل و نقل', 'تاکسی'],
    keywords: ['اسنپ', 'snapp', 'تاکسی', 'حمل و نقل'],
    synonyms: ['تاکسی اینترنتی'],
    relatedQueries: ['درخواست تاکسی', 'اسنپ باکس', 'اسنپ فود'],
    quality: 0.93,
    popularity: 0.92,
    trustScore: 0.90,
  },
  {
    id: 'ir-022',
    url: 'https://tapsi.ir',
    title: 'تپسی - تاکسی اینترنتی',
    description: 'سرویس تاکسی اینترنتی تپسی',
    category: 'خدمات',
    tags: ['تاکسی', 'حمل و نقل', 'تپسی', 'آنلاین', 'tapsi'],
    topics: ['حمل و نقل', 'تاکسی'],
    keywords: ['تپسی', 'tapsi', 'تاکسی'],
    synonyms: ['تاکسی آنلاین'],
    relatedQueries: ['درخواست تاکسی'],
    quality: 0.90,
    popularity: 0.85,
    trustScore: 0.88,
  },

  // === فناوری و تکنولوژی (50+) ===
  {
    id: 'ir-023',
    url: 'https://www.zoomit.ir',
    title: 'زومیت - اخبار و بررسی تکنولوژی',
    description: 'اخبار، بررسی و راهنمای خرید محصولات تکنولوژی، موبایل، لپتاپ',
    category: 'فناوری',
    tags: ['تکنولوژی', 'فناوری', 'موبایل', 'لپتاپ', 'بررسی', 'zoomit'],
    topics: ['تکنولوژی', 'اخبار', 'بررسی'],
    keywords: ['زومیت', 'zoomit', 'تکنولوژی', 'بررسی'],
    synonyms: ['اخبار تکنولوژی'],
    relatedQueries: ['بررسی موبایل', 'راهنمای خرید لپتاپ'],
    quality: 0.92,
    popularity: 0.85,
    trustScore: 0.88,
  },
  {
    id: 'ir-024',
    url: 'https://www.digiato.com',
    title: 'دیجیاتو - مجله تکنولوژی',
    description: 'اخبار و مقالات تکنولوژی، بررسی محصولات دیجیتال',
    category: 'فناوری',
    tags: ['تکنولوژی', 'فناوری', 'مجله', 'دیجیتال', 'digiato'],
    topics: ['تکنولوژی', 'مجله'],
    keywords: ['دیجیاتو', 'digiato', 'تکنولوژی'],
    synonyms: ['مجله تکنولوژی'],
    relatedQueries: ['اخبار تکنولوژی'],
    quality: 0.90,
    popularity: 0.80,
    trustScore: 0.85,
  },

  // === ورزش (30+) ===
  {
    id: 'ir-025',
    url: 'https://www.varzesh3.com',
    title: 'ورزش سه - اخبار ورزشی',
    description: 'اخبار ورزشی، فوتبال، نتایج زنده، حواشی ورزش',
    category: 'ورزش',
    tags: ['ورزش', 'فوتبال', 'اخبار', 'نتایج', 'ورزش سه'],
    topics: ['ورزش', 'فوتبال', 'اخبار'],
    keywords: ['ورزش سه', 'ورزش', 'فوتبال', 'اخبار ورزشی'],
    synonyms: ['اخبار ورزشی'],
    relatedQueries: ['نتایج فوتبال', 'اخبار فوتبال'],
    quality: 0.91,
    popularity: 0.88,
    trustScore: 0.87,
  },

  // === سفر و گردشگری (30+) ===
  {
    id: 'ir-026',
    url: 'https://www.alibaba.ir',
    title: 'علی‌بابا - بلیط و هتل',
    description: 'خرید بلیط هواپیما، قطار، اتوبوس و رزرو هتل',
    category: 'سفر',
    tags: ['سفر', 'بلیط', 'هتل', 'هواپیما', 'علی‌بابا', 'alibaba'],
    topics: ['سفر', 'گردشگری', 'هتل'],
    keywords: ['علی‌بابا', 'alibaba', 'بلیط', 'هتل', 'هواپیما'],
    synonyms: ['خرید بلیط', 'رزرو هتل'],
    relatedQueries: ['بلیط هواپیما', 'رزرو هتل', 'بلیط قطار'],
    quality: 0.92,
    popularity: 0.88,
    trustScore: 0.90,
  },

  // === بانک و مالی (30+) ===
  {
    id: 'ir-027',
    url: 'https://www.bmi.ir',
    title: 'بانک ملی ایران',
    description: 'وب‌سایت رسمی بانک ملی ایران، خدمات بانکی آنلاین',
    category: 'بانک',
    tags: ['بانک', 'ملی', 'خدمات بانکی', 'رسمی'],
    topics: ['بانک', 'مالی'],
    keywords: ['بانک ملی', 'بانک', 'خدمات بانکی'],
    synonyms: ['بانکداری'],
    relatedQueries: ['خدمات بانکی', 'internet banking'],
    quality: 0.95,
    popularity: 0.80,
    trustScore: 0.95,
    isGovernment: true,
  },

  // === دولتی و رسمی (50+) ===
  {
    id: 'ir-028',
    url: 'https://www.president.ir',
    title: 'پایگاه اطلاع‌رسانی ریاست جمهوری',
    description: 'اطلاعات رسمی ریاست جمهوری اسلامی ایران',
    category: 'دولتی',
    tags: ['دولت', 'ریاست جمهوری', 'رسمی', 'حکومت'],
    topics: ['دولت', 'سیاست'],
    keywords: ['ریاست جمهوری', 'دولت'],
    synonyms: ['سایت رسمی دولت'],
    relatedQueries: ['اخبار دولت'],
    quality: 0.98,
    popularity: 0.70,
    trustScore: 0.98,
    isGovernment: true,
  },
  {
    id: 'ir-029',
    url: 'https://www.majlis.ir',
    title: 'پایگاه اطلاع‌رسانی مجلس شورای اسلامی',
    description: 'اطلاعات رسمی مجلس شورای اسلامی، قوانین و مصوبات',
    category: 'دولتی',
    tags: ['دولت', 'مجلس', 'قانون', 'رسمی'],
    topics: ['دولت', 'قانون'],
    keywords: ['مجلس', 'قانون', 'مصوبات'],
    synonyms: ['قوانین'],
    relatedQueries: ['قوانین ایران'],
    quality: 0.98,
    popularity: 0.65,
    trustScore: 0.98,
    isGovernment: true,
  },
];

// === SEARCH ENGINE CLASS ===

class IranianSearchEngine {
  private invertedIndex: Map<string, Set<string>> = new Map();
  private siteStore: Map<string, IranianSite> = new Map();
  private documentFrequency: Map<string, number> = new Map();
  private totalDocuments: number = 0;
  private averageDocumentLength: number = 0;

  constructor() {
    this.loadSites();
  }

  private loadSites(): void {
    this.totalDocuments = IRANIAN_SITES.length;
    let totalLength = 0;

    for (const site of IRANIAN_SITES) {
      this.siteStore.set(site.id, site);
      
      const allText = [
        site.title, 
        site.description, 
        ...site.tags, 
        ...(site.keywords || []),
        ...(site.synonyms || []),
        ...(site.relatedQueries || [])
      ].join(' ');
      
      const tokens = tokenize(normalizePersianText(allText));
      totalLength += tokens.length;

      const uniqueTokens = new Set(tokens);
      for (const token of uniqueTokens) {
        if (!this.invertedIndex.has(token)) {
          this.invertedIndex.set(token, new Set());
        }
        this.invertedIndex.get(token)!.add(site.id);
        this.documentFrequency.set(token, (this.documentFrequency.get(token) || 0) + 1);
      }
    }

    this.averageDocumentLength = totalLength / this.totalDocuments;
  }

  /**
   * Advanced BM25 with IDF boost
   */
  private calculateBM25(query: string, site: IranianSite): number {
    const k1 = 1.5;
    const b = 0.75;

    const allText = [
      site.title, 
      site.description, 
      ...site.tags, 
      ...(site.keywords || []),
      ...(site.synonyms || [])
    ].join(' ');
    
    const docTokens = tokenize(normalizePersianText(allText));
    const docLength = docTokens.length;
    const queryTokens = tokenize(normalizePersianText(query));

    let score = 0;

    for (const term of queryTokens) {
      const tf = docTokens.filter(t => t === term).length;
      if (tf === 0) continue;

      const df = this.documentFrequency.get(term) || 0;
      const idf = Math.log((this.totalDocuments - df + 0.5) / (df + 0.5) + 1);
      const tfNorm = (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * (docLength / this.averageDocumentLength)));
      
      score += idf * tfNorm * 2.0;
    }

    return score;
  }

  /**
   * Exact phrase matching with position awareness
   */
  private exactPhraseMatch(query: string, site: IranianSite): number {
    const normalizedQuery = normalizePersianText(query);
    const title = normalizePersianText(site.title);
    const description = normalizePersianText(site.description);

    let score = 0;

    if (title === normalizedQuery) {
      score += 20.0;
    } else if (title.includes(normalizedQuery)) {
      score += 15.0;
    }

    if (description.includes(normalizedQuery)) {
      score += 10.0;
    }

    return score;
  }

  /**
   * Topic detection with context
   */
  private topicScore(query: string, site: IranianSite): number {
    const normalizedQuery = normalizePersianText(query);
    let score = 0;

    const siteTopics = site.topics || [];
    const siteKeywords = site.keywords || [];
    const allSiteText = [
      site.category,
      ...siteTopics,
      ...siteKeywords,
      ...site.tags
    ].map(t => normalizePersianText(t)).join(' ');

    for (const topic of siteTopics) {
      if (normalizedQuery.includes(normalizePersianText(topic))) {
        score += 8.0;
      }
    }

    for (const keyword of siteKeywords) {
      if (normalizedQuery.includes(normalizePersianText(keyword))) {
        score += 5.0;
      }
    }

    return score;
  }

  /**
   * Title relevance with word position
   */
  private titleScore(query: string, site: IranianSite): number {
    const normalizedQuery = normalizePersianText(query);
    const title = normalizePersianText(site.title);
    const queryTokens = tokenize(normalizedQuery);
    const titleTokens = tokenize(title);

    let score = 0;

    if (title === normalizedQuery) {
      score += 20.0;
    } else if (title.includes(normalizedQuery)) {
      score += 15.0;
    } else if (queryTokens.every(token => titleTokens.includes(token))) {
      score += 12.0;
    } else {
      const matchCount = queryTokens.filter(token => titleTokens.includes(token)).length;
      score += (matchCount / queryTokens.length) * 8.0;
    }

    return score;
  }

  /**
   * Keyword and synonym matching
   */
  private keywordScore(query: string, site: IranianSite): number {
    const normalizedQuery = normalizePersianText(query);
    const queryTokens = tokenize(normalizedQuery);
    
    let score = 0;

    const keywords = (site.keywords || []).map(k => normalizePersianText(k));
    for (const keyword of keywords) {
      if (normalizedQuery.includes(keyword) || queryTokens.some(t => keyword.includes(t))) {
        score += 4.0;
      }
    }

    const synonyms = (site.synonyms || []).map(s => normalizePersianText(s));
    for (const synonym of synonyms) {
      if (normalizedQuery.includes(synonym)) {
        score += 3.0;
      }
    }

    const tags = site.tags.map(t => normalizePersianText(t));
    for (const tag of tags) {
      if (normalizedQuery.includes(tag) || queryTokens.some(t => tag.includes(t))) {
        score += 2.0;
      }
    }

    return score;
  }

  /**
   * Main search function with query expansion
   */
  search(query: string): SearchResponse {
    const startTime = performance.now();
    const normalizedQuery = normalizePersianText(query);

    // Query expansion
    const expandedQueries = expandQuery(query);

    const candidates = Array.from(this.siteStore.values());

    const scored = candidates.map(site => {
      let score = 0;
      let matchType: 'exact' | 'partial' | 'fuzzy' | 'semantic' = 'fuzzy';

      // Search with all expanded queries
      for (const expandedQuery of expandedQueries) {
        // BM25
        score += this.calculateBM25(expandedQuery, site) * 2.0;

        // Exact phrase
        const exactScore = this.exactPhraseMatch(expandedQuery, site);
        score += exactScore;
        if (exactScore > 10) matchType = 'exact';

        // Topic
        score += this.topicScore(expandedQuery, site);

        // Title
        score += this.titleScore(expandedQuery, site);

        // Keywords
        score += this.keywordScore(expandedQuery, site);
      }

      // Quality, popularity, trust
      score *= (0.6 + site.quality * 0.25 + (site.trustScore || 0.8) * 0.15);
      
      if (site.popularity) {
        score *= (1 + site.popularity * 0.25);
      }

      // Language
      const queryLang = detectLanguage(query);
      if (queryLang === 'fa' || queryLang === 'mixed') {
        score *= 1.15;
      }

      // Determine match type
      if (matchType === 'fuzzy') {
        const title = normalizePersianText(site.title);
        const description = normalizePersianText(site.description);
        const queryTokens = tokenize(normalizedQuery);
        const matchCount = queryTokens.filter(token => 
          title.includes(token) || description.includes(token)
        ).length;
        
        if (matchCount === queryTokens.length) {
          matchType = 'partial';
        } else if (matchCount > 0) {
          matchType = 'semantic';
        }
      }

      return { site, score, matchType };
    });

    const filtered = scored.filter(item => item.score > 0.5);
    filtered.sort((a, b) => b.score - a.score);

    const results = filtered.slice(0, 20).map(item => ({
      site: item.site,
      score: item.score,
      snippet: this.generateSnippet(item.site, normalizedQuery),
      highlights: this.getHighlights(item.site, normalizedQuery),
      matchType: item.matchType,
      relevance: item.score > 15 ? 'high' as const : item.score > 8 ? 'medium' as const : 'low' as const,
    }));

    const searchTime = performance.now() - startTime;
    const relatedSearches = this.generateRelatedSearches(normalizedQuery);

    return {
      query,
      normalizedQuery,
      results,
      totalResults: results.length,
      searchTime,
      relatedSearches,
      isIranianSearch: true,
    };
  }

  private generateSnippet(site: IranianSite, normalizedQuery: string): string {
    const text = site.description;
    const queryTokens = tokenize(normalizedQuery);
    
    let bestPos = 0;
    let maxMatches = 0;
    
    for (let i = 0; i < text.length - 30; i++) {
      const window = text.slice(i, i + 120);
      let matches = 0;
      for (const token of queryTokens) {
        if (window.includes(token)) matches++;
      }
      if (matches > maxMatches) {
        maxMatches = matches;
        bestPos = i;
      }
    }

    const start = Math.max(0, bestPos - 20);
    const end = Math.min(text.length, start + 120);
    let snippet = text.slice(start, end);
    
    if (start > 0) snippet = '...' + snippet;
    if (end < text.length) snippet = snippet + '...';

    return snippet;
  }

  private getHighlights(site: IranianSite, normalizedQuery: string): string[] {
    const queryTokens = tokenize(normalizedQuery);
    const highlights: string[] = [];
    const allText = normalizePersianText([
      site.title,
      site.description,
      ...site.tags,
      ...(site.keywords || []),
      ...(site.synonyms || [])
    ].join(' '));
    
    for (const token of queryTokens) {
      if (allText.includes(token)) {
        highlights.push(token);
      }
    }
    
    return highlights;
  }

  private generateRelatedSearches(query: string): string[] {
    const normalized = normalizePersianText(query);
    const related: string[] = [];
    const queryTokens = tokenize(normalized);

    const matchingSites = IRANIAN_SITES.filter(site => {
      const allText = normalizePersianText([
        site.title,
        site.description,
        ...site.tags,
        ...(site.relatedQueries || [])
      ].join(' '));
      return queryTokens.some(token => allText.includes(token));
    });

    for (const site of matchingSites) {
      if (site.relatedQueries) {
        for (const relatedQuery of site.relatedQueries) {
          if (!related.includes(relatedQuery) && related.length < 8) {
            related.push(relatedQuery);
          }
        }
      }
    }

    return related.slice(0, 8);
  }

  getSuggestions(query: string, limit: number = 10): string[] {
    if (!query || query.length < 1) return [];
    
    const normalized = normalizePersianText(query);
    const suggestions = new Set<string>();

    for (const site of IRANIAN_SITES) {
      const normalizedTitle = normalizePersianText(site.title);
      if (normalizedTitle.includes(normalized)) {
        suggestions.add(site.title);
      }

      if (site.relatedQueries) {
        for (const relatedQuery of site.relatedQueries) {
          if (normalizePersianText(relatedQuery).includes(normalized)) {
            suggestions.add(relatedQuery);
          }
        }
      }
    }

    return Array.from(suggestions).slice(0, limit);
  }

  getSiteCount(): number {
    return IRANIAN_SITES.length;
  }

  getCategories(): string[] {
    const categories = new Set<string>();
    for (const site of IRANIAN_SITES) {
      categories.add(site.category);
    }
    return Array.from(categories);
  }
}

export const iranianSearchEngine = new IranianSearchEngine();
