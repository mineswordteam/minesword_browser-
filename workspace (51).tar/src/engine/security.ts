/**
 * Minesword Browser Engine - Security Module
 * 
 * Implements real security boundaries:
 * - Content Security Policy parsing and enforcement
 * - iframe sandbox configuration
 * - Origin isolation checks
 * - URL safety validation
 * - Cookie security attribute handling
 * - Mixed content detection
 * - Permission enforcement
 * 
 * This module does NOT simulate security - it provides real
 * security policies that are actually enforced.
 */

// === CONTENT SECURITY POLICY ===

export interface CSPPolicy {
  defaultSrc?: string[];
  scriptSrc?: string[];
  styleSrc?: string[];
  imgSrc?: string[];
  connectSrc?: string[];
  fontSrc?: string[];
  objectSrc?: string[];
  mediaSrc?: string[];
  frameSrc?: string[];
  frameAncestors?: string[];
  formAction?: string[];
  baseUri?: string[];
  reportUri?: string;
  reportTo?: string;
  upgradeInsecureRequests?: boolean;
  blockAllMixedContent?: boolean;
}

/**
 * Parse a CSP header string into a structured policy
 */
export function parseCSP(header: string): CSPPolicy {
  const policy: CSPPolicy = {};
  const directives = header.split(';').map(d => d.trim()).filter(Boolean);

  for (const directive of directives) {
    const parts = directive.split(/\s+/);
    const name = parts[0].toLowerCase();
    const values = parts.slice(1);

    switch (name) {
      case 'default-src': policy.defaultSrc = values; break;
      case 'script-src': policy.scriptSrc = values; break;
      case 'style-src': policy.styleSrc = values; break;
      case 'img-src': policy.imgSrc = values; break;
      case 'connect-src': policy.connectSrc = values; break;
      case 'font-src': policy.fontSrc = values; break;
      case 'object-src': policy.objectSrc = values; break;
      case 'media-src': policy.mediaSrc = values; break;
      case 'frame-src': policy.frameSrc = values; break;
      case 'frame-ancestors': policy.frameAncestors = values; break;
      case 'form-action': policy.formAction = values; break;
      case 'base-uri': policy.baseUri = values; break;
      case 'report-uri': policy.reportUri = values[0]; break;
      case 'report-to': policy.reportTo = values[0]; break;
      case 'upgrade-insecure-requests': policy.upgradeInsecureRequests = true; break;
      case 'block-all-mixed-content': policy.blockAllMixedContent = true; break;
    }
  }

  return policy;
}

/**
 * Check if a URL is allowed by a CSP directive
 */
export function isURLAllowedByCSP(url: string, directive: string[] | undefined, documentOrigin: string): boolean {
  if (!directive || directive.length === 0) return true; // No restriction

  for (const source of directive) {
    if (source === '*') return true;
    if (source === "'self'") {
      try {
        const urlOrigin = new URL(url).origin;
        if (urlOrigin === documentOrigin) return true;
      } catch {
        return false;
      }
    }
    if (source === "'none'") return false;
    if (source === "'unsafe-inline'") continue; // Handled separately
    if (source === "'unsafe-eval'") continue; // Handled separately
    
    // Check scheme
    if (source.endsWith(':') && url.startsWith(source)) return true;
    
    // Check host match
    try {
      const urlObj = new URL(url);
      if (source.startsWith('*.')) {
        const domain = source.slice(2);
        if (urlObj.hostname.endsWith(domain) || urlObj.hostname === domain.slice(1)) {
          return true;
        }
      } else if (urlObj.hostname === source || urlObj.host === source) {
        return true;
      }
    } catch {
      continue;
    }
  }

  return false;
}

// === SANDBOX CONFIGURATION ===

export type SandboxFlag =
  | 'allow-scripts'
  | 'allow-same-origin'
  | 'allow-forms'
  | 'allow-popups'
  | 'allow-popups-to-escape-sandbox'
  | 'allow-top-navigation'
  | 'allow-top-navigation-by-user-activation'
  | 'allow-modals'
  | 'allow-orientation-lock'
  | 'allow-pointer-lock'
  | 'allow-presentation'
  | 'allow-downloads'
  | 'allow-storage-access-by-user-activation';

/**
 * Get sandbox configuration based on security level
 */
export function getSandboxConfig(level: 'strict' | 'standard' | 'permissive'): SandboxFlag[] {
  switch (level) {
    case 'strict':
      // Maximum isolation - no scripts, no same-origin
      return [
        'allow-forms',
        'allow-popups',
        'allow-downloads',
      ];
    
    case 'standard':
      // Balanced - scripts allowed but isolated
      return [
        'allow-scripts',
        'allow-forms',
        'allow-popups',
        'allow-popups-to-escape-sandbox',
        'allow-downloads',
      ];
    
    case 'permissive':
      // Full functionality - scripts + same-origin
      // WARNING: This weakens origin isolation
      return [
        'allow-scripts',
        'allow-same-origin',
        'allow-forms',
        'allow-popups',
        'allow-popups-to-escape-sandbox',
        'allow-modals',
        'allow-downloads',
      ];
  }
}

/**
 * Convert sandbox flags to attribute string
 */
export function sandboxToString(flags: SandboxFlag[]): string {
  return flags.join(' ');
}

// === URL SAFETY ===

export interface URLSafetyResult {
  safe: boolean;
  reason?: string;
  risk: 'none' | 'low' | 'medium' | 'high';
}

/**
 * Dangerous URL patterns
 */
const DANGEROUS_PROTOCOLS = new Set([
  'javascript:',
  'data:',
  'vbscript:',
]);

const SUSPICIOUS_PATTERNS = [
  /@.*@/, // Double @ (URL obfuscation)
  /\t|\r|\n/, // Control characters
  /%00/, // Null byte
  /\/\/.*@/, // Credentials in URL
  /\.pdf\.exe$/i, // Double extension
  /\.doc\.exe$/i,
  /\.jpg\.exe$/i,
];

/**
 * Check if a URL is safe to navigate to
 */
export function checkURLSafety(url: string): URLSafetyResult {
  if (!url || url.trim() === '') {
    return { safe: false, reason: 'Empty URL', risk: 'high' };
  }

  const trimmed = url.trim();

  // Check for dangerous protocols
  const lowerUrl = trimmed.toLowerCase();
  for (const protocol of DANGEROUS_PROTOCOLS) {
    if (lowerUrl.startsWith(protocol)) {
      return {
        safe: false,
        reason: `Blocked dangerous protocol: ${protocol}`,
        risk: 'high',
      };
    }
  }

  // Check for suspicious patterns
  for (const pattern of SUSPICIOUS_PATTERNS) {
    if (pattern.test(trimmed)) {
      return {
        safe: false,
        reason: 'URL contains suspicious patterns',
        risk: 'high',
      };
    }
  }

  // Validate URL structure
  try {
    const parsed = new URL(trimmed.startsWith('http') ? trimmed : `https://${trimmed}`);
    
    // Check for localhost/internal IPs in production context
    const hostname = parsed.hostname.toLowerCase();
    if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1') {
      return {
        safe: true,
        reason: 'Local address',
        risk: 'low',
      };
    }

    // Check for private IP ranges
    if (/^(10\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.)/.test(hostname)) {
      return {
        safe: true,
        reason: 'Private network address',
        risk: 'low',
      };
    }

    return { safe: true, risk: 'none' };
  } catch {
    return {
      safe: false,
      reason: 'Invalid URL format',
      risk: 'medium',
    };
  }
}

// === MIXED CONTENT ===

export interface MixedContentCheck {
  allowed: boolean;
  type: 'active' | 'passive' | 'none';
  reason?: string;
}

/**
 * Check for mixed content (HTTPS page loading HTTP resources)
 */
export function checkMixedContent(pageUrl: string, resourceUrl: string): MixedContentCheck {
  try {
    const pageProtocol = new URL(pageUrl).protocol;
    const resourceProtocol = new URL(resourceUrl).protocol;

    if (pageProtocol === 'https:' && resourceProtocol === 'http:') {
      // Determine if active or passive content
      const resourcePath = new URL(resourceUrl).pathname.toLowerCase();
      const isActive = resourcePath.endsWith('.js') ||
                       resourcePath.endsWith('.css') ||
                       resourcePath.endsWith('.html');

      return {
        allowed: false,
        type: isActive ? 'active' : 'passive',
        reason: `Mixed content: HTTPS page loading HTTP ${isActive ? 'active' : 'passive'} resource`,
      };
    }

    return { allowed: true, type: 'none' };
  } catch {
    return { allowed: true, type: 'none' };
  }
}

// === COOKIE SECURITY ===

export interface CookieAttributes {
  name: string;
  value: string;
  domain?: string;
  path?: string;
  expires?: Date;
  maxAge?: number;
  secure?: boolean;
  httpOnly?: boolean;
  sameSite?: 'Strict' | 'Lax' | 'None';
}

/**
 * Parse Set-Cookie header
 */
export function parseCookieHeader(header: string): CookieAttributes | null {
  const parts = header.split(';').map(p => p.trim());
  if (parts.length === 0) return null;

  const [nameValue, ...attributes] = parts;
  const eqIndex = nameValue.indexOf('=');
  if (eqIndex === -1) return null;

  const cookie: CookieAttributes = {
    name: nameValue.slice(0, eqIndex).trim(),
    value: nameValue.slice(eqIndex + 1).trim(),
  };

  for (const attr of attributes) {
    const [attrName, attrValue] = attr.split('=').map(s => s.trim());
    const lowerName = attrName.toLowerCase();

    switch (lowerName) {
      case 'domain': cookie.domain = attrValue; break;
      case 'path': cookie.path = attrValue; break;
      case 'expires': cookie.expires = new Date(attrValue); break;
      case 'max-age': cookie.maxAge = parseInt(attrValue, 10); break;
      case 'secure': cookie.secure = true; break;
      case 'httponly': cookie.httpOnly = true; break;
      case 'samesite':
        if (attrValue?.toLowerCase() === 'strict') cookie.sameSite = 'Strict';
        else if (attrValue?.toLowerCase() === 'lax') cookie.sameSite = 'Lax';
        else if (attrValue?.toLowerCase() === 'none') cookie.sameSite = 'None';
        break;
    }
  }

  return cookie;
}

/**
 * Check if a cookie should be accepted based on security policy
 */
export function shouldAcceptCookie(
  cookie: CookieAttributes,
  requestUrl: string,
  isSecureContext: boolean
): { accept: boolean; reason?: string } {
  try {
    const url = new URL(requestUrl);
    
    // Secure flag check
    if (cookie.secure && url.protocol !== 'https:') {
      return { accept: false, reason: 'Secure cookie rejected on non-HTTPS page' };
    }

    // SameSite=None requires Secure
    if (cookie.sameSite === 'None' && !cookie.secure) {
      return { accept: false, reason: 'SameSite=None cookie must be Secure' };
    }

    // Domain validation
    if (cookie.domain) {
      const cookieDomain = cookie.domain.startsWith('.')
        ? cookie.domain.slice(1)
        : cookie.domain;
      
      if (!url.hostname.endsWith(cookieDomain) && url.hostname !== cookieDomain) {
        return { accept: false, reason: 'Cookie domain does not match request URL' };
      }
    }

    return { accept: true };
  } catch {
    return { accept: false, reason: 'Invalid URL' };
  }
}

// === PERMISSION SYSTEM ===

export type PermissionName =
  | 'camera'
  | 'microphone'
  | 'geolocation'
  | 'notifications'
  | 'clipboard-read'
  | 'clipboard-write'
  | 'fullscreen'
  | 'payment'
  | 'usb'
  | 'bluetooth'
  | 'persistent-storage';

export type PermissionState = 'granted' | 'denied' | 'prompt';

export interface PermissionDescriptor {
  name: PermissionName;
  origin: string;
  state: PermissionState;
  updatedAt: number;
}

class PermissionManager {
  private permissions: Map<string, PermissionDescriptor> = new Map();

  private getKey(origin: string, name: PermissionName): string {
    return `${origin}:${name}`;
  }

  /**
   * Get permission state for an origin
   */
  getPermission(origin: string, name: PermissionName): PermissionState {
    const key = this.getKey(origin, name);
    const stored = this.permissions.get(key);
    return stored?.state || 'prompt';
  }

  /**
   * Set permission state
   */
  setPermission(origin: string, name: PermissionName, state: PermissionState): void {
    const key = this.getKey(origin, name);
    this.permissions.set(key, {
      name,
      origin,
      state,
      updatedAt: Date.now(),
    });
    this.persist();
  }

  /**
   * Reset permission to prompt state
   */
  resetPermission(origin: string, name: PermissionName): void {
    const key = this.getKey(origin, name);
    this.permissions.delete(key);
    this.persist();
  }

  /**
   * Clear all permissions for an origin
   */
  clearOrigin(origin: string): void {
    for (const [key, desc] of this.permissions) {
      if (desc.origin === origin) {
        this.permissions.delete(key);
      }
    }
    this.persist();
  }

  /**
   * Get all permissions for an origin
   */
  getOriginPermissions(origin: string): PermissionDescriptor[] {
    const result: PermissionDescriptor[] = [];
    for (const desc of this.permissions.values()) {
      if (desc.origin === origin) {
        result.push(desc);
      }
    }
    return result;
  }

  /**
   * Check if action is allowed
   */
  isAllowed(origin: string, name: PermissionName): boolean {
    return this.getPermission(origin, name) === 'granted';
  }

  private persist(): void {
    try {
      const data = Array.from(this.permissions.values());
      localStorage.setItem('minesword_permissions', JSON.stringify(data));
    } catch {
      // Storage may be unavailable
    }
  }

  load(): void {
    try {
      const stored = localStorage.getItem('minesword_permissions');
      if (stored) {
        const data: PermissionDescriptor[] = JSON.parse(stored);
        for (const desc of data) {
          this.permissions.set(this.getKey(desc.origin, desc.name), desc);
        }
      }
    } catch {
      // Ignore load errors
    }
  }
}

// Singleton instance
export const permissionManager = new PermissionManager();
permissionManager.load();

// === SECURITY HEADERS ===

/**
 * Generate recommended security headers for iframe
 */
export function getSecurityHeaders(): Record<string, string> {
  return {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'SAMEORIGIN',
    'Referrer-Policy': 'no-referrer',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  };
}

/**
 * Validate that a redirect target is safe
 */
export function isRedirectSafe(fromUrl: string, toUrl: string): boolean {
  // Block redirects to dangerous protocols
  const safety = checkURLSafety(toUrl);
  if (!safety.safe) return false;

  // Block redirects from HTTPS to HTTP (downgrade)
  try {
    const fromProtocol = new URL(fromUrl).protocol;
    const toProtocol = new URL(toUrl).protocol;
    if (fromProtocol === 'https:' && toProtocol === 'http:') {
      return false;
    }
  } catch {
    return false;
  }

  return true;
}
