/**
 * Minesword Browser - Smart URL Loader
 * 
 * Detects sites that block iframe embedding and opens them in new tab.
 * Uses a combination of:
 * - Known blocking sites list
 * - X-Frame-Options detection
 * - Automatic fallback
 */

// Sites known to block iframe embedding
const IFRAME_BLOCKED_SITES = new Set([
  'aparat.com',
  'www.aparat.com',
  'youtube.com',
  'www.youtube.com',
  'google.com',
  'www.google.com',
  'facebook.com',
  'www.facebook.com',
  'twitter.com',
  'x.com',
  'instagram.com',
  'www.instagram.com',
  'rubika.ir',
  'www.rubika.ir',
  'digikala.com',
  'www.digikala.com',
  'divar.ir',
  'www.divar.ir',
  'bale.ai',
  'www.bale.ai',
  'eitaa.com',
  'snapp.ir',
  'tapsi.ir',
  'snappfood.ir',
  'filimo.com',
  'www.filimo.com',
  'namava.ir',
  'www.namava.ir',
  'torob.com',
  'www.torob.com',
  'bama.ir',
  'www.bama.ir',
  'sheypoor.com',
  'www.sheypoor.com',
  'alibaba.ir',
  'www.alibaba.ir',
  'github.com',
  'www.github.com',
  'stackoverflow.com',
  'reddit.com',
  'www.reddit.com',
  'linkedin.com',
  'www.linkedin.com',
  'amazon.com',
  'www.amazon.com',
  'netflix.com',
  'www.netflix.com',
]);

/**
 * Check if a URL is known to block iframe embedding
 */
export function isKnownIframeBlocked(url: string): boolean {
  try {
    const urlObj = new URL(url);
    const hostname = urlObj.hostname.toLowerCase();
    
    // Check exact match
    if (IFRAME_BLOCKED_SITES.has(hostname)) {
      return true;
    }
    
    // Check if any blocked domain is a suffix
    for (const blocked of IFRAME_BLOCKED_SITES) {
      if (hostname === blocked || hostname.endsWith('.' + blocked)) {
        return true;
      }
    }
    
    return false;
  } catch {
    return false;
  }
}

/**
 * Get the appropriate action for a URL
 */
export function getUrlAction(url: string): 'iframe' | 'new-tab' {
  if (isKnownIframeBlocked(url)) {
    return 'new-tab';
  }
  return 'iframe';
}

/**
 * Open URL in new tab
 */
export function openUrlInNewTab(url: string): void {
  window.open(url, '_blank', 'noopener,noreferrer');
}
