/**
 * Minesword Browser Engine - Compatibility Test Suite
 * 
 * Tests actual browser capabilities using real APIs.
 * Records results in a structured compatibility matrix.
 * 
 * This is NOT a simulation - it tests real browser features.
 */

export interface CompatibilityTest {
  id: string;
  name: string;
  category: 'html' | 'css' | 'js' | 'api' | 'security' | 'persian';
  level: 1 | 2 | 3 | 4 | 5 | 6;
  description: string;
  test: () => Promise<TestResult>;
}

export interface TestResult {
  supported: 'full' | 'partial' | 'none';
  details?: string;
  score?: number; // 0-100
}

export interface CompatibilityReport {
  timestamp: number;
  userAgent: string;
  results: Map<string, TestResult>;
  summary: {
    total: number;
    full: number;
    partial: number;
    none: number;
    overallScore: number;
  };
}

// === TEST DEFINITIONS ===

const tests: CompatibilityTest[] = [
  // LEVEL 1: Basic HTML
  {
    id: 'html5-doctype',
    name: 'HTML5 Doctype',
    category: 'html',
    level: 1,
    description: 'HTML5 document type support',
    test: async () => ({
      supported: 'full',
      details: 'HTML5 doctype is standard',
      score: 100,
    }),
  },
  {
    id: 'semantic-elements',
    name: 'Semantic HTML Elements',
    category: 'html',
    level: 1,
    description: 'header, nav, main, article, section, footer',
    test: async () => {
      const elements = ['header', 'nav', 'main', 'article', 'section', 'footer', 'aside', 'figure', 'figcaption'];
      const supported = elements.filter(el => typeof document.createElement(el).constructor === 'function');
      return {
        supported: supported.length === elements.length ? 'full' : 'partial',
        details: `${supported.length}/${elements.length} elements supported`,
        score: (supported.length / elements.length) * 100,
      };
    },
  },
  {
    id: 'form-validation',
    name: 'HTML5 Form Validation',
    category: 'html',
    level: 1,
    description: 'Built-in form validation attributes',
    test: async () => {
      const input = document.createElement('input');
      const hasRequired = 'required' in input;
      const hasPattern = 'pattern' in input;
      const hasMin = 'min' in input;
      const hasMax = 'max' in input;
      
      return {
        supported: (hasRequired && hasPattern && hasMin && hasMax) ? 'full' : 'partial',
        details: `required:${hasRequired} pattern:${hasPattern} min:${hasMin} max:${hasMax}`,
        score: [hasRequired, hasPattern, hasMin, hasMax].filter(Boolean).length * 25,
      };
    },
  },

  // LEVEL 2: HTML + CSS
  {
    id: 'css-flexbox',
    name: 'CSS Flexbox',
    category: 'css',
    level: 2,
    description: 'Flexible box layout',
    test: async () => {
      const div = document.createElement('div');
      div.style.display = 'flex';
      document.body.appendChild(div);
      const computed = window.getComputedStyle(div).display;
      document.body.removeChild(div);
      
      return {
        supported: computed === 'flex' ? 'full' : 'none',
        details: `display:flex computed as: ${computed}`,
        score: computed === 'flex' ? 100 : 0,
      };
    },
  },
  {
    id: 'css-grid',
    name: 'CSS Grid',
    category: 'css',
    level: 2,
    description: 'Grid layout system',
    test: async () => {
      const supported = CSS.supports('display', 'grid');
      return {
        supported: supported ? 'full' : 'none',
        details: `CSS.supports('display', 'grid'): ${supported}`,
        score: supported ? 100 : 0,
      };
    },
  },
  {
    id: 'css-variables',
    name: 'CSS Custom Properties',
    category: 'css',
    level: 2,
    description: 'CSS variables (--custom-property)',
    test: async () => {
      const supported = CSS.supports('--test', '0');
      return {
        supported: supported ? 'full' : 'none',
        details: `CSS custom properties: ${supported}`,
        score: supported ? 100 : 0,
      };
    },
  },
  {
    id: 'css-media-queries',
    name: 'CSS Media Queries',
    category: 'css',
    level: 2,
    description: 'Responsive design support',
    test: async () => {
      const supported = typeof window.matchMedia === 'function';
      return {
        supported: supported ? 'full' : 'none',
        details: `window.matchMedia: ${supported}`,
        score: supported ? 100 : 0,
      };
    },
  },

  // LEVEL 3: Responsive Layouts
  {
    id: 'viewport-meta',
    name: 'Viewport Meta Tag',
    category: 'css',
    level: 3,
    description: 'Mobile viewport handling',
    test: async () => {
      const meta = document.querySelector('meta[name="viewport"]');
      return {
        supported: meta ? 'full' : 'none',
        details: meta ? 'Viewport meta tag present' : 'No viewport meta tag',
        score: meta ? 100 : 0,
      };
    },
  },
  {
    id: 'css-calc',
    name: 'CSS calc()',
    category: 'css',
    level: 3,
    description: 'Dynamic CSS calculations',
    test: async () => {
      const supported = CSS.supports('width', 'calc(100% - 20px)');
      return {
        supported: supported ? 'full' : 'none',
        details: `calc() support: ${supported}`,
        score: supported ? 100 : 0,
      };
    },
  },

  // LEVEL 4: JavaScript + DOM
  {
    id: 'es6-features',
    name: 'ES6+ Features',
    category: 'js',
    level: 4,
    description: 'let, const, arrow functions, classes, modules',
    test: async () => {
      const features = {
        let: true, // If this runs, let works
        const: true,
        arrow: (() => true)(),
        class: new (class { test() { return true; } })().test(),
        template: `test`,
        destructuring: (() => { const {a} = {a: 1}; return a === 1; })(),
        spread: (() => { const arr = [...[1,2,3]]; return arr.length === 3; })(),
        promise: typeof Promise !== 'undefined',
        symbol: typeof Symbol !== 'undefined',
        map: typeof Map !== 'undefined',
        set: typeof Set !== 'undefined',
      };
      
      const supported = Object.values(features).filter(Boolean).length;
      const total = Object.keys(features).length;
      
      return {
        supported: supported === total ? 'full' : 'partial',
        details: `${supported}/${total} ES6+ features`,
        score: (supported / total) * 100,
      };
    },
  },
  {
    id: 'async-await',
    name: 'Async/Await',
    category: 'js',
    level: 4,
    description: 'Asynchronous programming',
    test: async () => {
      try {
        const result = await (async () => {
          await new Promise(resolve => setTimeout(resolve, 1));
          return true;
        })();
        return {
          supported: result ? 'full' : 'none',
          details: 'async/await works',
          score: 100,
        };
      } catch {
        return {
          supported: 'none',
          details: 'async/await failed',
          score: 0,
        };
      }
    },
  },
  {
    id: 'dom-selectors',
    name: 'DOM Selectors',
    category: 'js',
    level: 4,
    description: 'querySelector, querySelectorAll',
    test: async () => {
      const hasQuerySelector = typeof document.querySelector === 'function';
      const hasQuerySelectorAll = typeof document.querySelectorAll === 'function';
      
      return {
        supported: (hasQuerySelector && hasQuerySelectorAll) ? 'full' : 'none',
        details: `querySelector: ${hasQuerySelector}, querySelectorAll: ${hasQuerySelectorAll}`,
        score: (hasQuerySelector && hasQuerySelectorAll) ? 100 : 0,
      };
    },
  },
  {
    id: 'event-listeners',
    name: 'Event Listeners',
    category: 'js',
    level: 4,
    description: 'addEventListener with options',
    test: async () => {
      const div = document.createElement('div');
      let triggered = false;
      
      div.addEventListener('click', () => { triggered = true; }, { once: true, passive: true });
      div.click();
      
      return {
        supported: triggered ? 'full' : 'none',
        details: `Event listener with options: ${triggered}`,
        score: triggered ? 100 : 0,
      };
    },
  },

  // LEVEL 5: Modern Web APIs
  {
    id: 'fetch-api',
    name: 'Fetch API',
    category: 'api',
    level: 5,
    description: 'Modern HTTP client',
    test: async () => {
      const supported = typeof fetch === 'function';
      return {
        supported: supported ? 'full' : 'none',
        details: `fetch API: ${supported}`,
        score: supported ? 100 : 0,
      };
    },
  },
  {
    id: 'web-storage',
    name: 'Web Storage',
    category: 'api',
    level: 5,
    description: 'localStorage and sessionStorage',
    test: async () => {
      const hasLocal = typeof localStorage !== 'undefined';
      const hasSession = typeof sessionStorage !== 'undefined';
      
      // Test actual functionality
      try {
        localStorage.setItem('test', '1');
        localStorage.removeItem('test');
      } catch {
        return {
          supported: 'none',
          details: 'localStorage not accessible',
          score: 0,
        };
      }
      
      return {
        supported: (hasLocal && hasSession) ? 'full' : 'partial',
        details: `localStorage: ${hasLocal}, sessionStorage: ${hasSession}`,
        score: (hasLocal && hasSession) ? 100 : 50,
      };
    },
  },
  {
    id: 'intersection-observer',
    name: 'Intersection Observer',
    category: 'api',
    level: 5,
    description: 'Lazy loading and visibility detection',
    test: async () => {
      const supported = typeof IntersectionObserver !== 'undefined';
      return {
        supported: supported ? 'full' : 'none',
        details: `IntersectionObserver: ${supported}`,
        score: supported ? 100 : 0,
      };
    },
  },
  {
    id: 'resize-observer',
    name: 'Resize Observer',
    category: 'api',
    level: 5,
    description: 'Element resize detection',
    test: async () => {
      const supported = typeof ResizeObserver !== 'undefined';
      return {
        supported: supported ? 'full' : 'none',
        details: `ResizeObserver: ${supported}`,
        score: supported ? 100 : 0,
      };
    },
  },
  {
    id: 'web-workers',
    name: 'Web Workers',
    category: 'api',
    level: 5,
    description: 'Background thread execution',
    test: async () => {
      const supported = typeof Worker !== 'undefined';
      return {
        supported: supported ? 'full' : 'none',
        details: `Worker API: ${supported}`,
        score: supported ? 100 : 0,
      };
    },
  },

  // LEVEL 6: Complex Features
  {
    id: 'webgl',
    name: 'WebGL',
    category: 'api',
    level: 6,
    description: 'Hardware-accelerated graphics',
    test: async () => {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      
      return {
        supported: gl ? 'full' : 'none',
        details: `WebGL context: ${!!gl}`,
        score: gl ? 100 : 0,
      };
    },
  },
  {
    id: 'indexeddb',
    name: 'IndexedDB',
    category: 'api',
    level: 6,
    description: 'Client-side database',
    test: async () => {
      const supported = typeof indexedDB !== 'undefined';
      return {
        supported: supported ? 'full' : 'none',
        details: `IndexedDB: ${supported}`,
        score: supported ? 100 : 0,
      };
    },
  },

  // SECURITY
  {
    id: 'crypto-api',
    name: 'Web Crypto API',
    category: 'security',
    level: 5,
    description: 'Cryptographic operations',
    test: async () => {
      const supported = typeof crypto !== 'undefined' && typeof crypto.subtle !== 'undefined';
      return {
        supported: supported ? 'full' : 'none',
        details: `crypto.subtle: ${supported}`,
        score: supported ? 100 : 0,
      };
    },
  },
  {
    id: 'subresource-integrity',
    name: 'Subresource Integrity',
    category: 'security',
    level: 5,
    description: 'SRI attribute support',
    test: async () => {
      const script = document.createElement('script');
      const supported = 'integrity' in script;
      return {
        supported: supported ? 'full' : 'none',
        details: `integrity attribute: ${supported}`,
        score: supported ? 100 : 0,
      };
    },
  },

  // PERSIAN/RTL
  {
    id: 'rtl-direction',
    name: 'RTL Direction Support',
    category: 'persian',
    level: 2,
    description: 'Right-to-left text direction',
    test: async () => {
      const div = document.createElement('div');
      div.dir = 'rtl';
      div.textContent = 'سلام';
      document.body.appendChild(div);
      
      const computed = window.getComputedStyle(div).direction;
      document.body.removeChild(div);
      
      return {
        supported: computed === 'rtl' ? 'full' : 'none',
        details: `direction: ${computed}`,
        score: computed === 'rtl' ? 100 : 0,
      };
    },
  },
  {
    id: 'unicode-bidi',
    name: 'Unicode Bidirectional Algorithm',
    category: 'persian',
    level: 3,
    description: 'Mixed LTR/RTL text handling',
    test: async () => {
      const supported = CSS.supports('unicode-bidi', 'plaintext');
      return {
        supported: supported ? 'full' : 'partial',
        details: `unicode-bidi: plaintext: ${supported}`,
        score: supported ? 100 : 50,
      };
    },
  },
];

// === TEST RUNNER ===

class CompatibilityTestSuite {
  /**
   * Run all compatibility tests
   */
  async runAllTests(): Promise<CompatibilityReport> {
    const results = new Map<string, TestResult>();
    
    for (const test of tests) {
      try {
        const result = await test.test();
        results.set(test.id, result);
      } catch (error) {
        results.set(test.id, {
          supported: 'none',
          details: `Test failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
          score: 0,
        });
      }
    }

    const summary = this.calculateSummary(results);

    return {
      timestamp: Date.now(),
      userAgent: navigator.userAgent,
      results,
      summary,
    };
  }

  /**
   * Run tests for a specific level
   */
  async runLevelTests(level: 1 | 2 | 3 | 4 | 5 | 6): Promise<CompatibilityReport> {
    const levelTests = tests.filter(t => t.level === level);
    const results = new Map<string, TestResult>();
    
    for (const test of levelTests) {
      try {
        const result = await test.test();
        results.set(test.id, result);
      } catch (error) {
        results.set(test.id, {
          supported: 'none',
          details: `Test failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
          score: 0,
        });
      }
    }

    const summary = this.calculateSummary(results);

    return {
      timestamp: Date.now(),
      userAgent: navigator.userAgent,
      results,
      summary,
    };
  }

  /**
   * Run tests for a specific category
   */
  async runCategoryTests(category: 'html' | 'css' | 'js' | 'api' | 'security' | 'persian'): Promise<CompatibilityReport> {
    const categoryTests = tests.filter(t => t.category === category);
    const results = new Map<string, TestResult>();
    
    for (const test of categoryTests) {
      try {
        const result = await test.test();
        results.set(test.id, result);
      } catch (error) {
        results.set(test.id, {
          supported: 'none',
          details: `Test failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
          score: 0,
        });
      }
    }

    const summary = this.calculateSummary(results);

    return {
      timestamp: Date.now(),
      userAgent: navigator.userAgent,
      results,
      summary,
    };
  }

  /**
   * Calculate summary statistics
   */
  private calculateSummary(results: Map<string, TestResult>): CompatibilityReport['summary'] {
    let full = 0;
    let partial = 0;
    let none = 0;
    let totalScore = 0;

    for (const result of results.values()) {
      if (result.supported === 'full') full++;
      else if (result.supported === 'partial') partial++;
      else none++;
      
      if (result.score !== undefined) {
        totalScore += result.score;
      }
    }

    const total = results.size;
    const overallScore = total > 0 ? totalScore / total : 0;

    return {
      total,
      full,
      partial,
      none,
      overallScore: Math.round(overallScore),
    };
  }

  /**
   * Get all test definitions
   */
  getTests(): CompatibilityTest[] {
    return [...tests];
  }
}

// Singleton instance
export const compatibilityTestSuite = new CompatibilityTestSuite();
