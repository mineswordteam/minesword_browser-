/**
 * Minesword Browser Engine - Network Manager
 * 
 * Intelligently detects network connectivity states:
 * - GLOBAL_ONLINE: Full internet access
 * - LOCAL_NETWORK: Only local/internal services reachable
 * - OFFLINE: No network connectivity
 * 
 * The browser NEVER claims to bypass internet restrictions.
 * It only uses services that are actually reachable.
 */

export type NetworkState = 'GLOBAL_ONLINE' | 'LOCAL_NETWORK' | 'OFFLINE';

export interface NetworkStatus {
  state: NetworkState;
  isOnline: boolean;
  isLocalOnly: boolean;
  connectionType: string;
  effectiveType: string;
  downlink: number;
  rtt: number;
  timestamp: number;
}

export type NetworkStateListener = (status: NetworkStatus) => void;

class NetworkManager {
  private state: NetworkState = 'OFFLINE';
  private listeners: Set<NetworkStateListener> = new Set();
  private checkInterval: ReturnType<typeof setInterval> | null = null;
  private lastCheck: number = 0;
  // Real connectivity check endpoints
  // Uses well-known public endpoints that are reliable
  private checkEndpoints: string[] = [
    'https://www.gstatic.com/generate_204',
    'https://dns.cloudflare.com/cdn-cgi/trace',
  ];

  constructor() {
    this.initialize();
  }

  private initialize(): void {
    // Listen to browser online/offline events
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => this.handleConnectivityChange());
      window.addEventListener('offline', () => this.handleConnectivityChange());
      
      // Listen to Network Information API
      const connection = (navigator as any).connection;
      if (connection) {
        connection.addEventListener('change', () => this.handleConnectivityChange());
      }
    }

    // Periodic connectivity check
    this.checkInterval = setInterval(() => this.performConnectivityCheck(), 30000);
    
    // Initial check
    this.performConnectivityCheck();
  }

  private handleConnectivityChange(): void {
    this.performConnectivityCheck();
  }

  private async performConnectivityCheck(): Promise<void> {
    this.lastCheck = Date.now();
    const previousState = this.state;

    if (!navigator.onLine) {
      this.state = 'OFFLINE';
    } else {
      // Try to reach global internet
      try {
        const reachable = await this.checkGlobalConnectivity();
        if (reachable) {
          this.state = 'GLOBAL_ONLINE';
        } else {
          // Check if local network services are available
          const localReachable = await this.checkLocalConnectivity();
          this.state = localReachable ? 'LOCAL_NETWORK' : 'OFFLINE';
        }
      } catch {
        this.state = 'OFFLINE';
      }
    }

    if (this.state !== previousState) {
      this.notifyListeners();
    }
  }

  private async checkGlobalConnectivity(): Promise<boolean> {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      
      const response = await fetch('https://www.gstatic.com/generate_204', {
        method: 'HEAD',
        mode: 'no-cors',
        signal: controller.signal,
        cache: 'no-store',
      });
      
      clearTimeout(timeout);
      return response !== undefined;
    } catch {
      return false;
    }
  }

  private async checkLocalConnectivity(): Promise<boolean> {
    // Check if any local/internal services are reachable
    // This is a placeholder - in production, this would check known local endpoints
    try {
      // Try to access the current origin as a basic connectivity test
      const response = await fetch(window.location.origin, {
        method: 'HEAD',
        mode: 'same-origin',
        cache: 'no-store',
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  private notifyListeners(): void {
    const status = this.getStatus();
    this.listeners.forEach(listener => listener(status));
  }

  /**
   * Get current network status
   */
  getStatus(): NetworkStatus {
    const connection = (navigator as any).connection;
    
    return {
      state: this.state,
      isOnline: this.state !== 'OFFLINE',
      isLocalOnly: this.state === 'LOCAL_NETWORK',
      connectionType: connection?.type || 'unknown',
      effectiveType: connection?.effectiveType || '4g',
      downlink: connection?.downlink || 0,
      rtt: connection?.rtt || 0,
      timestamp: this.lastCheck,
    };
  }

  /**
   * Subscribe to network state changes
   */
  subscribe(listener: NetworkStateListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  /**
   * Force a connectivity check
   */
  async refresh(): Promise<NetworkStatus> {
    await this.performConnectivityCheck();
    return this.getStatus();
  }

  /**
   * Destroy the network manager
   */
  destroy(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
    }
    this.listeners.clear();
  }
}

// Singleton instance
export const networkManager = new NetworkManager();
