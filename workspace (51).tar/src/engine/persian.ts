/**
 * Minesword Browser Engine - Persian Text Processing
 * 
 * Handles normalization, tokenization, and text analysis for Persian/Arabic content.
 * This is a production-quality text processing module.
 */

// Persian/Arabic character normalization map
const NORMALIZATION_MAP: Record<string, string> = {
  // Arabic Yeh → Persian Yeh
  '\u064A': '\u06CC', // ي → ی
  '\u0649': '\u06CC', // ى → ی
  // Arabic Kaf → Persian Kaf
  '\u0643': '\u06A9', // ك → ک
  // Arabic digits → Persian digits
  '\u0660': '\u06F0', // ٠ → ۰
  '\u0661': '\u06F1', // ١ → ۱
  '\u0662': '\u06F2', // ٢ → ۲
  '\u0663': '\u06F3', // ٣ → ۳
  '\u0664': '\u06F4', // ٤ → ۴
  '\u0665': '\u06F5', // ٥ → ۵
  '\u0666': '\u06F6', // ٦ → ۶
  '\u0667': '\u06F7', // ٧ → ۷
  '\u0668': '\u06F8', // ٨ → ۸
  '\u0669': '\u06F9', // ٩ → ۹
  // Tatweel removal
  '\u0640': '', // ـ → (removed)
  // Various space normalization
  '\u00A0': ' ', // non-breaking space → space
  '\u200C': ' ', // zero-width non-joiner → space (for search)
  '\u200D': '', // zero-width joiner → removed
  '\u200E': '', // left-to-right mark → removed
  '\u200F': '', // right-to-left mark → removed
  // Punctuation normalization
  '\u061B': '؛', // Arabic semicolon
  '\u061F': '؟', // Arabic question mark
};

// Persian stopwords
const PERSIAN_STOPWORDS = new Set([
  'و', 'در', 'به', 'از', 'که', 'این', 'را', 'با', 'است', 'برای',
  'تا', 'اما', 'آن', 'یا', 'هم', 'نه', 'هر', 'یک', 'شد', 'بود',
  'هست', 'چون', 'چه', 'کجا', 'کی', 'چگونه', 'چرا', 'اگر', 'then',
  'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been',
  'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
  'would', 'could', 'should', 'may', 'might', 'can', 'shall',
  'of', 'in', 'on', 'at', 'to', 'for', 'with', 'by', 'from',
  'as', 'into', 'through', 'during', 'before', 'after', 'above',
  'below', 'between', 'under', 'again', 'further', 'then', 'once'
]);

/**
 * Normalize Persian text for search indexing and querying
 */
export function normalizePersianText(text: string): string {
  if (!text) return '';
  
  let normalized = text;
  
  // Apply character normalization
  for (const [from, to] of Object.entries(NORMALIZATION_MAP)) {
    normalized = normalized.split(from).join(to);
  }
  
  // Remove diacritics (Arabic/Persian)
  normalized = normalized.replace(/[\u064B-\u065F\u0670]/g, '');
  
  // Normalize whitespace
  normalized = normalized.replace(/\s+/g, ' ').trim();
  
  // Convert to lowercase for English parts
  normalized = normalized.toLowerCase();
  
  return normalized;
}

/**
 * Tokenize text into words (supports Persian and English)
 */
export function tokenize(text: string): string[] {
  if (!text) return [];
  
  const normalized = normalizePersianText(text);
  
  // Split on whitespace and punctuation, keeping Persian/Arabic words intact
  const tokens = normalized
    .split(/[\s\u060C\u061B\u061F.,;:!?()[\]{}"«»\-–—]+/)
    .filter(token => token.length > 0);
  
  return tokens;
}

/**
 * Remove stopwords from token list
 */
export function removeStopwords(tokens: string[]): string[] {
  return tokens.filter(token => !PERSIAN_STOPWORDS.has(token));
}

/**
 * Simple Persian stemmer (removes common prefixes/suffixes)
 */
export function persianStem(word: string): string {
  if (!word || word.length < 3) return word;
  
  let stemmed = word;
  
  // Remove common Persian suffixes
  const suffixes = ['ها', 'های', 'تر', 'ترین', 'ی', 'ام', 'ات', 'اش', 'مان', 'تان', 'شان'];
  for (const suffix of suffixes) {
    if (stemmed.endsWith(suffix) && stemmed.length > suffix.length + 2) {
      stemmed = stemmed.slice(0, -suffix.length);
      break;
    }
  }
  
  // Remove common Persian prefixes
  const prefixes = ['می', 'بی', 'نا'];
  for (const prefix of prefixes) {
    if (stemmed.startsWith(prefix) && stemmed.length > prefix.length + 2) {
      stemmed = stemmed.slice(prefix.length);
      break;
    }
  }
  
  return stemmed;
}

/**
 * Detect if text is primarily Persian/Arabic
 */
export function detectLanguage(text: string): 'fa' | 'en' | 'mixed' | 'unknown' {
  if (!text) return 'unknown';
  
  const persianPattern = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/g;
  const latinPattern = /[a-zA-Z]/g;
  
  const persianMatches = text.match(persianPattern);
  const latinMatches = text.match(latinPattern);
  
  const persianCount = persianMatches?.length || 0;
  const latinCount = latinMatches?.length || 0;
  const total = persianCount + latinCount;
  
  if (total === 0) return 'unknown';
  
  const persianRatio = persianCount / total;
  const latinRatio = latinCount / total;
  
  if (persianRatio > 0.7) return 'fa';
  if (latinRatio > 0.7) return 'en';
  return 'mixed';
}

/**
 * Generate n-grams for fuzzy matching
 */
export function generateNgrams(text: string, n: number = 2): string[] {
  const normalized = normalizePersianText(text);
  const ngrams: string[] = [];
  
  for (let i = 0; i <= normalized.length - n; i++) {
    ngrams.push(normalized.slice(i, i + n));
  }
  
  return ngrams;
}

/**
 * Calculate similarity between two strings (Dice coefficient)
 */
export function stringSimilarity(a: string, b: string): number {
  if (a === b) return 1;
  if (a.length < 2 || b.length < 2) return 0;
  
  const ngramsA = new Set(generateNgrams(a, 2));
  const ngramsB = new Set(generateNgrams(b, 2));
  
  let intersection = 0;
  ngramsA.forEach(ngram => {
    if (ngramsB.has(ngram)) intersection++;
  });
  
  return (2 * intersection) / (ngramsA.size + ngramsB.size);
}

/**
 * Check if input is a URL
 */
export function isURL(input: string): boolean {
  const trimmed = input.trim();
  
  // Check for protocol
  if (/^https?:\/\//i.test(trimmed)) return true;
  
  // Check for domain-like pattern
  if (/^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z]{2,})+(\/.*)?$/.test(trimmed)) return true;
  
  // Check for localhost
  if (/^localhost(:\d+)?(\/.*)?$/.test(trimmed)) return true;
  
  // Check for IP address
  if (/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(:\d+)?(\/.*)?$/.test(trimmed)) return true;
  
  return false;
}

/**
 * Parse URL and extract components
 */
export function parseURL(input: string): { protocol: string; host: string; path: string; query: string; hash: string } | null {
  try {
    let url = input.trim();
    if (!/^https?:\/\//i.test(url)) {
      url = 'https://' + url;
    }
    const parsed = new URL(url);
    return {
      protocol: parsed.protocol,
      host: parsed.host,
      path: parsed.pathname,
      query: parsed.search,
      hash: parsed.hash,
    };
  } catch {
    return null;
  }
}

/**
 * Normalize URL for consistent storage
 */
export function normalizeURL(url: string): string {
  const parsed = parseURL(url);
  if (!parsed) return url;
  
  let normalized = `${parsed.protocol}//${parsed.host}${parsed.path}`;
  if (parsed.query && parsed.query !== '?') {
    normalized += parsed.query;
  }
  if (parsed.hash && parsed.hash !== '#') {
    normalized += parsed.hash;
  }
  
  // Remove trailing slash from path (except root)
  normalized = normalized.replace(/^(https?:\/\/[^/]+)\/$/, '$1');
  
  return normalized;
}
