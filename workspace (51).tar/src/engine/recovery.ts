/**
 * Minesword Browser Engine - Error Recovery
 * 
 * Handles graceful recovery from:
 * - Tab crashes
 * - Network failures
 * - Invalid content
 * - Memory pressure
 * - JavaScript errors
 * - Rendering failures
 * 
 * The goal is to keep the browser functional even when individual
 * components fail.
 */

export enum ErrorType {
  TAB_CRASH = 'TAB_CRASH',
  NETWORK_FAILURE = 'NETWORK_FAILURE',
  RENDER_FAILURE = 'RENDER_FAILURE',
  JS_ERROR = 'JS_ERROR',
  MEMORY_PRESSURE = 'MEMORY_PRESSURE',
  STORAGE_FAILURE = 'STORAGE_FAILURE',
  CONTENT_ERROR = 'CONTENT_ERROR',
  UNKNOWN = 'UNKNOWN',
}

export interface BrowserError {
  type: ErrorType;
  message: string;
  tabId?: string;
  url?: string;
  timestamp: number;
  recoverable: boolean;
  details?: unknown;
}

export type RecoveryAction =
  | { type: 'reload-tab'; tabId: string }
  | { type: 'show-error-page'; tabId: string; error: BrowserError }
  | { type: 'freeze-tab'; tabId: string }
  | { type: 'close-tab'; tabId: string }
  | { type: 'clear-cache' }
  | { type: 'reduce-performance' }
  | { type: 'notify-user'; message: string };

export type ErrorHandler = (error: BrowserError) => RecoveryAction | null;

class ErrorRecoveryManager {
  private errorHistory: BrowserError[] = [];
  private maxHistory = 50;
  private handlers: Map<ErrorType, ErrorHandler[]> = new Map();
  private crashCount = 0;
  private lastCrashTime = 0;

  constructor() {
    this.initializeDefaultHandlers();
    this.setupGlobalErrorHandlers();
  }

  /**
   * Set up default recovery handlers
   */
  private initializeDefaultHandlers(): void {
    // Tab crash handler
    this.addHandler(ErrorType.TAB_CRASH, (error) => {
      this.crashCount++;
      this.lastCrashTime = Date.now();

      if (error.tabId) {
        // If multiple crashes in short time, freeze the tab
        if (this.crashCount > 3 && Date.now() - this.lastCrashTime < 60000) {
          return { type: 'freeze-tab', tabId: error.tabId };
        }
        return { type: 'reload-tab', tabId: error.tabId };
      }
      return null;
    });

    // Network failure handler
    this.addHandler(ErrorType.NETWORK_FAILURE, (error) => {
      if (error.tabId) {
        return { type: 'show-error-page', tabId: error.tabId, error };
      }
      return null;
    });

    // Render failure handler
    this.addHandler(ErrorType.RENDER_FAILURE, (error) => {
      if (error.tabId) {
        return { type: 'reload-tab', tabId: error.tabId };
      }
      return null;
    });

    // Memory pressure handler
    this.addHandler(ErrorType.MEMORY_PRESSURE, () => {
      return { type: 'reduce-performance' };
    });

    // Storage failure handler
    this.addHandler(ErrorType.STORAGE_FAILURE, () => {
      return { type: 'clear-cache' };
    });
  }

  /**
   * Set up global error handlers
   */
  private setupGlobalErrorHandlers(): void {
    if (typeof window === 'undefined') return;

    // Global error handler
    window.addEventListener('error', (event) => {
      this.reportError({
        type: ErrorType.JS_ERROR,
        message: event.message || 'Unknown JavaScript error',
        url: event.filename,
        timestamp: Date.now(),
        recoverable: true,
        details: {
          lineno: event.lineno,
          colno: event.colno,
          error: event.error?.toString(),
        },
      });
    });

    // Unhandled promise rejection
    window.addEventListener('unhandledrejection', (event) => {
      this.reportError({
        type: ErrorType.JS_ERROR,
        message: `Unhandled promise rejection: ${event.reason}`,
        timestamp: Date.now(),
        recoverable: true,
        details: { reason: event.reason?.toString() },
      });
    });
  }

  /**
   * Add a recovery handler for an error type
   */
  addHandler(type: ErrorType, handler: ErrorHandler): void {
    if (!this.handlers.has(type)) {
      this.handlers.set(type, []);
    }
    this.handlers.get(type)!.push(handler);
  }

  /**
   * Report an error and get recovery action
   */
  reportError(error: BrowserError): RecoveryAction | null {
    // Add to history
    this.errorHistory.push(error);
    if (this.errorHistory.length > this.maxHistory) {
      this.errorHistory.shift();
    }

    // Log to console
    console.error(`[Minesword Error] ${error.type}:`, error.message, error.details);

    // Get recovery action from handlers
    const handlers = this.handlers.get(error.type) || [];
    for (const handler of handlers) {
      const action = handler(error);
      if (action) return action;
    }

    // Default action
    if (error.tabId && error.recoverable) {
      return { type: 'show-error-page', tabId: error.tabId, error };
    }

    return null;
  }

  /**
   * Get error history
   */
  getHistory(): BrowserError[] {
    return [...this.errorHistory];
  }

  /**
   * Get error statistics
   */
  getStats(): {
    totalErrors: number;
    crashCount: number;
    errorsByType: Record<ErrorType, number>;
    recentErrors: number; // Last hour
  } {
    const errorsByType: Record<ErrorType, number> = {
      [ErrorType.TAB_CRASH]: 0,
      [ErrorType.NETWORK_FAILURE]: 0,
      [ErrorType.RENDER_FAILURE]: 0,
      [ErrorType.JS_ERROR]: 0,
      [ErrorType.MEMORY_PRESSURE]: 0,
      [ErrorType.STORAGE_FAILURE]: 0,
      [ErrorType.CONTENT_ERROR]: 0,
      [ErrorType.UNKNOWN]: 0,
    };

    const oneHourAgo = Date.now() - 3600000;
    let recentErrors = 0;

    for (const error of this.errorHistory) {
      errorsByType[error.type]++;
      if (error.timestamp > oneHourAgo) {
        recentErrors++;
      }
    }

    return {
      totalErrors: this.errorHistory.length,
      crashCount: this.crashCount,
      errorsByType,
      recentErrors,
    };
  }

  /**
   * Clear error history
   */
  clearHistory(): void {
    this.errorHistory = [];
    this.crashCount = 0;
  }

  /**
   * Check if browser is in a degraded state
   */
  isDegraded(): boolean {
    const stats = this.getStats();
    
    // Degraded if too many recent errors
    if (stats.recentErrors > 10) return true;
    
    // Degraded if multiple crashes
    if (stats.crashCount > 5) return true;
    
    return false;
  }

  /**
   * Get recovery recommendations
   */
  getRecommendations(): string[] {
    const recommendations: string[] = [];
    const stats = this.getStats();

    if (stats.crashCount > 3) {
      recommendations.push('Multiple tab crashes detected. Consider restarting the browser.');
    }

    if (stats.recentErrors > 5) {
      recommendations.push('High error rate detected. Some features may be unstable.');
    }

    if (stats.errorsByType[ErrorType.MEMORY_PRESSURE] > 0) {
      recommendations.push('Memory pressure detected. Close some tabs to free memory.');
    }

    return recommendations;
  }
}

// Singleton instance
export const errorRecoveryManager = new ErrorRecoveryManager();

// === ERROR PAGE GENERATOR ===

export interface ErrorPageConfig {
  type: 'offline' | 'dns' | 'timeout' | 'tls' | 'blocked' | 'crash' | 'generic';
  url?: string;
  message?: string;
  canRetry?: boolean;
  canViewSaved?: boolean;
}

/**
 * Generate error page HTML
 */
export function generateErrorPage(config: ErrorPageConfig): string {
  const titles: Record<string, string> = {
    offline: 'اتصال برقرار نیست',
    dns: 'سایت یافت نشد',
    timeout: 'زمان انتظار به پایان رسید',
    tls: 'خطای امنیتی',
    blocked: 'دسترسی مسدود شده',
    crash: 'صفحه دچار مشکل شد',
    generic: 'خطا',
  };

  const messages: Record<string, string> = {
    offline: 'اینترنت در دسترس نیست. صفحات ذخیره‌شده همچنان قابل دسترسی هستند.',
    dns: 'آدرس سایت معتبر نیست یا در دسترس نمی‌باشد.',
    timeout: 'سرور بیش از حد منتظر ماند. لطفاً دوباره تلاش کنید.',
    tls: 'اتصال امن برقرار نشد. سایت ممکن است ناامن باشد.',
    blocked: 'این سایت اجازه نمایش در مرورگر را نمی‌دهد.',
    crash: 'این صفحه دچار مشکل شد. می‌توانید آن را دوباره بارگذاری کنید.',
    generic: config.message || 'خطایی رخ داد.',
  };

  const icons: Record<string, string> = {
    offline: '📡',
    dns: '🔍',
    timeout: '⏱️',
    tls: '🔒',
    blocked: '🚫',
    crash: '💥',
    generic: '⚠️',
  };

  return `
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${titles[config.type]}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Vazirmatn', 'Tahoma', sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .container {
      text-align: center;
      max-width: 500px;
    }
    .icon { font-size: 80px; margin-bottom: 20px; }
    h1 { font-size: 28px; margin-bottom: 15px; font-weight: 700; }
    p { font-size: 16px; opacity: 0.9; line-height: 1.8; margin-bottom: 30px; }
    .url { 
      font-size: 12px; 
      opacity: 0.6; 
      margin-bottom: 30px; 
      direction: ltr;
      word-break: break-all;
    }
    .buttons { display: flex; flex-direction: column; gap: 12px; }
    button, a {
      padding: 14px 28px;
      border: none;
      border-radius: 12px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
      text-decoration: none;
      display: inline-block;
    }
    .primary {
      background: white;
      color: #667eea;
    }
    .primary:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,0,0,0.2); }
    .secondary {
      background: rgba(255,255,255,0.2);
      color: white;
      backdrop-filter: blur(10px);
    }
    .secondary:hover { background: rgba(255,255,255,0.3); }
  </style>
</head>
<body>
  <div class="container">
    <div class="icon">${icons[config.type]}</div>
    <h1>${titles[config.type]}</h1>
    ${config.url ? `<div class="url">${config.url}</div>` : ''}
    <p>${messages[config.type]}</p>
    <div class="buttons">
      ${config.canRetry ? '<button class="primary" onclick="location.reload()">تلاش مجدد</button>' : ''}
      ${config.canViewSaved ? '<button class="secondary" onclick="window.parent.postMessage({type:\'view-saved\',url:\'' + (config.url || '') + '\'},\'*\')">مشاهده نسخه ذخیره‌شده</button>' : ''}
      <button class="secondary" onclick="window.parent.postMessage({type:\'go-home\'},\'*\')">بازگشت به صفحه اصلی</button>
    </div>
  </div>
</body>
</html>
  `.trim();
}
