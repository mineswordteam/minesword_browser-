/**
 * Minesword Browser Engine - Storage Manager
 * 
 * Handles persistent local storage for:
 * - Bookmarks
 * - History
 * - Saved pages (offline)
 * - Downloads metadata
 * - Settings
 * - Permissions
 * - Search history
 * 
 * Uses localStorage with JSON serialization.
 * In production Android, this would use encrypted SQLite.
 */

export interface Bookmark {
  id: string;
  url: string;
  title: string;
  favicon?: string;
  folder?: string;
  createdAt: number;
  updatedAt: number;
}

export interface HistoryEntry {
  id: string;
  url: string;
  title: string;
  visitedAt: number;
  visitCount: number;
}

export interface SavedPage {
  id: string;
  url: string;
  title: string;
  content: string;
  savedAt: number;
  size: number;
}

export interface DownloadItem {
  id: string;
  url: string;
  filename: string;
  mimeType: string;
  size: number;
  downloadedAt: number;
  status: 'completed' | 'paused' | 'failed' | 'downloading';
  progress: number;
}

export interface SitePermission {
  origin: string;
  camera: 'allow' | 'block' | 'ask';
  microphone: 'allow' | 'block' | 'ask';
  location: 'allow' | 'block' | 'ask';
  notifications: 'allow' | 'block' | 'ask';
  clipboard: 'allow' | 'block' | 'ask';
  updatedAt: number;
}

export interface SearchHistoryItem {
  id: string;
  query: string;
  timestamp: number;
  resultCount: number;
}

export interface BrowserSettings {
  theme: 'light' | 'dark' | 'system';
  language: 'fa' | 'en';
  searchEngine: 'minesword' | 'duckduckgo' | 'bing';
  privateMode: boolean;
  trackingProtection: boolean;
  thirdPartyCookies: boolean;
  javascriptEnabled: boolean;
  imageLoading: boolean;
  performanceLevel: 'low' | 'balanced' | 'high';
  fontSize: number;
  animationsEnabled: boolean;
  telemetryEnabled: boolean;
}

const DEFAULT_SETTINGS: BrowserSettings = {
  theme: 'system',
  language: 'fa',
  searchEngine: 'minesword',
  privateMode: false,
  trackingProtection: true,
  thirdPartyCookies: false,
  javascriptEnabled: true,
  imageLoading: true,
  performanceLevel: 'balanced',
  fontSize: 16,
  animationsEnabled: true,
  telemetryEnabled: false,
};

const STORAGE_KEYS = {
  BOOKMARKS: 'minesword_bookmarks',
  HISTORY: 'minesword_history',
  SAVED_PAGES: 'minesword_saved_pages',
  DOWNLOADS: 'minesword_downloads',
  SETTINGS: 'minesword_settings',
  PERMISSIONS: 'minesword_permissions',
  SEARCH_HISTORY: 'minesword_search_history',
  TABS_STATE: 'minesword_tabs_state',
};

class StorageManager {
  /**
   * Generic get/set with JSON serialization
   */
  private get<T>(key: string, defaultValue: T): T {
    try {
      const data = localStorage.getItem(key);
      if (data === null) return defaultValue;
      return JSON.parse(data) as T;
    } catch {
      return defaultValue;
    }
  }

  private set<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error('Storage write failed:', e);
    }
  }

  // === BOOKMARKS ===
  
  getBookmarks(): Bookmark[] {
    return this.get<Bookmark[]>(STORAGE_KEYS.BOOKMARKS, []);
  }

  addBookmark(bookmark: Omit<Bookmark, 'id' | 'createdAt' | 'updatedAt'>): Bookmark {
    const bookmarks = this.getBookmarks();
    const newBookmark: Bookmark = {
      ...bookmark,
      id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2),
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    bookmarks.unshift(newBookmark);
    this.set(STORAGE_KEYS.BOOKMARKS, bookmarks);
    return newBookmark;
  }

  removeBookmark(id: string): void {
    const bookmarks = this.getBookmarks().filter(b => b.id !== id);
    this.set(STORAGE_KEYS.BOOKMARKS, bookmarks);
  }

  isBookmarked(url: string): boolean {
    return this.getBookmarks().some(b => b.url === url);
  }

  // === HISTORY ===
  
  getHistory(): HistoryEntry[] {
    return this.get<HistoryEntry[]>(STORAGE_KEYS.HISTORY, []);
  }

  addHistoryEntry(url: string, title: string): void {
    const history = this.getHistory();
    const existing = history.find(h => h.url === url);
    
    if (existing) {
      existing.visitedAt = Date.now();
      existing.visitCount++;
      existing.title = title || existing.title;
    } else {
      history.unshift({
        id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2),
        url,
        title,
        visitedAt: Date.now(),
        visitCount: 1,
      });
    }
    
    // Keep max 1000 entries
    if (history.length > 1000) {
      history.splice(1000);
    }
    
    this.set(STORAGE_KEYS.HISTORY, history);
  }

  clearHistory(): void {
    this.set(STORAGE_KEYS.HISTORY, []);
  }

  // === SAVED PAGES ===
  
  getSavedPages(): SavedPage[] {
    return this.get<SavedPage[]>(STORAGE_KEYS.SAVED_PAGES, []);
  }

  savePage(page: Omit<SavedPage, 'id' | 'savedAt'>): SavedPage {
    const pages = this.getSavedPages();
    const newPage: SavedPage = {
      ...page,
      id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2),
      savedAt: Date.now(),
    };
    pages.unshift(newPage);
    this.set(STORAGE_KEYS.SAVED_PAGES, pages);
    return newPage;
  }

  removeSavedPage(id: string): void {
    const pages = this.getSavedPages().filter(p => p.id !== id);
    this.set(STORAGE_KEYS.SAVED_PAGES, pages);
  }

  // === DOWNLOADS ===
  
  getDownloads(): DownloadItem[] {
    return this.get<DownloadItem[]>(STORAGE_KEYS.DOWNLOADS, []);
  }

  addDownload(download: Omit<DownloadItem, 'id' | 'downloadedAt'>): DownloadItem {
    const downloads = this.getDownloads();
    const newDownload: DownloadItem = {
      ...download,
      id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2),
      downloadedAt: Date.now(),
    };
    downloads.unshift(newDownload);
    this.set(STORAGE_KEYS.DOWNLOADS, downloads);
    return newDownload;
  }

  // === SETTINGS ===
  
  getSettings(): BrowserSettings {
    const stored = this.get<Partial<BrowserSettings>>(STORAGE_KEYS.SETTINGS, {});
    return { ...DEFAULT_SETTINGS, ...stored };
  }

  updateSettings(partial: Partial<BrowserSettings>): BrowserSettings {
    const current = this.getSettings();
    const updated = { ...current, ...partial };
    this.set(STORAGE_KEYS.SETTINGS, updated);
    return updated;
  }

  // === PERMISSIONS ===
  
  getPermissions(): SitePermission[] {
    return this.get<SitePermission[]>(STORAGE_KEYS.PERMISSIONS, []);
  }

  setPermission(permission: Omit<SitePermission, 'updatedAt'>): void {
    const permissions = this.getPermissions();
    const existing = permissions.findIndex(p => p.origin === permission.origin);
    const updated: SitePermission = { ...permission, updatedAt: Date.now() };
    
    if (existing >= 0) {
      permissions[existing] = updated;
    } else {
      permissions.push(updated);
    }
    
    this.set(STORAGE_KEYS.PERMISSIONS, permissions);
  }

  getPermissionForOrigin(origin: string): SitePermission | null {
    return this.getPermissions().find(p => p.origin === origin) || null;
  }

  // === SEARCH HISTORY ===
  
  getSearchHistory(): SearchHistoryItem[] {
    return this.get<SearchHistoryItem[]>(STORAGE_KEYS.SEARCH_HISTORY, []);
  }

  addSearchHistory(query: string, resultCount: number): void {
    const history = this.getSearchHistory();
    history.unshift({
      id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2),
      query,
      timestamp: Date.now(),
      resultCount,
    });
    
    // Keep max 200 entries
    if (history.length > 200) {
      history.splice(200);
    }
    
    this.set(STORAGE_KEYS.SEARCH_HISTORY, history);
  }

  clearSearchHistory(): void {
    this.set(STORAGE_KEYS.SEARCH_HISTORY, []);
  }

  // === TABS STATE ===
  
  getTabsState(): any[] {
    return this.get<any[]>(STORAGE_KEYS.TABS_STATE, []);
  }

  saveTabsState(tabs: any[]): void {
    this.set(STORAGE_KEYS.TABS_STATE, tabs);
  }

  // === CLEAR ALL DATA ===
  
  clearAllData(): void {
    Object.values(STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
  }

  /**
   * Get storage usage estimate
   */
  getStorageEstimate(): { used: number; quota: number } {
    let used = 0;
    for (const key of Object.values(STORAGE_KEYS)) {
      const item = localStorage.getItem(key);
      if (item) used += item.length * 2; // UTF-16
    }
    return { used, quota: 10 * 1024 * 1024 }; // 10MB estimate
  }
}

// Singleton instance
export const storageManager = new StorageManager();
