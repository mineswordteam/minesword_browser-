/**
 * Minesword Search Engine
 * 
 * A modular search system designed for Persian-first search quality.
 * 
 * CURRENT STATUS:
 * - Local search: Searches content the user has explicitly saved/indexed
 * - Web search: Routes queries to external providers (DuckDuckGo, Bing, Google)
 * - NO pre-loaded test data or mock results
 * 
 * The local search engine provides:
 * - Persian text normalization (ي→ی, ك→ک, digit conversion)
 * - Tokenization supporting mixed Persian/English
 * - Stopword removal
 * - Simple Persian stemming
 * - Inverted index with TF-IDF-inspired ranking
 * - Fuzzy matching for typo tolerance
 * 
 * Architecture is designed to be replaceable with a production backend.
 */

import { normalizePersianText, tokenize, removeStopwords, persianStem, stringSimilarity, detectLanguage } from './persian';
import { storageManager } from './storage';

export interface SearchDocument {
  id: string;
  url: string;
  title: string;
  body: string;
  headings: string[];
  language: 'fa' | 'en' | 'mixed';
  publishDate?: number;
  quality: number; // 0-1
  category?: string;
  source: 'user-saved' | 'cached' | 'indexed';
  indexedAt: number;
}

export interface SearchResult {
  document: SearchDocument;
  score: number;
  snippet: string;
  highlights: string[];
}

export interface SearchResponse {
  query: string;
  normalizedQuery: string;
  results: SearchResult[];
  totalResults: number;
  searchTime: number;
  correctedQuery?: string;
  relatedSearches: string[];
  searchProvider: 'local' | 'duckduckgo' | 'bing' | 'google';
  isLocalIndex: boolean;
  webSearchUrl?: string;
}

/**
 * Minesword Local Search Engine
 * 
 * Searches ONLY content the user has saved or indexed.
 * Returns empty results when no local content exists.
 */
class MineswordLocalSearchEngine {
  private invertedIndex: Map<string, Set<string>> = new Map();
  private documentStore: Map<string, SearchDocument> = new Map();

  constructor() {
    this.loadFromStorage();
  }

  /**
   * Load indexed documents from persistent storage
   */
  private loadFromStorage(): void {
    try {
      const stored = localStorage.getItem('minesword_search_index');
      if (stored) {
        const docs: SearchDocument[] = JSON.parse(stored);
        for (const doc of docs) {
          this.documentStore.set(doc.id, doc);
        }
        this.buildIndex();
      }
    } catch (e) {
      console.error('Failed to load search index:', e);
    }
  }

  /**
   * Persist index to storage
   */
  private saveToStorage(): void {
    try {
      const docs = Array.from(this.documentStore.values());
      localStorage.setItem('minesword_search_index', JSON.stringify(docs));
    } catch (e) {
      console.error('Failed to save search index:', e);
    }
  }

  /**
   * Build inverted index from document store
   */
  private buildIndex(): void {
    this.invertedIndex.clear();

    for (const doc of this.documentStore.values()) {
      const allText = [doc.title, ...doc.headings, doc.body].join(' ');
      const tokens = removeStopwords(tokenize(allText));
      
      const allTokens = new Set<string>();
      for (const token of tokens) {
        allTokens.add(token);
        const stemmed = persianStem(token);
        if (stemmed !== token) {
          allTokens.add(stemmed);
        }
      }

      for (const token of allTokens) {
        if (!this.invertedIndex.has(token)) {
          this.invertedIndex.set(token, new Set());
        }
        this.invertedIndex.get(token)!.add(doc.id);
      }
    }
  }

  /**
   * Index a document (user-saved content)
   */
  indexDocument(doc: Omit<SearchDocument, 'id' | 'indexedAt'>): SearchDocument {
    const newDoc: SearchDocument = {
      ...doc,
      id: `doc-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      indexedAt: Date.now(),
    };
    this.documentStore.set(newDoc.id, newDoc);
    this.buildIndex();
    this.saveToStorage();
    return newDoc;
  }

  /**
   * Remove a document from the index
   */
  removeDocument(id: string): void {
    this.documentStore.delete(id);
    this.buildIndex();
    this.saveToStorage();
  }

  /**
   * Clear the entire index
   */
  clearIndex(): void {
    this.documentStore.clear();
    this.invertedIndex.clear();
    this.saveToStorage();
  }

  /**
   * Search local index
   * Returns empty results if no content is indexed
   */
  search(query: string): SearchResponse {
    const startTime = performance.now();
    const normalizedQuery = normalizePersianText(query);
    
    // Get candidate documents from index
    const candidates = this.getCandidates(normalizedQuery);
    
    // Score and rank
    const scored = this.scoreDocuments(candidates, normalizedQuery, query);
    
    // Sort by score
    scored.sort((a, b) => b.score - a.score);
    
    // Generate snippets
    const results = scored.slice(0, 20).map(item => ({
      document: item.document,
      score: item.score,
      snippet: this.generateSnippet(item.document, normalizedQuery),
      highlights: this.getHighlights(item.document, normalizedQuery),
    }));

    const searchTime = performance.now() - startTime;

    return {
      query,
      normalizedQuery,
      results,
      totalResults: results.length,
      searchTime,
      relatedSearches: [],
      searchProvider: 'local',
      isLocalIndex: true,
    };
  }

  /**
   * Get candidate documents using inverted index
   */
  private getCandidates(query: string): SearchDocument[] {
    const queryTokens = removeStopwords(tokenize(query));
    const candidateIds = new Set<string>();

    for (const token of queryTokens) {
      // Direct match
      const directMatches = this.invertedIndex.get(token);
      if (directMatches) {
        directMatches.forEach(id => candidateIds.add(id));
      }

      // Stemmed match
      const stemmed = persianStem(token);
      const stemmedMatches = this.invertedIndex.get(stemmed);
      if (stemmedMatches) {
        stemmedMatches.forEach(id => candidateIds.add(id));
      }

      // Fuzzy match for typo tolerance
      for (const [indexToken, docIds] of this.invertedIndex) {
        if (stringSimilarity(token, indexToken) > 0.7) {
          docIds.forEach(id => candidateIds.add(id));
        }
      }
    }

    return Array.from(candidateIds)
      .map(id => this.documentStore.get(id))
      .filter((doc): doc is SearchDocument => doc !== undefined);
  }

  /**
   * Score documents using multiple ranking signals
   */
  private scoreDocuments(
    candidates: SearchDocument[],
    normalizedQuery: string,
    originalQuery: string
  ): Array<{ document: SearchDocument; score: number }> {
    const queryTokens = removeStopwords(tokenize(normalizedQuery));

    return candidates.map(doc => {
      let score = 0;

      // Title relevance (high weight)
      const normalizedTitle = normalizePersianText(doc.title);
      for (const qt of queryTokens) {
        if (normalizedTitle.includes(qt)) score += 3.0;
      }

      // Heading relevance
      for (const heading of doc.headings) {
        const normalizedHeading = normalizePersianText(heading);
        for (const qt of queryTokens) {
          if (normalizedHeading.includes(qt)) score += 1.5;
        }
      }

      // Body relevance
      const normalizedBody = normalizePersianText(doc.body);
      for (const qt of queryTokens) {
        const escaped = qt.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const bodyMatches = (normalizedBody.match(new RegExp(escaped, 'g')) || []).length;
        score += Math.min(bodyMatches * 0.5, 3.0);
      }

      // Document quality
      score *= (0.5 + doc.quality * 0.5);

      // Freshness
      if (doc.publishDate) {
        const daysSincePublish = (Date.now() - doc.publishDate) / 86400000;
        const freshnessBoost = Math.max(0, 1 - daysSincePublish / 90);
        score *= (1 + freshnessBoost * 0.3);
      }

      // Language match
      const queryLang = detectLanguage(originalQuery);
      if (queryLang === doc.language || queryLang === 'mixed') {
        score *= 1.2;
      }

      // Exact phrase bonus
      if (normalizedQuery.length > 3 && normalizedBody.includes(normalizedQuery)) {
        score += 2.0;
      }

      return { document: doc, score };
    }).filter(item => item.score > 0);
  }

  /**
   * Generate text snippet
   */
  private generateSnippet(doc: SearchDocument, normalizedQuery: string): string {
    const body = doc.body;
    const queryTokens = tokenize(normalizedQuery);
    
    let bestPos = 0;
    let maxMatches = 0;
    
    for (let i = 0; i < body.length - 50; i++) {
      const window = body.slice(i, i + 200);
      let matches = 0;
      for (const token of queryTokens) {
        if (window.includes(token)) matches++;
      }
      if (matches > maxMatches) {
        maxMatches = matches;
        bestPos = i;
      }
    }

    const start = Math.max(0, bestPos - 30);
    const end = Math.min(body.length, start + 160);
    let snippet = body.slice(start, end);
    
    if (start > 0) snippet = '...' + snippet;
    if (end < body.length) snippet = snippet + '...';

    return snippet;
  }

  /**
   * Get highlighted terms
   */
  private getHighlights(doc: SearchDocument, normalizedQuery: string): string[] {
    const queryTokens = tokenize(normalizedQuery);
    const highlights: string[] = [];
    const allText = normalizePersianText([doc.title, ...doc.headings, doc.body].join(' '));
    
    for (const token of queryTokens) {
      if (allText.includes(token)) {
        highlights.push(token);
      }
    }
    
    return highlights;
  }

  /**
   * Get search suggestions from indexed content
   */
  getSuggestions(query: string, limit: number = 8): string[] {
    if (!query || query.length < 1) return [];
    
    const normalized = normalizePersianText(query);
    const suggestions = new Set<string>();

    for (const doc of this.documentStore.values()) {
      const normalizedTitle = normalizePersianText(doc.title);
      if (normalizedTitle.includes(normalized)) {
        suggestions.add(doc.title);
      }
    }

    return Array.from(suggestions).slice(0, limit);
  }

  /**
   * Get index statistics
   */
  getIndexStats(): { documentCount: number; indexSize: number } {
    return {
      documentCount: this.documentStore.size,
      indexSize: this.invertedIndex.size,
    };
  }
}

/**
 * Generate web search URL for external providers
 */
export function getWebSearchUrl(query: string, provider: 'duckduckgo' | 'bing' | 'google'): string {
  const encoded = encodeURIComponent(query);
  switch (provider) {
    case 'duckduckgo':
      return `https://duckduckgo.com/?q=${encoded}`;
    case 'bing':
      return `https://www.bing.com/search?q=${encoded}`;
    case 'google':
      return `https://www.google.com/search?q=${encoded}`;
    default:
      return `https://duckduckgo.com/?q=${encoded}`;
  }
}

// Singleton instance
export const localSearchEngine = new MineswordLocalSearchEngine();
