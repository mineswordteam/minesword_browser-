/**
 * Minesword Browser Engine
 * 
 * Central export for all engine modules.
 * This is the public API of the engine layer.
 */

// Network
export { networkManager } from './network';
export type { NetworkState, NetworkStatus, NetworkStateListener } from './network';

// Networking (HTTP client)
export { networkClient, NetworkError, NetworkErrorType } from './networking';
export type { RequestOptions, NetworkResponse, RequestTiming } from './networking';

// Storage
export { storageManager } from './storage';
export type {
  Bookmark,
  HistoryEntry,
  SavedPage,
  DownloadItem,
  SitePermission,
  SearchHistoryItem,
  BrowserSettings,
} from './storage';

// Search
export { localSearchEngine, getWebSearchUrl } from './search';
export type { SearchDocument, SearchResult, SearchResponse } from './search';

// Persian text processing
export {
  normalizePersianText,
  tokenize,
  removeStopwords,
  persianStem,
  detectLanguage,
  generateNgrams,
  stringSimilarity,
  isURL,
  parseURL,
  normalizeURL,
} from './persian';

// Security
export {
  parseCSP,
  isURLAllowedByCSP,
  getSandboxConfig,
  sandboxToString,
  checkURLSafety,
  checkMixedContent,
  parseCookieHeader,
  shouldAcceptCookie,
  permissionManager,
  getSecurityHeaders,
  isRedirectSafe,
} from './security';
export type {
  CSPPolicy,
  SandboxFlag,
  URLSafetyResult,
  MixedContentCheck,
  CookieAttributes,
  PermissionName,
  PermissionState,
  PermissionDescriptor,
} from './security';

// Performance
export { performanceMonitor } from './performance';
export type { PerformanceMetrics, PerformanceSnapshot, PerformanceLevel } from './performance';

// Compatibility
export { compatibilityTestSuite } from './compatibility';
export type { CompatibilityTest, TestResult, CompatibilityReport } from './compatibility';

// Error Recovery
export { errorRecoveryManager, generateErrorPage, ErrorType } from './recovery';
export type { BrowserError, RecoveryAction, ErrorPageConfig } from './recovery';
