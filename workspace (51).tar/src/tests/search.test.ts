/**
 * Minesword Iranian Search Engine - Comprehensive Tests
 * 
 * تست‌های جامع موتور جستجوی ایرانی ماینسورد
 */

import { iranianSearchEngine } from '../engine/iranian-search';

console.log('=== Minesword Iranian Search Engine - Tests ===\n');

let passed = 0;
let failed = 0;

function test(name: string, fn: () => void) {
  try {
    fn();
    console.log(`✓ ${name}`);
    passed++;
  } catch (error) {
    console.error(`✗ ${name}`);
    console.error(`  Error: ${error instanceof Error ? error.message : error}`);
    failed++;
  }
}

function assert(condition: boolean, message: string) {
  if (!condition) {
    throw new Error(message);
  }
}

// === BASIC SEARCH TESTS ===

console.log('\n--- Basic Search Tests ---\n');

test('Search for "روبیکا" returns Rubika site', () => {
  const results = iranianSearchEngine.search('روبیکا');
  assert(results.results.length > 0, 'Should return results');
  assert(results.results[0].site.id === 'ir-001', 'First result should be Rubika');
  assert(results.results[0].matchType === 'exact', 'Should be exact match');
});

test('Search for "دیجی‌کالا" returns Digikala site', () => {
  const results = iranianSearchEngine.search('دیجی‌کالا');
  assert(results.results.length > 0, 'Should return results');
  assert(results.results[0].site.id === 'ir-007', 'First result should be Digikala');
});

test('Search for "اخبار" returns news sites', () => {
  const results = iranianSearchEngine.search('اخبار');
  assert(results.results.length > 0, 'Should return results');
  const categories = results.results.map(r => r.site.category);
  assert(categories.includes('اخبار'), 'Should include news category');
});

// === TOPIC DETECTION TESTS ===

console.log('\n--- Topic Detection Tests ---\n');

test('Search for "جنگ های صلیبی" does NOT return shopping sites', () => {
  const results = iranianSearchEngine.search('جنگ های صلیبی');
  const categories = results.results.map(r => r.site.category);
  assert(!categories.includes('فروشگاه'), 'Should NOT include shopping category');
});

test('Search for "فوتبال" returns sports sites', () => {
  const results = iranianSearchEngine.search('فوتبال');
  assert(results.results.length > 0, 'Should return results');
  const hasSports = results.results.some(r => 
    r.site.category === 'ورزش' || 
    r.site.topics?.includes('ورزش') ||
    r.site.topics?.includes('فوتبال')
  );
  assert(hasSports, 'Should include sports-related sites');
});

test('Search for "آموزش برنامه‌نویسی" returns educational sites', () => {
  const results = iranianSearchEngine.search('آموزش برنامه‌نویسی');
  assert(results.results.length > 0, 'Should return results');
  const hasEducation = results.results.some(r => 
    r.site.isEducational || 
    r.site.topics?.includes('آموزش')
  );
  assert(hasEducation, 'Should include educational sites');
});

// === BM25 ALGORITHM TESTS ===

console.log('\n--- BM25 Algorithm Tests ---\n');

test('BM25 gives higher score to sites with more relevant content', () => {
  const results = iranianSearchEngine.search('پیام‌رسان');
  assert(results.results.length > 0, 'Should return results');
  
  // Messenger sites should be at the top
  const messengerSites = results.results.filter(r => 
    r.site.category === 'پیام‌رسان'
  );
  assert(messengerSites.length > 0, 'Should find messenger sites');
  
  // First result should be a messenger
  assert(results.results[0].site.category === 'پیام‌رسان', 
    'First result should be a messenger site');
});

test('BM25 considers document length normalization', () => {
  const results = iranianSearchEngine.search('خرید');
  assert(results.results.length > 0, 'Should return results');
  
  // Shopping sites should rank high
  const shoppingSites = results.results.filter(r => 
    r.site.isShopping || r.site.category === 'فروشگاه'
  );
  assert(shoppingSites.length > 0, 'Should find shopping sites');
});

// === EXACT PHRASE MATCHING TESTS ===

console.log('\n--- Exact Phrase Matching Tests ---\n');

test('Exact phrase "ثبت آگهی" matches Divar', () => {
  const results = iranianSearchEngine.search('ثبت آگهی');
  assert(results.results.length > 0, 'Should return results');
  
  const divarResult = results.results.find(r => r.site.id === 'ir-008');
  assert(divarResult !== undefined, 'Should find Divar');
  assert(divarResult!.matchType === 'exact' || divarResult!.score > 5, 
    'Should have high score or exact match');
});

test('Partial match "آگهی" still finds Divar', () => {
  const results = iranianSearchEngine.search('آگهی');
  assert(results.results.length > 0, 'Should return results');
  
  const divarResult = results.results.find(r => r.site.id === 'ir-008');
  assert(divarResult !== undefined, 'Should find Divar');
});

// === KEYWORD MATCHING TESTS ===

console.log('\n--- Keyword Matching Tests ---\n');

test('Keywords help find relevant sites', () => {
  const results = iranianSearchEngine.search('تاکسی');
  assert(results.results.length > 0, 'Should return results');
  
  const hasTaxi = results.results.some(r => 
    r.site.keywords?.includes('تاکسی') ||
    r.site.tags.includes('تاکسی')
  );
  assert(hasTaxi, 'Should find sites with taxi keyword');
});

test('Tags improve search relevance', () => {
  const results = iranianSearchEngine.search('ویدیو');
  assert(results.results.length > 0, 'Should return results');
  
  const hasVideo = results.results.some(r => 
    r.site.tags.includes('ویدیو') ||
    r.site.topics?.includes('ویدیو')
  );
  assert(hasVideo, 'Should find sites with video tag');
});

// === QUALITY AND POPULARITY TESTS ===

console.log('\n--- Quality and Popularity Tests ---\n');

test('High quality sites rank higher', () => {
  const results = iranianSearchEngine.search('اخبار');
  assert(results.results.length > 0, 'Should return results');
  
  // High quality news sites should be at top
  const topResults = results.results.slice(0, 3);
  const avgQuality = topResults.reduce((sum, r) => sum + r.site.quality, 0) / topResults.length;
  assert(avgQuality > 0.85, 'Top results should have high quality');
});

test('Popular sites get boost in ranking', () => {
  const results = iranianSearchEngine.search('فروشگاه');
  assert(results.results.length > 0, 'Should return results');
  
  // Digikala (popularity: 0.95) should rank high
  const digikalaIndex = results.results.findIndex(r => r.site.id === 'ir-007');
  assert(digikalaIndex !== -1, 'Should find Digikala');
  assert(digikalaIndex < 3, 'Digikala should be in top 3');
});

// === PERSIAN TEXT PROCESSING TESTS ===

console.log('\n--- Persian Text Processing Tests ---\n');

test('Arabic Yeh (ي) is normalized to Persian Yeh (ی)', () => {
  const results = iranianSearchEngine.search('ديجى‌كالا');
  assert(results.results.length > 0, 'Should return results');
  
  const digikalaResult = results.results.find(r => r.site.id === 'ir-007');
  assert(digikalaResult !== undefined, 'Should find Digikala despite Arabic characters');
});

test('Arabic Kaf (ك) is normalized to Persian Kaf (ک)', () => {
  const results = iranianSearchEngine.search('كتاب');
  // Should not crash and should return some results
  assert(results.searchTime > 0, 'Search should complete');
});

test('Zero-width non-joiner is handled', () => {
  const results = iranianSearchEngine.search('برنامه‌نویسی');
  assert(results.searchTime > 0, 'Search should complete');
});

// === RELATED SEARCHES TESTS ===

console.log('\n--- Related Searches Tests ---\n');

test('Related searches are generated', () => {
  const results = iranianSearchEngine.search('اخبار');
  assert(results.relatedSearches.length > 0, 'Should generate related searches');
  assert(results.relatedSearches.length <= 5, 'Should not exceed 5 related searches');
});

test('Related searches are relevant', () => {
  const results = iranianSearchEngine.search('فوتبال');
  assert(results.relatedSearches.length > 0, 'Should generate related searches');
  
  // Related searches should contain relevant terms
  const hasRelevant = results.relatedSearches.some(rs => 
    rs.includes('ورزش') || rs.includes('تیم') || rs.includes('بازی')
  );
  assert(hasRelevant, 'Related searches should be relevant');
});

// === PERFORMANCE TESTS ===

console.log('\n--- Performance Tests ---\n');

test('Search completes in reasonable time', () => {
  const start = performance.now();
  iranianSearchEngine.search('تست');
  const duration = performance.now() - start;
  
  assert(duration < 100, `Search should complete in < 100ms (took ${duration}ms)`);
});

test('Multiple searches maintain performance', () => {
  const queries = ['اخبار', 'فروشگاه', 'آموزش', 'ورزش', 'تکنولوژی'];
  const start = performance.now();
  
  for (const query of queries) {
    iranianSearchEngine.search(query);
  }
  
  const duration = performance.now() - start;
  const avgTime = duration / queries.length;
  
  assert(avgTime < 50, `Average search time should be < 50ms (was ${avgTime}ms)`);
});

// === EDGE CASES ===

console.log('\n--- Edge Cases ---\n');

test('Empty query returns empty results', () => {
  const results = iranianSearchEngine.search('');
  assert(results.results.length === 0, 'Empty query should return no results');
});

test('Very long query does not crash', () => {
  const longQuery = 'تست '.repeat(100);
  const results = iranianSearchEngine.search(longQuery);
  assert(results.searchTime > 0, 'Should handle long query');
});

test('Special characters are handled', () => {
  const results = iranianSearchEngine.search('تست@#$%');
  assert(results.searchTime > 0, 'Should handle special characters');
});

test('Mixed Persian and English query works', () => {
  const results = iranianSearchEngine.search('تست test');
  assert(results.searchTime > 0, 'Should handle mixed language query');
});

// === SUMMARY ===

console.log('\n=== Test Summary ===\n');
console.log(`Total: ${passed + failed}`);
console.log(`Passed: ${passed}`);
console.log(`Failed: ${failed}`);
console.log(`Success Rate: ${((passed / (passed + failed)) * 100).toFixed(1)}%`);

if (failed > 0) {
  console.log('\n❌ Some tests failed');
  throw new Error(`${failed} tests failed`);
} else {
  console.log('\n✅ All tests passed!');
}
