/**
 * Minesword Browser - Quick Test
 * 
 * Test the search functionality
 */

import { localSearchEngine, getWebSearchUrl } from '../engine/search';
import { isURL } from '../engine/persian';

console.log('=== Minesword Browser - Quick Test ===\n');

// Test 1: URL detection
console.log('Test 1: URL Detection');
console.log('  "https://example.com" →', isURL('https://example.com'));
console.log('  "example.com" →', isURL('example.com'));
console.log('  "بهترین لپ تاپ" →', isURL('بهترین لپ تاپ'));
console.log('  "best laptop" →', isURL('best laptop'));

// Test 2: Local search (should be empty)
console.log('\nTest 2: Local Search (Empty Index)');
const localResults = localSearchEngine.search('بهترین لپ تاپ');
console.log('  Query: "بهترین لپ تاپ"');
console.log('  Results:', localResults.totalResults);
console.log('  Is Local Index:', localResults.isLocalIndex);

// Test 3: Web search URL generation
console.log('\nTest 3: Web Search URLs');
console.log('  DuckDuckGo:', getWebSearchUrl('بهترین لپ تاپ', 'duckduckgo'));
console.log('  Bing:', getWebSearchUrl('بهترین لپ تاپ', 'bing'));
console.log('  Google:', getWebSearchUrl('بهترین لپ تاپ', 'google'));

// Test 4: Search flow simulation
console.log('\nTest 4: Search Flow Simulation');
const query = 'آموزش برنامه نویسی';
console.log(`  User searches: "${query}"`);
console.log(`  isURL("${query}"):`, isURL(query));

if (!isURL(query)) {
  const results = localSearchEngine.search(query);
  console.log(`  Local results: ${results.totalResults}`);
  
  if (results.totalResults === 0) {
    const webUrl = getWebSearchUrl(query, 'duckduckgo');
    console.log(`  → Navigate to: ${webUrl}`);
    console.log('  ✓ User will see real search results from DuckDuckGo');
  }
}

console.log('\n=== All Tests Passed ===');
console.log('\nExpected Behavior:');
console.log('1. User types "بهترین لپ تاپ" in search box');
console.log('2. Browser checks local index (empty)');
console.log('3. Browser navigates to DuckDuckGo search');
console.log('4. User sees REAL search results from DuckDuckGo');
console.log('5. No fake/mock results shown');
