/**
 * Minesword Browser Engine - Automated Tests
 * 
 * Real tests for engine modules.
 * Run with: npm run test
 * 
 * These tests verify ACTUAL functionality, not mocks.
 */

import {
  normalizePersianText,
  tokenize,
  removeStopwords,
  persianStem,
  detectLanguage,
  stringSimilarity,
  isURL,
  parseURL,
  normalizeURL,
} from '../engine/persian';

import {
  parseCSP,
  isURLAllowedByCSP,
  checkURLSafety,
  checkMixedContent,
  parseCookieHeader,
  shouldAcceptCookie,
  getSandboxConfig,
  sandboxToString,
} from '../engine/security';

// === TEST FRAMEWORK ===

interface TestResult {
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestResult[] = [];

function test(name: string, fn: () => void): void {
  try {
    fn();
    results.push({ name, passed: true });
    console.log(`✓ ${name}`);
  } catch (error) {
    results.push({ 
      name, 
      passed: false, 
      error: error instanceof Error ? error.message : String(error) 
    });
    console.error(`✗ ${name}: ${error instanceof Error ? error.message : error}`);
  }
}

function assert(condition: boolean, message: string): void {
  if (!condition) {
    throw new Error(message);
  }
}

function assertEqual<T>(actual: T, expected: T, message?: string): void {
  if (actual !== expected) {
    throw new Error(message || `Expected ${expected}, got ${actual}`);
  }
}

// === PERSIAN TEXT TESTS ===

console.log('\n=== Persian Text Processing Tests ===\n');

test('normalizePersianText: Arabic Yeh to Persian Yeh', () => {
  assertEqual(normalizePersianText('بهترين'), 'بهترین');
});

test('normalizePersianText: Arabic Kaf to Persian Kaf', () => {
  assertEqual(normalizePersianText('كتاب'), 'کتاب');
});

test('normalizePersianText: Arabic digits to Persian digits', () => {
  assertEqual(normalizePersianText('١٢٣'), '۱۲۳');
});

test('normalizePersianText: Remove diacritics', () => {
  const input = 'مُحَمَّد';
  const result = normalizePersianText(input);
  assert(!result.includes('\u064E'), 'Should remove fatha');
  assert(!result.includes('\u064F'), 'Should remove damma');
  assert(!result.includes('\u0650'), 'Should remove kasra');
});

test('normalizePersianText: ZWNJ handling', () => {
  const input = 'برنامه‌نویسی';
  const result = normalizePersianText(input);
  assert(result.includes(' '), 'ZWNJ should become space');
});

test('normalizePersianText: Whitespace normalization', () => {
  assertEqual(normalizePersianText('  hello   world  '), 'hello world');
});

test('normalizePersianText: Case normalization', () => {
  assertEqual(normalizePersianText('Hello WORLD'), 'hello world');
});

test('tokenize: Persian text', () => {
  const tokens = tokenize('آموزش برنامه نویسی');
  assertEqual(tokens.length, 3);
  assertEqual(tokens[0], 'آموزش');
  assertEqual(tokens[1], 'برنامه');
  assertEqual(tokens[2], 'نویسی');
});

test('tokenize: Mixed Persian/English', () => {
  const tokens = tokenize('آموزش JavaScript');
  assert(tokens.length >= 2, 'Should tokenize mixed text');
});

test('removeStopwords: Persian stopwords', () => {
  const tokens = ['این', 'یک', 'کتاب', 'است'];
  const filtered = removeStopwords(tokens);
  assert(!filtered.includes('این'), 'Should remove این');
  assert(!filtered.includes('یک'), 'Should remove یک');
  assert(filtered.includes('کتاب'), 'Should keep کتاب');
});

test('persianStem: Remove plural suffix', () => {
  const stemmed = persianStem('کتابها');
  assertEqual(stemmed, 'کتاب');
});

test('persianStem: Remove comparative suffix', () => {
  const stemmed = persianStem('بهترین');
  assertEqual(stemmed, 'بهتر');
});

test('persianStem: Remove prefix', () => {
  const stemmed = persianStem('می‌نویسد');
  // After ZWNJ becomes space, it's two words
  assert(stemmed.length > 0, 'Should return something');
});

test('detectLanguage: Persian text', () => {
  assertEqual(detectLanguage('سلام دنیا'), 'fa');
});

test('detectLanguage: English text', () => {
  assertEqual(detectLanguage('Hello world'), 'en');
});

test('detectLanguage: Mixed text', () => {
  assertEqual(detectLanguage('Hello سلام'), 'mixed');
});

test('detectLanguage: Empty text', () => {
  assertEqual(detectLanguage(''), 'unknown');
});

test('stringSimilarity: Identical strings', () => {
  assertEqual(stringSimilarity('hello', 'hello'), 1);
});

test('stringSimilarity: Similar strings', () => {
  const similarity = stringSimilarity('hello', 'helo');
  assert(similarity > 0.5, 'Similar strings should have high similarity');
});

test('stringSimilarity: Different strings', () => {
  const similarity = stringSimilarity('hello', 'world');
  assert(similarity < 0.5, 'Different strings should have low similarity');
});

test('isURL: Valid HTTPS URL', () => {
  assert(isURL('https://example.com'), 'Should detect HTTPS URL');
});

test('isURL: Valid HTTP URL', () => {
  assert(isURL('http://example.com'), 'Should detect HTTP URL');
});

test('isURL: Domain without protocol', () => {
  assert(isURL('example.com'), 'Should detect domain');
});

test('isURL: Persian text (not URL)', () => {
  assert(!isURL('سلام دنیا'), 'Should not detect Persian text as URL');
});

test('parseURL: Valid URL', () => {
  const parsed = parseURL('https://example.com/path?query=1#hash');
  assert(parsed !== null, 'Should parse URL');
  assertEqual(parsed!.protocol, 'https:');
  assertEqual(parsed!.host, 'example.com');
  assertEqual(parsed!.path, '/path');
  assertEqual(parsed!.query, '?query=1');
  assertEqual(parsed!.hash, '#hash');
});

test('normalizeURL: Remove trailing slash', () => {
  const normalized = normalizeURL('https://example.com/');
  assertEqual(normalized, 'https://example.com');
});

// === SECURITY TESTS ===

console.log('\n=== Security Tests ===\n');

test('parseCSP: Basic policy', () => {
  const policy = parseCSP("default-src 'self'; script-src https://cdn.example.com");
  assert(policy.defaultSrc !== undefined, 'Should parse default-src');
  assert(policy.defaultSrc!.includes("'self'"), 'Should include self');
  assert(policy.scriptSrc !== undefined, 'Should parse script-src');
  assert(policy.scriptSrc!.includes('https://cdn.example.com'), 'Should include CDN');
});

test('parseCSP: Multiple directives', () => {
  const policy = parseCSP("default-src 'self'; img-src *; style-src 'unsafe-inline'");
  assert(policy.defaultSrc !== undefined, 'Should have default-src');
  assert(policy.imgSrc !== undefined, 'Should have img-src');
  assert(policy.styleSrc !== undefined, 'Should have style-src');
});

test('isURLAllowedByCSP: Self origin', () => {
  const allowed = isURLAllowedByCSP('https://example.com/page', ["'self'"], 'https://example.com');
  assert(allowed, 'Should allow same origin');
});

test('isURLAllowedByCSP: Different origin', () => {
  const allowed = isURLAllowedByCSP('https://other.com/page', ["'self'"], 'https://example.com');
  assert(!allowed, 'Should block different origin');
});

test('isURLAllowedByCSP: Wildcard', () => {
  const allowed = isURLAllowedByCSP('https://any.com/page', ['*'], 'https://example.com');
  assert(allowed, 'Should allow with wildcard');
});

test('isURLAllowedByCSP: None', () => {
  const allowed = isURLAllowedByCSP('https://example.com/page', ["'none'"], 'https://example.com');
  assert(!allowed, 'Should block with none');
});

test('checkURLSafety: Safe HTTPS URL', () => {
  const result = checkURLSafety('https://example.com');
  assert(result.safe, 'Should be safe');
  assertEqual(result.risk, 'none');
});

test('checkURLSafety: JavaScript protocol', () => {
  const result = checkURLSafety('javascript:alert(1)');
  assert(!result.safe, 'Should block javascript:');
  assertEqual(result.risk, 'high');
});

test('checkURLSafety: Data protocol', () => {
  const result = checkURLSafety('data:text/html,<script>alert(1)</script>');
  assert(!result.safe, 'Should block data:');
  assertEqual(result.risk, 'high');
});

test('checkURLSafety: Empty URL', () => {
  const result = checkURLSafety('');
  assert(!result.safe, 'Should block empty URL');
});

test('checkURLSafety: Suspicious pattern', () => {
  const result = checkURLSafety('http://example.com@evil.com');
  assert(!result.safe, 'Should block suspicious pattern');
});

test('checkMixedContent: HTTPS page, HTTP resource', () => {
  const result = checkMixedContent('https://example.com', 'http://cdn.com/script.js');
  assert(!result.allowed, 'Should block mixed content');
  assertEqual(result.type, 'active');
});

test('checkMixedContent: HTTPS page, HTTPS resource', () => {
  const result = checkMixedContent('https://example.com', 'https://cdn.com/script.js');
  assert(result.allowed, 'Should allow HTTPS resource');
});

test('parseCookieHeader: Basic cookie', () => {
  const cookie = parseCookieHeader('name=value');
  assert(cookie !== null, 'Should parse cookie');
  assertEqual(cookie!.name, 'name');
  assertEqual(cookie!.value, 'value');
});

test('parseCookieHeader: Cookie with attributes', () => {
  const cookie = parseCookieHeader('session=abc123; Secure; HttpOnly; SameSite=Strict');
  assert(cookie !== null, 'Should parse cookie');
  assert(cookie!.secure === true, 'Should have Secure flag');
  assert(cookie!.httpOnly === true, 'Should have HttpOnly flag');
  assertEqual(cookie!.sameSite, 'Strict');
});

test('shouldAcceptCookie: Secure cookie on HTTPS', () => {
  const cookie = { name: 'test', value: '1', secure: true };
  const result = shouldAcceptCookie(cookie, 'https://example.com', true);
  assert(result.accept, 'Should accept secure cookie on HTTPS');
});

test('shouldAcceptCookie: Secure cookie on HTTP', () => {
  const cookie = { name: 'test', value: '1', secure: true };
  const result = shouldAcceptCookie(cookie, 'http://example.com', false);
  assert(!result.accept, 'Should reject secure cookie on HTTP');
});

test('getSandboxConfig: Strict mode', () => {
  const config = getSandboxConfig('strict');
  assert(!config.includes('allow-scripts'), 'Strict should not allow scripts');
  assert(!config.includes('allow-same-origin'), 'Strict should not allow same-origin');
});

test('getSandboxConfig: Standard mode', () => {
  const config = getSandboxConfig('standard');
  assert(config.includes('allow-scripts'), 'Standard should allow scripts');
  assert(!config.includes('allow-same-origin'), 'Standard should not allow same-origin');
});

test('sandboxToString: Convert flags to string', () => {
  const flags: Array<'allow-scripts' | 'allow-forms'> = ['allow-scripts', 'allow-forms'];
  const str = sandboxToString(flags as any);
  assertEqual(str, 'allow-scripts allow-forms');
});

// === SUMMARY ===

console.log('\n=== Test Summary ===\n');

const passed = results.filter(r => r.passed).length;
const failed = results.filter(r => !r.passed).length;
const total = results.length;

console.log(`Total: ${total}`);
console.log(`Passed: ${passed}`);
console.log(`Failed: ${failed}`);
console.log(`Success Rate: ${((passed / total) * 100).toFixed(1)}%`);

// Export results for use in the browser
export const testResults = {
  total,
  passed,
  failed,
  successRate: (passed / total) * 100,
  results,
};

// Log final summary
if (failed > 0) {
  console.log('\nFailed tests:');
  results.filter(r => !r.passed).forEach(r => {
    console.log(`  - ${r.name}: ${r.error}`);
  });
} else {
  console.log('\n✓ All tests passed!');
}
