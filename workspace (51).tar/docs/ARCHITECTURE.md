# Minesword Browser - Architecture

## Overview

Minesword Browser follows a modular, layered architecture designed for:
- Separation of concerns
- Testability
- Replaceability of individual components
- Long-term extensibility

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    USER INTERFACE                         │
│  (React/WebView - Mobile-first, RTL, Persian-first)      │
├─────────────────────────────────────────────────────────┤
│                   BROWSER SHELL                           │
│  Tab Manager │ Navigation │ Address Bar │ UI State        │
├──────────┬──────────┬──────────┬──────────┬──────────────┤
│ SEARCH   │ NETWORK  │ SECURITY │ STORAGE  │ OFFLINE      │
│ ENGINE   │ MANAGER  │ POLICIES │ MANAGER  │ MANAGER      │
├──────────┴──────────┴──────────┴──────────┴──────────────┤
│                  MINESWORD ENGINE                          │
│  HTML │ CSS │ DOM │ Layout │ Rendering │ JS │ Networking  │
├─────────────────────────────────────────────────────────┤
│                   PLATFORM LAYER                          │
│  Android Native │ Web APIs │ File System │ Crypto         │
└─────────────────────────────────────────────────────────┘
```

## Module Descriptions

### 1. UI Layer (`src/App.tsx`, future `src/components/`)

**Responsibility**: User interface rendering, user interaction handling, animations.

**Key decisions**:
- React for web prototype (rapid iteration, component model)
- Tailwind CSS for styling (utility-first, small bundle)
- Framer Motion for animations (GPU-accelerated, declarative)
- Vazirmatn font for Persian typography

**Mobile-first principles**:
- Touch targets ≥ 44px
- Safe area insets for notched devices
- Reduced motion support
- RTL-first layout

### 2. Browser Shell

**Responsibility**: Tab management, navigation state, URL handling.

**Tab System**:
```typescript
interface Tab {
  id: string;
  title: string;
  url: string;
  isLoading: boolean;
  isPrivate: boolean;
  canGoBack: boolean;
  canGoForward: boolean;
}
```

**Navigation Logic**:
1. User enters text in address bar
2. System determines: URL or search query?
3. If URL → navigate (add protocol if missing)
4. If query → route to search engine

### 3. Engine Layer (`src/engine/`)

The engine is architected as independent subsystems:

#### 3.1 Persian Text Processing (`persian.ts`)

Handles all Persian/Arabic text normalization:

```
Input Text → Character Normalization → Diacritic Removal
          → Whitespace Normalization → Case Normalization
          → Output (normalized text)
```

**Key functions**:
- `normalizePersianText()` - Full normalization pipeline
- `tokenize()` - Word splitting (Persian + English)
- `removeStopwords()` - Stopword filtering
- `persianStem()` - Simple morphological analysis
- `detectLanguage()` - Language identification
- `stringSimilarity()` - Fuzzy matching (Dice coefficient)
- `isURL()` - URL detection
- `parseURL()` - URL parsing

#### 3.2 Network Manager (`network.ts`)

Three-state network detection:

```
┌────────────────┐
│  NETWORK MGR   │
├────────────────┤
│ online event   │──→ State Machine ──→ Listeners
│ offline event  │       │
│ connectivity   │       │
│ check API      │       ▼
│                │  GLOBAL_ONLINE
│                │  LOCAL_NETWORK
│                │  OFFLINE
└────────────────┘
```

**Design decisions**:
- Never claims to bypass restrictions
- Uses standard browser APIs (navigator.onLine, Network Information API)
- Periodic connectivity checks (30s interval)
- Event-driven updates to subscribers

#### 3.3 Storage Manager (`storage.ts`)

Persistent data management:

```
┌─────────────────────────────────────┐
│         STORAGE MANAGER             │
├─────────────────────────────────────┤
│ Bookmarks    │ History              │
│ Saved Pages  │ Downloads            │
│ Settings     │ Permissions          │
│ Search Hist  │ Tabs State           │
├─────────────────────────────────────┤
│     localStorage (current)          │
│     → SQLite (Android production)   │
│     → Encrypted storage (sensitive) │
└─────────────────────────────────────┘
```

**Migration strategy**: Interface-based design allows swapping storage backends without changing consumers.

#### 3.4 Search Engine (`search.ts`)

Full search pipeline:

```
Query → Normalize → Tokenize → Remove Stopwords
  ↓
Inverted Index Lookup → Candidate Documents
  ↓
Score (Title + Headings + Body + Quality + Freshness + Language)
  ↓
Sort → Generate Snippets → Related Searches
  ↓
Response
```

**Ranking signals**:
1. Title relevance (weight: 3.0)
2. Heading relevance (weight: 1.5)
3. Body term frequency (weight: 0.5 per match, max 3.0)
4. Document quality (multiplier: 0.5-1.0)
5. Freshness decay (90-day half-life)
6. Language match (multiplier: 1.2)
7. Exact phrase bonus (+2.0)

### 4. Security Layer

**Architecture**:
- Origin isolation via iframe sandbox attributes
- Permission model per-origin
- No credential logging
- Input validation at all boundaries
- CSP-ready architecture

**Permission Model**:
```typescript
interface SitePermission {
  origin: string;
  camera: 'allow' | 'block' | 'ask';
  microphone: 'allow' | 'block' | 'ask';
  location: 'allow' | 'block' | 'ask';
  notifications: 'allow' | 'block' | 'ask';
  clipboard: 'allow' | 'block' | 'ask';
}
```

### 5. Future Engine Components

The long-term goal is an independent browser engine:

```
engine/
├── html/        # HTML5 parser
├── css/         # CSS parser + style computation
├── dom/         # DOM tree + events
├── layout/      # Box model + flexbox + grid
├── rendering/   # Paint + compositing
├── javascript/  # JS engine integration
├── networking/  # HTTP client + WebSocket
├── storage/     # Web Storage + IndexedDB
├── security/    # CSP + SOP + sandboxing
├── media/       # Audio/video decoding
├── gpu/         # GPU acceleration
├── accessibility/ # ARIA + screen reader
├── workers/     # Web Workers
├── webapi/      # Web API implementations
└── cache/       # HTTP cache + service workers
```

**Current status**: Architecture designed, interfaces defined. Implementation uses WebView as rendering backend with clear boundaries for future replacement.

---

## Data Flow

### Navigation Flow
```
User Input → Address Bar → URL Detection
  ├─→ Is URL? → Navigate → Update Tab → Load in WebView
  └─→ Is Query? → Search Engine → Display Results
```

### Search Flow
```
Query → Normalize Persian → Tokenize
  → Index Lookup → Score → Rank → Snippet → Display
```

### Offline Flow
```
Network Check → State Detection
  ├─→ GLOBAL_ONLINE → Normal browsing
  ├─→ LOCAL_NETWORK → Use local services + cache
  └─→ OFFLINE → Cached/saved content + local search
```

---

## Performance Architecture

### Adaptive Performance Levels

| Parameter | LOW | BALANCED | HIGH |
|-----------|-----|----------|------|
| Animations | Disabled | Enabled | Full |
| Tab retention | 3 tabs | 8 tabs | Unlimited |
| Image quality | Low | Medium | Original |
| Cache size | 10MB | 50MB | 200MB |
| Preloading | None | Links | Aggressive |
| Background tabs | Frozen | Suspended | Active |

### Memory Management
- Inactive tab freezing after timeout
- Image decode size limits
- History cap (1000 entries)
- Search history cap (200 entries)
- Storage quota monitoring

---

## Testing Strategy

### Unit Tests
- Persian normalization
- Tokenization
- URL detection
- Ranking algorithm
- Storage operations

### Integration Tests
- Search pipeline
- Navigation flow
- Offline detection
- Tab management

### Security Tests
- XSS prevention
- Origin isolation
- Permission enforcement
- Input validation

---

## Design Decisions Log

| Decision | Choice | Reason |
|----------|--------|--------|
| UI Framework | React | Component model, rapid iteration, ecosystem |
| Styling | Tailwind CSS | Utility-first, small bundle, responsive |
| Animation | Framer Motion | GPU-accelerated, declarative, accessible |
| Font | Vazirmatn | Best Persian web font, open-source |
| Storage | localStorage | Simple, universal, migration path to SQLite |
| Search | Custom engine | Persian-first, no external dependency |
| Network | Browser APIs | Standard, reliable, no extra dependencies |

---

*This architecture is designed to evolve. Each module has clear interfaces allowing independent development and testing.*
