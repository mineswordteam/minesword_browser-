# Minesword Browser - Security

## Security Philosophy

Security is a top-level requirement in Minesword Browser, designed from the beginning rather than added later.

## Current Security Measures

### 1. Origin Isolation
- iframe sandbox attributes restrict cross-origin access
- `sandbox="allow-scripts allow-same-origin allow-forms allow-popups"`
- Scripts cannot access parent document across origins

### 2. URL Validation
- All URLs validated before navigation
- Protocol enforcement (https:// added if missing)
- Malformed URL rejection

### 3. Permission Model
```typescript
interface SitePermission {
  origin: string;
  camera: 'allow' | 'block' | 'ask';
  microphone: 'allow' | 'block' | 'ask';
  location: 'allow' | 'block' | 'ask';
  notifications: 'allow' | 'block' | 'ask';
  clipboard: 'allow' | 'block' | 'ask';
}
```
- Per-origin permission storage
- Default-deny for sensitive permissions
- User-controlled allow/block/ask

### 4. Private Browsing
- Private tabs don't persist to history
- Private tabs don't save search history
- Clear indication of private mode in UI
- **Limitation**: Does NOT make user anonymous on the internet

### 5. Tracking Protection
- Third-party cookie blocking (configurable)
- Tracking protection toggle
- Default: tracking protection enabled

### 6. Data Storage
- LocalStorage for non-sensitive data
- No credentials stored in plaintext
- No browsing data sent to analytics by default
- Telemetry disabled by default

### 7. Input Validation
- All user inputs validated before processing
- Search queries normalized before indexing
- URLs parsed and validated before navigation

## Planned Security Enhancements

### Process Isolation
- Separate processes for renderer and browser UI
- Crash isolation (one tab crash doesn't kill browser)
- Memory limits per process

### Content Security Policy
- CSP header enforcement
- Inline script blocking
- External resource restrictions

### Certificate Handling
- TLS certificate validation
- Certificate error UI (not silent failures)
- Certificate transparency checking

### Phishing/Malware Protection
- URL reputation checking
- Heuristic-based detection
- User warnings for suspicious sites
- Integration with public blocklists

### Secure Storage
- Encrypted local storage for sensitive data
- Android KeyStore integration
- Biometric authentication gate

### Memory Safety
- Input buffer bounds checking
- No unsafe memory operations
- Regular security code review

## Security Reporting

If you discover a security vulnerability, please report it responsibly.

## Threat Model

### Protected Against
- Cross-site scripting (XSS) via sandboxing
- Cross-site request forgery (CSRF) via SameSite cookies
- Data leakage via origin isolation
- Unauthorized permission use via explicit consent
- Credential theft via no-logging policy

### Not Protected Against (by design)
- Government-level network surveillance
- Physical device access (use device encryption)
- Compromised operating system
- Social engineering attacks

### Limitations
- Private mode does NOT provide anonymity
- The browser cannot bypass network restrictions
- WebView-based rendering inherits platform vulnerabilities
- Local storage is not encrypted (planned for future)

## Security Audit Checklist

- [x] No credentials logged
- [x] No sensitive data in analytics
- [x] Input validation at boundaries
- [x] Origin isolation
- [x] Permission model
- [x] Private mode implementation
- [x] No auto-execution of downloads
- [ ] Encrypted storage (planned)
- [ ] CSP enforcement (planned)
- [ ] Certificate pinning (planned)
- [ ] Phishing detection (planned)

---

*Security is an ongoing process, not a destination. This document will be updated as security measures are implemented.*
