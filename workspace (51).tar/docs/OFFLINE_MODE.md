# Minesword Browser - Offline Mode

## Overview

Minesword Browser provides intelligent offline capabilities that allow users to continue browsing useful content even when global internet connectivity is unavailable.

## Network States

```
┌─────────────────────────────────────────────────────┐
│                  NETWORK MANAGER                      │
├─────────────────────────────────────────────────────┤
│                                                       │
│   ┌──────────────┐  ┌──────────────┐  ┌───────────┐ │
│   │ GLOBAL_ONLINE│  │ LOCAL_NETWORK│  │  OFFLINE  │ │
│   │              │  │              │  │           │ │
│   │ Full access  │  │ Local services│  │ No network│ │
│   │ to internet  │  │ only         │  │ available │ │
│   └──────┬───────┘  └──────┬───────┘  └─────┬─────┘ │
│          │                 │                 │       │
│          ▼                 ▼                 ▼       │
│   Normal browsing    Use available      Show offline │
│   + caching          local services     UI + cached  │
│                      + cached content   content only │
│                                                       │
└─────────────────────────────────────────────────────┘
```

## Detection Mechanism

1. **Browser events**: `online`/`offline` events from `window`
2. **Network Information API**: `navigator.connection` for type/speed
3. **Active probing**: Periodic fetch to connectivity check endpoint
4. **Local service probing**: Check if internal services respond

### Important
- The browser NEVER claims to bypass internet shutdowns
- It only uses services that are ACTUALLY reachable
- Detection is best-effort, not guaranteed

## Offline Content Sources

When offline, content can come from:

| Source | Description | Priority |
|--------|-------------|----------|
| HTTP Cache | Browser-cached pages | High |
| Saved Pages | User-explicitly saved pages | High |
| Bookmarks | Quick access to known URLs | Medium |
| History | Recently visited pages | Medium |
| Downloads | Downloaded files | Medium |
| Local Search | Search over indexed local content | Low |

## Offline UI

When offline, the browser shows:

```
┌─────────────────────────────────────┐
│                                     │
│         🔌 اتصال برقرار نیست        │
│                                     │
│    اینترنت جهانی در دسترس نیست.     │
│                                     │
│    اما می‌توانید به محتوای          │
│    ذخیره‌شده دسترسی داشته باشید.    │
│                                     │
│    [صفحات ذخیره‌شده]  [نشانک‌ها]    │
│                                     │
│    [تلاش مجدد]                       │
│                                     │
└─────────────────────────────────────┘
```

## Service Worker Integration (Planned)

```
Request → Service Worker
           │
           ├─ Cache hit? → Return cached response
           │
           ├─ Network available? → Fetch + cache + return
           │
           └─ Offline → Return offline fallback page
```

## Storage Strategy

| Data Type | Storage | Limit | Eviction |
|-----------|---------|-------|----------|
| HTTP Cache | Browser cache | Configurable | LRU |
| Saved Pages | localStorage/IDB | 50MB | Manual |
| Search Index | In-memory + IDB | 10MB | Rebuild |
| Settings | localStorage | 100KB | Never |
| History | localStorage | 1000 entries | FIFO |

## Performance Level Adjustments

| Level | Cache Size | Preloading | Tab Retention |
|-------|-----------|------------|---------------|
| LOW | 10MB | None | 3 tabs |
| BALANCED | 50MB | Same-page links | 8 tabs |
| HIGH | 200MB | Aggressive | Unlimited |

## Future Enhancements

- [ ] Background page saving
- [ ] Offline reader mode (distilled content)
- [ ] Offline search over saved content
- [ ] Sync when reconnected
- [ ] Selective caching rules
- [ ] Storage quota management UI
- [ ] Offline-first PWA support

---

*Minesword Browser remains useful even without internet access.*
