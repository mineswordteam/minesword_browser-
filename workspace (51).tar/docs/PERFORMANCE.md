# Minesword Browser - Performance

## Overview

Performance is critical for Minesword Browser, especially on mid-range and low-end Android devices. The browser adapts its behavior based on device capabilities and user preferences.

## Performance Levels

### LOW (Battery Saver Mode)
Target: Devices with ≤2GB RAM, low-end CPUs

| Setting | Value |
|---------|-------|
| Animations | Disabled |
| Tab retention | 3 tabs max |
| Image quality | Compressed |
| Cache size | 10MB |
| Preloading | None |
| Background tabs | Frozen immediately |
| JavaScript | Optimized mode |

### BALANCED (Default)
Target: Devices with 3-4GB RAM, mid-range CPUs

| Setting | Value |
|---------|-------|
| Animations | Enabled (reduced) |
| Tab retention | 8 tabs |
| Image quality | Medium |
| Cache size | 50MB |
| Preloading | Same-page links |
| Background tabs | Suspended after 5min |
| JavaScript | Normal |

### HIGH (Performance Mode)
Target: Devices with ≥6GB RAM, flagship CPUs

| Setting | Value |
|---------|-------|
| Animations | Full |
| Tab retention | Unlimited |
| Image quality | Original |
| Cache size | 200MB |
| Preloading | Aggressive |
| Background tabs | Active |
| JavaScript | Full |

## Metrics Tracked

### PerformanceMonitor

```typescript
interface PerformanceMetrics {
  // Startup
  coldStartTime: number;      // ms from launch to interactive
  warmStartTime: number;      // ms from background to foreground
  
  // Navigation
  pageLoadTime: number;       // ms for page to become interactive
  firstContentfulPaint: number; // ms to first content
  largestContentfulPaint: number; // ms to largest content
  
  // Memory
  jsHeapUsed: number;         // bytes
  jsHeapTotal: number;        // bytes
  domNodes: number;           // count
  
  // Rendering
  frameRate: number;          // fps average
  droppedFrames: number;      // count
  
  // Network
  requestCount: number;
  totalBytes: number;
  cacheHitRate: number;       // percentage
  
  // Stability
  rendererCrashes: number;
  tabSuspensions: number;
}
```

## Optimization Strategies

### 1. Tab Management
```
Active Tab → Full resources
  ↓ (inactive for > timeout)
Suspended Tab → DOM preserved, JS paused
  ↓ (inactive for > extended timeout)
Frozen Tab → State serialized, resources released
  ↓ (user returns)
Restore → Deserialize state, reload if needed
```

### 2. Image Optimization
- Lazy loading for below-fold images
- Size-appropriate image serving
- WebP/AVIF preference when supported
- Decode size limits based on viewport

### 3. JavaScript Optimization
- Defer non-critical scripts
- Code splitting for browser features
- Worker offloading for heavy computation
- Idle-time processing for non-urgent tasks

### 4. Network Optimization
- Request coalescing
- Response compression
- Cache-aside pattern
- Connection pooling
- DNS prefetching

### 5. Memory Management
- Weak references for caches
- Periodic garbage collection hints
- Object pooling for frequent allocations
- Typed arrays for binary data

## Benchmarks (Target)

| Metric | LOW | BALANCED | HIGH |
|--------|-----|----------|------|
| Cold start | <3s | <2s | <1s |
| Page load (cached) | <1s | <500ms | <200ms |
| Page load (network) | <5s | <3s | <2s |
| Memory usage | <100MB | <200MB | <400MB |
| Frame rate | >24fps | >45fps | >60fps |
| Tab switch | <500ms | <200ms | <100ms |

## Reduced Motion Support

When `prefers-reduced-motion: reduce` is detected:
- All CSS animations disabled
- Transitions shortened to instant
- Loading indicators use static states
- No parallax or scroll effects

## Battery Optimization

- Pause background tab processing
- Reduce network polling frequency
- Disable unnecessary timers
- Throttle non-critical updates
- Respect system battery saver mode

## Crash Recovery

```
Tab Crash → Show error page
  ├─ "این صفحه دچار مشکل شد"
  ├─ [Reload] button
  └─ Other tabs unaffected

App Kill → Restore state
  ├─ Read saved tab state from storage
  ├─ Reopen last session tabs
  └─ Show "Session restored" notification

Network Failure → Graceful degradation
  ├─ Show cached version if available
  ├─ Show offline page if no cache
  └─ Auto-retry with exponential backoff
```

---

*Performance is not an afterthought - it's a core feature.*
