# Minesword Browser - Testing

## Overview

Testing is critical for a browser. This document describes the testing strategy.

## Test Categories

### 1. Unit Tests

#### Persian Text Processing
```typescript
// Character normalization
assert(normalizePersianText('بهترين') === 'بهترین'); // Arabic yeh
assert(normalizePersianText('كتاب') === 'کتاب');     // Arabic kaf
assert(normalizePersianText('١٢٣') === '۱۲۳');       // Arabic digits

// Zero-width non-joiner
assert(normalizePersianText('برنامه‌نویسی') === 'برنامه نویسی');

// Whitespace
assert(normalizePersianText('  hello   world  ') === 'hello world');

// Tokenization
assert(tokenize('آموزش برنامه نویسی').length === 3);

// Stopword removal
assert(!removeStopwords(['این', 'یک', 'کتاب']).includes('این'));

// Stemming
assert(persianStem('کتاب‌ها') === 'کتاب');

// Language detection
assert(detectLanguage('Hello world') === 'en');
assert(detectLanguage('سلام دنیا') === 'fa');
assert(detectLanguage('Hello سلام') === 'mixed');

// URL detection
assert(isURL('https://example.com') === true);
assert(isURL('example.com') === true);
assert(isURL('سلام دنیا') === false);
```

#### Search Engine
```typescript
// Basic search
const results = searchEngine.search('آموزش برنامه نویسی');
assert(results.results.length > 0);
assert(results.results[0].document.category === 'آموزش');

// Normalization in search
const r1 = searchEngine.search('بهترین لپ تاپ');
const r2 = searchEngine.search('بهترين لپتاپ');
assert(r1.results[0].document.id === r2.results[0].document.id);

// No results
const empty = searchEngine.search('xyznonexistent123');
assert(empty.results.length === 0);
assert(empty.isTestData === true);

// Suggestions
const suggestions = searchEngine.getSuggestions('آموزش');
assert(suggestions.length > 0);
```

#### Storage
```typescript
// Bookmarks
storageManager.addBookmark({ url: 'https://test.com', title: 'Test' });
assert(storageManager.isBookmarked('https://test.com'));
storageManager.removeBookmark(bookmarkId);
assert(!storageManager.isBookmarked('https://test.com'));

// History
storageManager.addHistoryEntry('https://test.com', 'Test');
const history = storageManager.getHistory();
assert(history.length > 0);
assert(history[0].url === 'https://test.com');

// Settings
storageManager.updateSettings({ theme: 'dark' });
assert(storageManager.getSettings().theme === 'dark');

// Clear
storageManager.clearAllData();
assert(storageManager.getBookmarks().length === 0);
```

### 2. Integration Tests

#### Navigation Flow
- URL input → URL detection → Navigation
- Query input → Search → Results display
- Back/forward navigation
- Tab creation and switching

#### Offline Mode
- Online → Offline transition
- Offline content display
- Reconnection handling
- Network state UI updates

#### Private Mode
- Private tab creation
- No history persistence
- No search history persistence
- Visual indicator

### 3. Security Tests

#### XSS Prevention
```
Test vectors:
<script>alert('xss')</script>
<img src=x onerror=alert('xss')>
<a href="javascript:alert('xss')">
<svg onload=alert('xss')>
```

#### Origin Isolation
- iframe cannot access parent document
- Cross-origin requests blocked
- Cookie isolation

#### Input Validation
- Malformed URLs rejected
- Oversized input handled
- Unicode edge cases
- Null bytes

### 4. Performance Tests

#### Startup
- Cold start < 3s (LOW), < 2s (BALANCED), < 1s (HIGH)
- Warm start < 500ms

#### Memory
- Idle memory < 50MB
- 10 tabs < 200MB
- No memory leaks over 1 hour

#### Rendering
- Frame rate > 30fps during scrolling
- No jank during tab switch

### 5. Accessibility Tests

- Screen reader labels on all interactive elements
- Touch targets ≥ 44px
- Keyboard navigation
- Reduced motion respected
- Color contrast ≥ 4.5:1

## Test Data

### Persian Search Corpus
10 test documents covering various topics. See SEARCH_ENGINE.md.

### Test Queries
```
"آموزش برنامه نویسی"
"بهترین لپ تاپ"
"بهترین لپتاپ"
"بهترين لپتاپ"
"قیمت گوشی"
"اخبار فناوری"
"بازی سازی"
"موتور بازی"
"برنامه نویسی اندروید"
"best گوشی"
```

## Running Tests

```bash
# Type checking
npm run typecheck

# Build verification
npm run build

# Manual testing checklist
# See QUALITY_GATE section in project requirements
```

## Quality Gate

Before any release:

1. ✅ Build succeeds
2. ✅ Type checking passes
3. ✅ RTL rendering correct
4. ✅ Persian text displays correctly
5. ✅ Navigation works
6. ✅ Tabs work
7. ✅ Search returns correct results
8. ✅ Offline mode shows correct UI
9. ✅ Private mode doesn't persist data
10. ✅ Settings persist across sessions
11. ✅ No console errors
12. ✅ Responsive on mobile viewport
13. ✅ Dark/Light theme works
14. ✅ No fake/placeholder implementations visible to user

---

*Testing is not optional. Every feature must be tested.*
