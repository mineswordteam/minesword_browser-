# Minesword Browser Engine

## Overview

The Minesword Browser Engine is the core rendering and execution subsystem of the browser. It is designed as a modular, replaceable architecture.

## Current Status

**Phase**: Architecture Design + Interface Definition

The engine currently uses the platform's WebView as its rendering backend. The architecture is designed so that individual components can be replaced with custom implementations over time.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    MINESWORD ENGINE                           │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │   HTML   │  │   CSS    │  │   DOM    │  │  Layout  │   │
│  │  Parser  │  │  Parser  │  │   Tree   │  │  Engine  │   │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘   │
│       │              │              │              │          │
│       └──────────────┴──────────────┴──────────────┘          │
│                          │                                    │
│                    ┌─────┴─────┐                              │
│                    │ Rendering │                              │
│                    │  Pipeline │                              │
│                    └─────┬─────┘                              │
│                          │                                    │
│  ┌──────────┐  ┌────────┴────────┐  ┌──────────┐           │
│  │JavaScript│  │    Networking   │  │  Media   │           │
│  │  Engine  │  │    (HTTP/WS)    │  │ Decoder  │           │
│  └──────────┘  └─────────────────┘  └──────────┘           │
│                                                               │
│  ┌──────────┐  ┌─────────────────┐  ┌──────────┐           │
│  │ Security │  │    Storage      │  │   GPU    │           │
│  │  (SOP,   │  │ (WebStorage,    │  │Accelerate│           │
│  │   CSP)   │  │  IndexedDB)     │  │          │           │
│  └──────────┘  └─────────────────┘  └──────────┘           │
│                                                               │
│  ┌──────────┐  ┌─────────────────┐  ┌──────────┐           │
│  │   Web    │  │    Workers      │  │   Cache  │           │
│  │   APIs   │  │ (Web, Service)  │  │  Manager │           │
│  └──────────┘  └─────────────────┘  └──────────┘           │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

## Component Interfaces

### HTML Parser
```typescript
interface HTMLParser {
  parse(source: string): Document;
  parseFragment(source: string): DocumentFragment;
}
```

### CSS Parser
```typescript
interface CSSParser {
  parse(source: string): StyleSheet;
  computeStyle(element: Element, rules: CSSRule[]): ComputedStyle;
}
```

### DOM
```typescript
interface DOMTree {
  createElement(tag: string): Element;
  createTextNode(text: string): TextNode;
  querySelector(selector: string): Element | null;
  querySelectorAll(selector: string): Element[];
  addEventListener(type: string, handler: EventHandler): void;
}
```

### Layout Engine
```typescript
interface LayoutEngine {
  calculateLayout(root: LayoutNode, constraints: BoxConstraints): LayoutResult;
  // Supports: block, inline, flexbox, grid
}
```

### Rendering Pipeline
```typescript
interface Renderer {
  paint(layoutResult: LayoutResult): RenderCommands;
  composite(layers: RenderLayer[]): FrameBuffer;
  present(frame: FrameBuffer): void;
}
```

### JavaScript Engine Interface
```typescript
interface JSEngine {
  evaluate(source: string, context: ExecutionContext): JSValue;
  registerAPI(name: string, implementation: Function): void;
  setGlobal(name: string, value: JSValue): void;
}
```

## Web Compatibility Matrix

| Feature | Status | Notes |
|---------|--------|-------|
| HTML5 parsing | Via WebView | Full HTML5 support via platform |
| CSS3 | Via WebView | Modern CSS via platform |
| DOM Level 4 | Via WebView | Full DOM API |
| ES2023 | Via WebView | Modern JavaScript |
| ES Modules | Via WebView | Import/export support |
| Web Storage | Implemented | Via StorageManager |
| IndexedDB | Planned | Interface defined |
| Cookies | Via WebView | Platform cookie jar |
| HTTP/HTTPS | Via WebView | Platform networking |
| WebSocket | Planned | Interface defined |
| Web Workers | Planned | Interface defined |
| Service Workers | Planned | For offline support |
| Canvas 2D | Via WebView | Platform implementation |
| WebGL | Via WebView | Platform implementation |
| WebGPU | Not planned | Future consideration |
| WebAssembly | Via WebView | Platform implementation |
| Fullscreen API | Planned | Interface defined |
| Notifications | Planned | Via permission system |
| Geolocation | Planned | Via permission system |
| Media Capture | Planned | Via permission system |
| Accessibility | Planned | ARIA support |

## Implementation Strategy

### Phase 1: WebView Integration (Current)
- Use platform WebView for rendering
- Implement browser chrome (UI) in React/native
- Define clean interfaces for future replacement
- Handle navigation, permissions, security at browser level

### Phase 2: Component Extraction
- Extract HTML parser (custom or library-based)
- Extract CSS parser
- Build custom DOM implementation
- Define rendering interface

### Phase 3: Custom Rendering
- Build layout engine (block model first)
- Build paint system
- Add GPU acceleration
- Implement compositing

### Phase 4: JavaScript
- Integrate JS engine (QuickJS for mobile)
- Build DOM bindings
- Implement Web APIs
- Add ES module support

### Phase 5: Full Compatibility
- Pass web platform tests
- Implement remaining Web APIs
- Add advanced CSS features
- Performance optimization

## Testing

### Conformance Tests
- W3C web platform tests
- HTML5 test suite
- CSS test suite
- ECMAScript test262

### Performance Tests
- Speedometer (JavaScript)
- MotionMark (Graphics)
- JetStream (Comprehensive)
- Custom benchmarks

### Security Tests
- XSS test vectors
- CSP bypass attempts
- Origin isolation tests
- Permission boundary tests

---

## Important Notes

1. **This is NOT a complete browser engine.** It is an architecture designed to grow into one.

2. **WebView is the current backend.** This is a legitimate engineering choice for Phase 1.

3. **Interfaces are the key deliverable.** Clean interfaces enable future replacement.

4. **Web compatibility comes from the platform.** The WebView provides modern web support today.

5. **The goal is an independent engine.** But this takes years of dedicated engineering.

---

*Building a browser engine is a multi-year project. The architecture is the foundation.*
