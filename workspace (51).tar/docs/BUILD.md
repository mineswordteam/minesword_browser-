# Minesword Browser - Build Guide

## Prerequisites

- Node.js 18+
- npm 9+

## Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Type checking
npm run typecheck
```

## Production Build

```bash
# Build for production
npm run build

# Output directory: dist/
# Files:
#   dist/index.html        - Entry HTML
#   dist/assets/*.css      - Compiled CSS
#   dist/assets/*.js       - Compiled JavaScript
```

## Project Structure

```
minesword-browser/
├── index.html              # Entry HTML (RTL, Persian, Vazirmatn font)
├── src/
│   ├── main.tsx            # React entry point
│   ├── App.tsx             # Main application component
│   ├── index.css           # Tailwind CSS + custom styles
│   └── engine/
│       ├── index.ts        # Engine public API
│       ├── persian.ts      # Persian text processing
│       ├── network.ts      # Network state detection
│       ├── storage.ts      # Local storage management
│       └── search.ts       # Minesword Search engine
├── docs/                   # Documentation
├── README.md
├── THIRD_PARTY_NOTICES.md
├── package.json
├── tsconfig.json
└── vite.config.js
```

## Build Output

| File | Size (gzip) | Description |
|------|-------------|-------------|
| index.html | 0.83 KB | Entry HTML |
| index.css | 5.55 KB | Styles |
| index.js | 99.69 KB | Application bundle |

**Total**: ~106 KB gzipped

## Environment Variables

No environment variables required for the current build.

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Samsung Internet 15+

## Android Build (Future)

For the native Android version:
1. Android Studio
2. Gradle 8+
3. Kotlin 1.9+
4. minSdk 24 (Android 7.0)
5. targetSdk 34 (Android 14)

```bash
# Future Android build
cd android/
./gradlew assembleRelease
```

---

*Build should complete in under 10 seconds on modern hardware.*
