# Minesword Search Engine

## Overview

Minesword Search is a Persian-first local search engine. It searches ONLY content that the user has explicitly saved or indexed. It does NOT contain pre-loaded test data or mock results.

## Current Status

**Local Search**: Searches user-saved content only
**Web Search**: Routes queries to real providers (DuckDuckGo, Bing, Google)
**Test Data**: NONE - the engine starts with an empty index

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    MINESWORD SEARCH                       │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  USER ACTION:                                           │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐             │
│  │ Save Page│→ │  Index   │→ │  Local   │             │
│  │  Button  │  │ Document │  │  Search  │             │
│  └──────────┘  └──────────┘  └──────────┘             │
│                                                         │
│  QUERY PIPELINE:                                        │
│  ┌─────────┐  ┌──────────┐  ┌──────────┐  ┌─────────┐ │
│  │  Query  │→ │ Normalize│→ │ Tokenize │→ │  Score  │ │
│  │  Input  │  │ Persian  │  │ + Stem   │  │ + Rank  │ │
│  └─────────┘  └──────────┘  └──────────┘  └─────────┘ │
│                                              │          │
│  INDEX:                                      ▼          │
│  ┌─────────────────────────────────────────────────┐   │
│  │  Inverted Index (token → document IDs)          │   │
│  │  Document Store (id → full document)            │   │
│  │  Persisted to localStorage                      │   │
│  └─────────────────────────────────────────────────┘   │
│                                                         │
│  IF NO LOCAL RESULTS:                                   │
│  ┌─────────┐  ┌──────────┐  ┌──────────┐             │
│  │  Show   │→ │  Route   │→ │  Open in │             │
│  │ Message │  │  to Web  │  │ New Tab  │             │
│  └─────────┘  └──────────┘  └──────────┘             │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

## How It Works

### 1. User Saves a Page
When the user clicks the "ذخیره" (Save) button:
- The page HTML is stored in localStorage
- The page content is indexed by the search engine
- Title, body text, and headings are extracted and tokenized

### 2. User Searches
When the user enters a query:
- The query is normalized (Persian text processing)
- The query is tokenized and stemmed
- The inverted index is searched for matching documents
- Results are scored and ranked
- If results found → display local results
- If no results → offer to search the web

### 3. Web Search Routing
When no local results exist:
- A clear message is shown: "No local results found"
- The user can choose to search using DuckDuckGo, Bing, or Google
- The query is routed to the chosen provider
- Results open in a new tab/window

## Persian Text Processing

### Normalization Pipeline

```
Raw Text
  ↓
1. Arabic → Persian character mapping
   ي → ی  (Arabic Yeh → Persian Yeh)
   ك → ک  (Arabic Kaf → Persian Kaf)
  ↓
2. Digit normalization
   ٠١٢٣٤٥٦٧٨٩ → ۰۱۲۳۴۵۶۷۸۹
  ↓
3. Diacritic removal
   Remove Arabic/Persian diacritics (ـَـُـِـّ)
  ↓
4. Special character handling
   Remove tatweel (ـ)
   ZWNJ (‌) → space (for search matching)
   Remove directional marks
  ↓
5. Whitespace normalization
   Multiple spaces → single space
   Trim
  ↓
6. Case normalization
   English parts → lowercase
  ↓
Normalized Text
```

### Examples

| Input | Normalized |
|-------|-----------|
| "بهترين لپتاپ" | "بهترین لپتاپ" |
| "بهترین لپ تاپ" | "بهترین لپ تاپ" |
| "برنامه‌نویسی" | "برنامه نویسی" |
| "كتاب" | "کتاب" |

### Tokenization

Words are split on whitespace and punctuation while keeping Persian/Arabic words intact:

```
"آموزش برنامه نویسی اندروید"
→ ["آموزش", "برنامه", "نویسی", "اندروید"]
```

### Stopword Removal

Common Persian and English stopwords are removed:

Persian: و، در، به، از، که، این، را، با، است، برای...
English: the, a, is, are, was, were, be, been...

### Stemming

Simple prefix/suffix removal for Persian:

Suffixes: ها، های، تر، ترین، ی، ام، ات، اش، مان، تان، شان
Prefixes: می، بی، نا

Example: "برنامه‌نویسی‌ها" → "برنامه نویسی"

## Ranking Algorithm

### Scoring Formula

```
Score = BaseRelevance × QualityMultiplier × FreshnessMultiplier × LanguageMultiplier

Where:
  BaseRelevance = TitleScore + HeadingScore + BodyScore + PhraseBonus
  TitleScore = Σ (3.0 per query term in title)
  HeadingScore = Σ (1.5 per query term in headings)
  BodyScore = min(Σ (0.5 per occurrence), 3.0)
  PhraseBonus = 2.0 if exact phrase found
  
  QualityMultiplier = 0.5 + (document_quality × 0.5)  [range: 0.5-1.0]
  FreshnessMultiplier = 1 + max(0, 1 - days/90) × 0.3  [decays over 90 days]
  LanguageMultiplier = 1.2 if query language matches document language
```

### Ranking Signals

| Signal | Weight | Description |
|--------|--------|-------------|
| Title match | 3.0 | Query terms in document title |
| Heading match | 1.5 | Query terms in section headings |
| Body frequency | 0.5/term | Term frequency in body (capped) |
| Document quality | 0.5-1.0× | Editorial quality score |
| Freshness | 0-0.3× | Recency boost (90-day decay) |
| Language match | 1.2× | Query/doc language alignment |
| Exact phrase | 2.0 | Bonus for exact phrase match |

## Fuzzy Matching

The search engine uses Dice coefficient for fuzzy matching:

```typescript
stringSimilarity("hello", "helo")  // → 0.8 (high similarity)
stringSimilarity("hello", "world") // → 0.2 (low similarity)
```

This provides typo tolerance for both Persian and English queries.

## Storage

The search index is persisted to localStorage:

```typescript
localStorage.setItem('minesword_search_index', JSON.stringify(documents));
```

### Storage Limits
- localStorage: ~5-10MB (browser-dependent)
- Maximum documents: Limited by storage size
- Automatic eviction: Not implemented (manual clear available)

## Important Notes

1. **No Pre-loaded Data**: The engine starts with an empty index. Users must save pages to build the index.

2. **No Mock Results**: When no local content matches, the engine returns empty results - it never fabricates results.

3. **Web Search Fallback**: When local search has no results, the browser routes to real web search providers.

4. **Scale**: This local engine is designed for personal use (hundreds to thousands of documents). A production search engine requires distributed infrastructure.

5. **Architecture**: The interface is designed so the local engine can be replaced by a remote API without changing the browser UI.

## Production Roadmap

### Phase 1: Local Engine (Current)
- ✅ Persian normalization
- ✅ Inverted index
- ✅ TF-IDF ranking
- ✅ Fuzzy matching
- ✅ localStorage persistence
- ✅ Empty index (no mock data)

### Phase 2: Enhanced Local Features
- [ ] BM25 scoring
- [ ] Spell correction (edit distance)
- [ ] Query classification
- [ ] Synonym dictionary
- [ ] Transliteration variants
- [ ] Automatic page indexing (opt-in)

### Phase 3: Crawler Infrastructure
- [ ] URL frontier (priority queue)
- [ ] robots.txt parser
- [ ] Sitemap parser
- [ ] Politeness delays
- [ ] Content deduplication
- [ ] Incremental crawling

### Phase 4: Indexing Infrastructure
- [ ] Distributed document store
- [ ] Sharded inverted index
- [ ] Real-time index updates
- [ ] Index compression
- [ ] Segment merging

### Phase 5: Ranking Improvements
- [ ] Link analysis (PageRank-like)
- [ ] User behavior signals
- [ ] ML-based ranking (LTR)
- [ ] Entity recognition

### Phase 6: Query Understanding
- [ ] Query classification
- [ ] Intent detection
- [ ] Named entity recognition
- [ ] Query expansion

---

*Minesword Search - Persian-first, quality-focused, transparent, no mock data.*
