# Third-Party Notices

Minesword Browser uses the following open-source components:

---

## React
- **License**: MIT
- **Copyright**: Meta Platforms, Inc. and affiliates
- **Repository**: https://github.com/facebook/react
- **Usage**: UI framework for browser interface

---

## Tailwind CSS
- **License**: MIT
- **Copyright**: Tailwind Labs Inc.
- **Repository**: https://github.com/tailwindlabs/tailwindcss
- **Usage**: Utility-first CSS framework

---

## Framer Motion
- **License**: MIT
- **Copyright**: Framer B.V.
- **Repository**: https://github.com/framer/motion
- **Usage**: Animation library for UI transitions

---

## Lucide React
- **License**: ISC
- **Copyright**: Lucide Contributors
- **Repository**: https://github.com/lucide-icons/lucide
- **Usage**: Icon library

---

## Vazirmatn Font
- **License**: SIL Open Font License 1.1
- **Copyright**: Saber Rastikerdar
- **Repository**: https://github.com/rastikerdar/vazirmatn
- **Usage**: Persian/Arabic typography

---

## UUID
- **License**: MIT
- **Copyright**: UUID contributors
- **Repository**: https://github.com/uuidjs/uuid
- **Usage**: Unique identifier generation

---

## Vite
- **License**: MIT
- **Copyright**: Evan You and Vite contributors
- **Repository**: https://github.com/vitejs/vite
- **Usage**: Build tool and dev server

---

## TypeScript
- **License**: Apache-2.0
- **Copyright**: Microsoft Corporation
- **Repository**: https://github.com/microsoft/TypeScript
- **Usage**: Type-safe JavaScript development

---

## Summary

All third-party components are used under their respective open-source licenses.
No proprietary code or assets from Google, Chrome, or any other browser vendor
is included in this project.

---

*Last updated: 2024*
